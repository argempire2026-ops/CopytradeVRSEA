const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/clearingHistory \? clearingHistory \? t\[lang\].deleting : t\[lang\].deleteAllNow}/g, 'clearingHistory ? t[lang].deleting : t[lang].deleteAllNow}');
code = code.replace(/clearingHistory \? clearingHistory \? t\[lang\].deleting : t\[lang\].confirmDeleteAll}/g, 'clearingHistory ? t[lang].deleting : t[lang].confirmDeleteAll}');

fs.writeFileSync('src/components/Dashboard.tsx', code);
