const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add state for defaultMaxTrials
code = code.replace(
  "const [historyDays, setHistoryDays] = useState(30);",
  "const [historyDays, setHistoryDays] = useState(30);\n  const [defaultMaxTrials, setDefaultMaxTrials] = useState(1);"
);

// 2. Fetch defaultMaxTrials from settings
code = code.replace(
  "if (data.historyDays) setHistoryDays(data.historyDays);",
  "if (data.historyDays) setHistoryDays(data.historyDays);\n        if (data.defaultMaxTrials !== undefined) setDefaultMaxTrials(data.defaultMaxTrials);"
);

// 3. Update save settings
code = code.replace(
  "historyDays,\n        eaList,",
  "historyDays,\n        defaultMaxTrials,\n        eaList,"
);

// 4. Update UI in settings tab to configure defaultMaxTrials
const settingsUI = `                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Default Max Trial Claims</label>
                  <input
                    type="number"
                    min="0"
                    value={defaultMaxTrials}
                    onChange={(e) => setDefaultMaxTrials(parseInt(e.target.value) || 0)}
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-1"
                  />
                  <p className="text-xs text-slate-500 mb-6">Global limit for how many times a client can claim the free trial.</p>

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.historyDays}</label>`;
code = code.replace(
  '<label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.historyDays}</label>',
  settingsUI
);

// 5. Update client fetch logic to include maxTrials and trialCount
code = code.replace(
  "setClientUser({ email: matchedClient.email, name: matchedClient.name, trialCount: matchedClient.trialCount || 0 });",
  "setClientUser({ email: matchedClient.email, name: matchedClient.name, trialCount: matchedClient.trialCount || 0, maxTrials: matchedClient.maxTrials });"
);

// 6. Update handleClaimTrial logic to enforce limit and increment trialCount
const handleClaimTrialOld = `    setTrialLoading(true);
    setTrialResult(null);
    try {
      // Create a 3 day expiry`;

const handleClaimTrialNew = `    const maxAllowed = clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials;
    if (clientUser.trialCount >= maxAllowed) {
      setTrialResult({ key: '', error: \`You have reached the maximum allowed trial claims (\${maxAllowed}).\` });
      return;
    }

    setTrialLoading(true);
    setTrialResult(null);
    try {
      // Update trial count in client doc
      const clientQuery = query(collection(db, 'clients'), where('email', '==', clientUser.email));
      const clientSnap = await getDocs(clientQuery);
      if (!clientSnap.empty) {
        const clientDoc = clientSnap.docs[0];
        await updateDoc(doc(db, 'clients', clientDoc.id), {
          trialCount: (clientUser.trialCount || 0) + 1
        });
        setClientUser({ ...clientUser, trialCount: (clientUser.trialCount || 0) + 1 });
      }

      // Create a 3 day expiry`;

code = code.replace(handleClaimTrialOld, handleClaimTrialNew);


fs.writeFileSync('src/components/Dashboard.tsx', code);
