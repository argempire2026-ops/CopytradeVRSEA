const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const clientsTabRender = `          ) : activeTab === 'clients' ? (
            <div className="flex-1 flex flex-col gap-6">
              <div className="bg-[#131E3A] p-6 rounded-xl border border-slate-800 shadow-sm shrink-0">
                <h3 className="text-sm uppercase font-bold text-slate-200 tracking-wider mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4 text-indigo-500" />
                  Client Accounts Management
                </h3>
                <p className="text-xs text-slate-400 mb-6">
                  Daftarkan pelanggan baru di sini untuk memberikan mereka akses ke portal pelanggan. Mereka boleh log masuk menggunakan e-mel dan kata laluan ini.
                </p>
                <form onSubmit={handleCreateClient} className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-400 mb-1">E-mel Pelanggan</label>
                    <input
                      type="email"
                      value={newClientEmail}
                      onChange={(e) => setNewClientEmail(e.target.value)}
                      placeholder="client@gmail.com"
                      className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Nama Penuh</label>
                    <input
                      type="text"
                      value={newClientName}
                      onChange={(e) => setNewClientName(e.target.value)}
                      placeholder="Ali Abu"
                      className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Kata Laluan</label>
                    <input
                      type="text"
                      value={newClientPassword}
                      onChange={(e) => setNewClientPassword(e.target.value)}
                      placeholder="Password Sementara"
                      className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 text-xs font-bold rounded flex items-center justify-center gap-2 transition-colors"
                  >
                    <Plus className="w-4 h-4" /> Daftar
                  </button>
                </form>
              </div>

              <div className="flex-1 flex flex-col bg-[#131E3A] rounded-xl overflow-hidden shadow-lg border border-slate-800">
                <div className="overflow-x-auto flex-1">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800 sticky top-0">
                      <tr>
                        <th className="px-6 py-3 whitespace-nowrap">Nama</th>
                        <th className="px-6 py-3 whitespace-nowrap">E-mel</th>
                        <th className="px-6 py-3 whitespace-nowrap">Kata Laluan</th>
                        <th className="px-6 py-3 whitespace-nowrap text-right">Tindakan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clients.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-6 py-8 text-center text-slate-400 text-xs font-medium">
                            Tiada pelanggan berdaftar.
                          </td>
                        </tr>
                      ) : (
                        clients.map(client => (
                          <tr key={client.id} className="hover:bg-[#050914]">
                            <td className="px-6 py-4 text-sm font-medium text-slate-200">{client.name}</td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-400">{client.email}</td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded font-mono text-xs">{client.password}</span>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button onClick={() => handleDeleteClient(client.email)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-500/10 rounded transition-colors" title="Padam Akaun">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : activeTab === 'html' ? (`;

code = code.replace("          ) : activeTab === 'html' ? (", clientsTabRender);
fs.writeFileSync('src/components/Dashboard.tsx', code);
