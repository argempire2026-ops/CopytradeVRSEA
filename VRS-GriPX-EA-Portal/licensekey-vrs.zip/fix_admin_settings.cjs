const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldSetting = `                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.tutorialLink}</label>
                      <input
                        type="url"
                        value={tutorialLink}
                        onChange={(e) => setTutorialLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://youtube.com/..."
                      />
                    </div>`;

const newSetting = `                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.tutorialLink}</label>
                      <input
                        type="url"
                        value={tutorialLink}
                        onChange={(e) => setTutorialLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://youtube.com/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Langganan / Renew Link</label>
                      <input
                        type="url"
                        value={renewLink}
                        onChange={(e) => setRenewLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://toyyibpay.com/..."
                      />
                      <p className="text-xs text-slate-500 mt-2">Pautan ini akan dipaparkan di portal pelanggan jika mereka sudah menebus Free Trial.</p>
                    </div>`;

code = code.replace(oldSetting, newSetting);
fs.writeFileSync('src/components/Dashboard.tsx', code);
