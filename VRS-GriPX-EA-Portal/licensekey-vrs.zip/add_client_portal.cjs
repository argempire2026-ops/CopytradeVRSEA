const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const clientPortalRender = `  if (!user) {
    if (clientUser) {
      return (
        <div className="min-h-screen w-full bg-[#0B132B] flex flex-col font-sans">
          <header className="h-16 bg-[#131E3A] border-b border-slate-800 flex items-center justify-between px-4 md:px-8">
            <div className="flex items-center gap-2">
              <img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-8 h-8 rounded object-cover" alt="VRS Logo" />
              <h1 className="text-white font-bold tracking-tight text-lg">VRS Client Portal</h1>
            </div>
            <div className="flex items-center gap-4">
              <p className="text-sm text-slate-300 hidden md:block">Selamat Datang, {clientUser.name || clientUser.email}</p>
              <button 
                onClick={() => setClientUser(null)} 
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded text-sm hover:bg-slate-700 transition-colors"
              >
                Log Keluar
              </button>
            </div>
          </header>
          <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
            <h2 className="text-xl font-bold text-slate-200 mb-6">Lesen Aktif Anda</h2>
            <div className="bg-[#131E3A] rounded-xl shadow-lg border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-3 whitespace-nowrap">License Key</th>
                      <th className="px-6 py-3 whitespace-nowrap">Status</th>
                      <th className="px-6 py-3 whitespace-nowrap">Nama MT5 (Allowed)</th>
                      <th className="px-6 py-3 whitespace-nowrap">Tamat Tempoh</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {clientKeys.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-slate-400">
                          <p className="text-sm font-semibold text-slate-700">Tiada lesen dijumpai.</p>
                        </td>
                      </tr>
                    ) : (
                      clientKeys.map(k => (
                        <tr key={k.id} className="hover:bg-[#050914]">
                          <td className="px-6 py-4 font-mono text-xs text-[#D4AF37] font-medium">{k.key}</td>
                          <td className="px-6 py-4">
                            <span className={\`inline-flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider \${k.status === 'active' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'}\`}>
                              {k.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-xs font-semibold text-slate-400">{k.allowedAccounts || 'Any Account'}</td>
                          <td className="px-6 py-4 text-xs text-slate-400 whitespace-nowrap">
                            {k.expiresAt ? new Date(k.expiresAt).toLocaleDateString('ms-MY', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Lifetime'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </main>
        </div>
      );
    }
    if (showAdminLogin) {`;

code = code.replace(`  if (!user) {
    if (showAdminLogin) {`, clientPortalRender);
fs.writeFileSync('src/components/Dashboard.tsx', code);
