const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  ".catch(err => console.error(\"Failed to load EA code\", err));\n  }, []);",
  ".catch(err => console.error(\"Failed to load EA code\", err));\n\n    fetch('/dashboard-export.html')\n      .then(res => res.text())\n      .then(text => setHtmlCode(text))\n      .catch(err => console.error(\"Failed to load HTML code\", err));\n  }, []);"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
