const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

if (code.startsWith('export const EA_CODE = "')) {
    let inner = code.substring('export const EA_CODE = "'.length);
    if (inner.endsWith('";\n')) {
        inner = inner.substring(0, inner.length - 3);
    } else if (inner.endsWith('";')) {
        inner = inner.substring(0, inner.length - 2);
    }
    
    // Convert any physical newlines to "\n" (literal backslash n)
    inner = inner.replace(/\n/g, '\\n');
    // Ensure no unescaped quotes break the string. (We should escape all " that are not already escaped, but for now we just handle newlines.)
    
    fs.writeFileSync('src/eaCode.ts', 'export const EA_CODE = "' + inner + '";\n');
    console.log("Fixed eaCode.ts syntax");
}
