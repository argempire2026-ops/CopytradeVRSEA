const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const clientLoginForm = `            ) : showClientLogin ? (
              <form onSubmit={handleClientLogin} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Client Login</h2>
                {clientLoginError && <p className="text-red-500 text-sm font-medium text-center">{clientLoginError}</p>}
                <div>
                  <input
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder="E-mel Mendaftar"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={clientPassword}
                    onChange={(e) => setClientPassword(e.target.value)}
                    placeholder="Kata Laluan"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                  Log Masuk
                </button>
                <button type="button" onClick={() => setShowClientLogin(false)} className="w-full mt-2 py-2 text-sm text-slate-400 hover:text-slate-200">Kembali</button>
              </form>
            ) : (`;

const clientLoginButton = `              </form>
            )}
            </>
            )}
            
            {!showPasswordPrompt && !showClientLogin && (
              <div className="mt-8 text-center border-t border-slate-800 pt-6">
                <p className="text-sm text-slate-400 mb-3">Pelanggan berdaftar?</p>
                <button 
                  onClick={() => setShowClientLogin(true)}
                  className="px-6 py-2 bg-slate-800 text-slate-300 rounded hover:bg-slate-700 transition-colors text-sm font-medium"
                >
                  Log Masuk Pelanggan
                </button>
              </div>
            )}
          </div>`;

code = code.replace(`            ) : (`, clientLoginForm);
code = code.replace(`              </form>
            )}
            </>
            )}
          </div>`, clientLoginButton);

fs.writeFileSync('src/components/Dashboard.tsx', code);
