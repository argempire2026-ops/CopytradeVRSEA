const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const brokenPart = `            ) : (                                      {!showPasswordPrompt && !showClientLogin && !showClientRegister && (
              <div className="mt-8 text-center border-t border-slate-800 pt-6">
                <p className="text-sm text-slate-400 mb-3">Pelanggan berdaftar?</p>
                <button 
                  onClick={() => setShowClientLogin(true)}
                  className="px-6 py-2 bg-slate-800 text-slate-300 rounded hover:bg-slate-700 transition-colors text-sm font-medium"
                >
                  Portal Pelanggan
                </button>
              </div>
            )}
          </div>`;

const fixedPart = `            ) : (
              <div className="text-center space-y-6 py-4">
                 <p className="text-slate-300 text-sm leading-relaxed mb-6">
                   Selamat datang ke Portal Pelanggan VRS Community.<br/>Sila log masuk atau daftar akaun baru.
                 </p>
                 <div className="flex flex-col gap-4">
                   <button onClick={() => setShowClientLogin(true)} className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                     Log Masuk Pelanggan
                   </button>
                   <button onClick={() => setShowClientRegister(true)} className="w-full py-3 px-4 bg-slate-800 border border-slate-700 text-slate-300 font-bold rounded shadow transition-colors hover:bg-slate-700">
                     Daftar Akaun Baru
                   </button>
                 </div>
              </div>
            )}
          </div>`;

code = code.replace(brokenPart, fixedPart);
fs.writeFileSync('src/components/Dashboard.tsx', code);
