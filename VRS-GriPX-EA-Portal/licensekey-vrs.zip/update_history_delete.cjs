const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add clearingHistory state
code = code.replace(
  "const [settingsLoading, setSettingsLoading] = useState(false);",
  "const [settingsLoading, setSettingsLoading] = useState(false);\n  const [clearingHistory, setClearingHistory] = useState(false);"
);

// 2. Add handleClearAllHistory function
const clearHistoryFn = `  const handleClearAllHistory = async () => {
    if (!window.confirm('Adakah anda pasti mahu memadam KESEMUA rekod sejarah untuk semua pelanggan? Tindakan ini tidak boleh dipulihkan.')) {
      return;
    }
    setClearingHistory(true);
    try {
      const snap = await getDocs(collection(db, 'licenseHistory'));
      let count = 0;
      snap.forEach((docSnap) => {
        deleteDoc(docSnap.ref);
        count++;
      });
      alert(\`Berjaya memadam \${count} rekod sejarah.\`);
    } catch (error: any) {
      alert('Ralat memadam sejarah: ' + error.message);
    }
    setClearingHistory(false);
  };
`;

code = code.replace(
  "const handleCopyCode = async () => {",
  clearHistoryFn + "\n  const handleCopyCode = async () => {"
);

// 3. Update UI
const oldHistoryUI = `<p className="text-xs text-slate-500 mt-1">Tempoh hari sebelum sejarah lesen klien dipadam secara automatik.</p>`;
const newHistoryUI = `<div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-slate-500">Tempoh hari sebelum sejarah lesen klien dipadam secara automatik.</p>
                    <button 
                      type="button" 
                      onClick={handleClearAllHistory} 
                      disabled={clearingHistory}
                      className="px-3 py-1.5 bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 hover:text-rose-400 text-xs font-bold rounded transition-colors whitespace-nowrap ml-4 disabled:opacity-50"
                    >
                      {clearingHistory ? 'Memadam...' : 'Padam Semua Sekarang'}
                    </button>
                  </div>`;

code = code.replace(oldHistoryUI, newHistoryUI);

fs.writeFileSync('src/components/Dashboard.tsx', code);
