const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Update State
code = code.replace(
  "const [eaDownloadLink, setEaDownloadLink] = useState('');\n  const [eaDescription, setEaDescription] = useState('');",
  "const [eaList, setEaList] = useState<{id: string, name: string, link: string, description: string}[]>([]);\n  const [selectedEaId, setSelectedEaId] = useState<string>('');"
);

// 2. Update Fetch
const fetchOld = `        if (data.eaDownloadLink) setEaDownloadLink(data.eaDownloadLink);
        if (data.eaDescription) setEaDescription(data.eaDescription);`;
const fetchNew = `        if (data.eaList) {
          setEaList(data.eaList);
          if (data.eaList.length > 0) setSelectedEaId(data.eaList[0].id);
        } else if (data.eaDownloadLink || data.eaDescription) {
          // Backward compatibility
          const fallback = [{
            id: 'default_ea',
            name: 'Main EA',
            link: data.eaDownloadLink || '',
            description: data.eaDescription || ''
          }];
          setEaList(fallback);
          setSelectedEaId('default_ea');
        }`;
code = code.replace(fetchOld, fetchNew);

// 3. Update Save
const saveOld = `        historyDays,
        eaDownloadLink,
        eaDescription,
        whatsappLink,`;
const saveNew = `        historyDays,
        eaList,
        whatsappLink,`;
code = code.replace(saveOld, saveNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
