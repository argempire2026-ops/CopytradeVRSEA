const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  /Alert\("License SAH, tetapi Nama Akaun MT5 anda \\(" \+ AccountInfoString\\(ACCOUNT_NAME\\) \+ "\\) TIDAK DIBENARKAN untuk license ini!"\\);/g,
  `if (!silent) Alert("License SAH, tetapi Nama Akaun MT5 anda (" + AccountInfoString(ACCOUNT_NAME) + ") TIDAK DIBENARKAN untuk license ini!");`
);

fs.writeFileSync('public/ea-code.txt', code);
