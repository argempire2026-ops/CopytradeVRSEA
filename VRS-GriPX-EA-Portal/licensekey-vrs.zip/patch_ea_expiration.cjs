const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

const oldBlock = `   if (g_is_expired) {
      Comment("STATUS: EA EXPIRED! Sila renew license anda.\\nSemua posisi ditutup dan sistem diberhentikan.");
      
      // Semak jika masih ada posisi / entry, close semuanya
      int B, S, BL, SL, BS, SS;
      COUNT_ORDERS(B, S, BL, SL, BS, SS, MAGIC_NUMBER);
      if (B > 0 || S > 0) {
         POSITIONS_CLOSE(-1);
      }
      return; // Berhenti pelaksanaan EA (tiada entry baru)
   }`;

const newBlock = `   if (g_is_expired) {
      Comment("STATUS: EA EXPIRED! Sila renew license anda.\\nPosisi sedia ada diuruskan untuk Close Profit.\\nEntry awal baru telah diberhentikan.");
      
      int B, S, BL, SL, BS, SS;
      COUNT_ORDERS(B, S, BL, SL, BS, SS, MAGIC_NUMBER);
      if (B == 0 && S == 0) {
         return; // Berhenti pelaksanaan EA sepenuhnya jika tiada entry
      }
      // Biarkan pelaksanaan diteruskan supaya Trailing Stop, TP, dan Grid berjalan.
   }`;

code = code.replace(oldBlock, newBlock);

// Also need to set is_news_blocked = true
code = code.replace(
  "is_news_blocked = CheckNewsBlock();",
  "is_news_blocked = CheckNewsBlock();\n   if (g_is_expired) is_news_blocked = true; // Paksa block entry baru jika expired"
);

// We also need to fix the Alert message inside real-time check
const oldAlert = `Alert("License anda telah TAMAT TEMPOH (" + g_license_expiry + ")! EA sedang menutup semua posisi entry...");`;
const newAlert = `Alert("License anda telah TAMAT TEMPOH (" + g_license_expiry + ")! EA tidak akan buka entry baru, posisi sedia ada dibiarkan close profit.");`;
code = code.replace(oldAlert, newAlert);

// Fix the OnInit Alert message
const oldOnInitAlert = `Alert("License anda telah TAMAT TEMPOH pada " + displayDate + "! EA akan close semua entry dan berhenti beroperasi.");`;
const newOnInitAlert = `Alert("License anda telah TAMAT TEMPOH pada " + displayDate + "! EA hanya akan menguruskan posisi sedia ada untuk close profit.");`;
code = code.replace(oldOnInitAlert, newOnInitAlert);

fs.writeFileSync('public/ea-code.txt', code);
