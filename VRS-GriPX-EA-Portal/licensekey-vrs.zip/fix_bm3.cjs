const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

code = code.replace(/SEMAKAN NAMA AKAUN/gi, 'MT5 ACCOUNT NAME CHECK');
code = code.replace(/status license tidak diketahui\. Sila hubungi admin\./gi, 'unknown license status. Please contact admin.');
code = code.replace(/Menyemak sistem Firebase License\.\.\./gi, 'Checking Firebase License system...');
code = code.replace(/Posisi sedia ada diuruskan untuk Close Profit\./gi, 'Existing positions managed for Close Profit.');
code = code.replace(/Entry awal baru telah diberhentikan\./gi, 'New entry has been stopped.');

fs.writeFileSync('src/eaCode.ts', code);
