const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Replace top-level flex to be column on mobile, row on desktop
code = code.replace(
  '<div className="h-screen w-full bg-[#F1F5F9] text-slate-900 font-sans flex overflow-hidden">',
  '<div className="h-screen w-full bg-[#F1F5F9] text-slate-900 font-sans flex flex-col md:flex-row overflow-hidden">'
);

// Update aside
const oldAside = `<aside className="w-64 bg-[#0F172A] text-slate-300 flex flex-col border-r border-slate-200 shrink-0">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-500 rounded flex items-center justify-center text-white font-bold text-xl">K</div>
            <h1 className="text-white font-bold tracking-tight text-lg">KEYFORGE.IO</h1>
          </div>
          <p className="text-[10px] uppercase tracking-widest mt-2 text-slate-500 font-semibold">License Management</p>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <div 
            onClick={() => setActiveTab('keys')}
            className={\`flex items-center gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors \${activeTab === 'keys' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Key className="w-4 h-4" />
            <span className="text-sm font-medium">Product Keys</span>
          </div>
          <div 
            onClick={() => setActiveTab('ea')}
            className={\`flex items-center gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors \${activeTab === 'ea' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Code className="w-4 h-4" />
            <span className="text-sm font-medium">EA Code Source</span>
          </div>
          <div 
            onClick={() => setActiveTab('html')}
            className={\`flex items-center gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors \${activeTab === 'html' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Code className="w-4 h-4" />
            <span className="text-sm font-medium">Web HTML Source</span>
          </div>
        </nav>
        <div className="p-4 border-t border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-3 justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white overflow-hidden">
                {user.photoURL ? <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : 'AD'}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-white leading-tight truncate w-32">{user.displayName || 'Admin'}</p>
                <p className="text-[10px] text-emerald-400">Connected</p>
              </div>
            </div>
            <button 
              onClick={() => signOut(auth)}
              className="text-slate-400 hover:text-white transition-colors"
              title="Sign Out"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            </button>
          </div>
        </div>
      </aside>`;

const newAside = `<aside className="w-full md:w-64 bg-[#0F172A] text-slate-300 flex flex-col border-b md:border-b-0 md:border-r border-slate-200 shrink-0 z-20">
        <div className="p-4 md:p-6 border-b border-slate-800 flex justify-between items-center md:block">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 md:w-8 md:h-8 bg-indigo-500 rounded flex items-center justify-center text-white font-bold text-sm md:text-xl">K</div>
              <h1 className="text-white font-bold tracking-tight text-base md:text-lg">KEYFORGE.IO</h1>
            </div>
            <p className="hidden md:block text-[10px] uppercase tracking-widest mt-2 text-slate-500 font-semibold">License Management</p>
          </div>
          
          <div className="md:hidden flex items-center gap-3">
             <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white overflow-hidden border border-slate-600">
                {user.photoURL ? <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : 'AD'}
              </div>
             <button onClick={() => signOut(auth)} className="text-slate-400 hover:text-white p-1" title="Sign Out">
                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
             </button>
          </div>
        </div>
        <nav className="flex md:flex-col p-2 md:p-4 gap-2 overflow-x-auto md:overflow-visible hide-scrollbar">
          <div 
            onClick={() => setActiveTab('keys')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'keys' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Key className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Product Keys</span>
          </div>
          <div 
            onClick={() => setActiveTab('ea')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'ea' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Code className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">EA Code Source</span>
          </div>
          <div 
            onClick={() => setActiveTab('html')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'html' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Code className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Web HTML Source</span>
          </div>
        </nav>
        <div className="hidden md:block p-4 border-t border-slate-800 bg-slate-900/50 mt-auto">
          <div className="flex items-center gap-3 justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white overflow-hidden">
                {user.photoURL ? <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : 'AD'}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-white leading-tight truncate w-32">{user.displayName || 'Admin'}</p>
                <p className="text-[10px] text-emerald-400">Connected</p>
              </div>
            </div>
            <button 
              onClick={() => signOut(auth)}
              className="text-slate-400 hover:text-white transition-colors"
              title="Sign Out"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            </button>
          </div>
        </div>
      </aside>`;

code = code.replace(oldAside, newAside);

// Header padding
code = code.replace(
  '<header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">',
  '<header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 md:px-8 shrink-0">'
);

// Main content padding
code = code.replace(
  '<div className="p-8 flex flex-col gap-6 flex-1 overflow-auto">',
  '<div className="p-4 md:p-8 flex flex-col gap-4 md:gap-6 flex-1 overflow-auto">'
);

// Form flex changes
code = code.replace(
  '<form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-4 items-end">',
  '<form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-3 md:gap-4 items-stretch sm:items-end">'
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
