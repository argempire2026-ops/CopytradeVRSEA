const fs = require('fs');
const eaCode = fs.readFileSync('public/ea-code.txt', 'utf-8');
const content = `export const EA_CODE = ${JSON.stringify(eaCode)};\n`;
fs.writeFileSync('src/eaCode.ts', content);
