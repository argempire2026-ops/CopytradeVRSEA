const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "const q = query(collection(db, 'licenseKeys'), where('ownerUid', '==', currentUser.uid));",
  "const q = query(collection(db, 'licenseKeys'));"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
