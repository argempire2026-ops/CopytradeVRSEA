const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/password: '\{t\[lang\]\.passwordPlaceholder\}',/g, "password: 'Kata Laluan',");

fs.writeFileSync('src/components/Dashboard.tsx', code);
