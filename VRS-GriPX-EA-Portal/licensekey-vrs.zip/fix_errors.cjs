const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const tReplaceEn = `
    removeEa: 'Remove',
    selectEa: 'Select EA to view details',
    downloadNow: 'Download Now',
    linkNotProvided: 'Link Not Provided',
    noEaProvided: 'No EA provided at this time.',
    noDescription: 'No description provided by Admin at this time.',
    clientLogin: 'Client Login',
    registeredEmailPlaceholder: 'Registered Email',
    passwordPlaceholder: 'Password',
    loginBtn: 'Login',
    welcomeMsg: 'Welcome to VRS Community Client Portal.\\nPlease log in or register a new account.',
    registerNewAccount: 'Register New Account',
    backBtn: 'Back',
    clientRegister: 'Client Registration',
    adminAccess: 'Admin Access',
    invalidPassword: 'Invalid Password',
    accountNotFound: 'Account not found.',
    incorrectPassword: 'Incorrect password.',
    systemError: 'System error.',
    errorDeletingHistory: 'Error deleting history: '
  },`;

const tReplaceMs = `
    removeEa: 'Buang',
    selectEa: 'Pilih EA untuk lihat butiran',
    downloadNow: 'Muat Turun Sekarang',
    linkNotProvided: 'Link Belum Disediakan',
    noEaProvided: 'Tiada EA disediakan buat masa ini.',
    noDescription: 'Tiada keterangan disediakan oleh Admin buat masa ini.',
    clientLogin: 'Log Masuk Pelanggan',
    registeredEmailPlaceholder: 'E-mel Mendaftar',
    passwordPlaceholder: 'Kata Laluan',
    loginBtn: 'Log Masuk',
    welcomeMsg: 'Selamat datang ke Portal Pelanggan VRS Community.\\nSila log masuk atau daftar akaun baru.',
    registerNewAccount: 'Daftar Akaun Baru',
    backBtn: 'Kembali',
    clientRegister: 'Pendaftaran Pelanggan',
    adminAccess: 'Akses Admin',
    invalidPassword: 'Kata Laluan Tidak Sah',
    accountNotFound: 'Akaun tidak dijumpai.',
    incorrectPassword: 'Kata laluan salah.',
    systemError: 'Ralat sistem.',
    errorDeletingHistory: 'Ralat memadam sejarah: '
  }
};`;

code = code.replace(/removeEa: 'Remove',\n\s*selectEa: 'Select EA to view details',[\s\S]*?invalidPassword: 'Invalid Password'\n\s*},\n/m, tReplaceEn + '\n');
code = code.replace(/removeEa: 'Buang',\n\s*selectEa: 'Pilih EA untuk lihat butiran',[\s\S]*?invalidPassword: 'Kata Laluan Tidak Sah'\n\s*}\n};\n/m, tReplaceMs + '\n');

code = code.replace(/setClientLoginError\('Akaun tidak dijumpai\.'\);/g, "setClientLoginError(t[lang].accountNotFound);");
code = code.replace(/setClientLoginError\('Kata laluan salah\.'\);/g, "setClientLoginError(t[lang].incorrectPassword);");
code = code.replace(/setClientLoginError\('Ralat sistem\.'\);/g, "setClientLoginError(t[lang].systemError);");
code = code.replace(/alert\('Ralat memadam sejarah: ' \+ error\.message\);/g, "alert(t[lang].errorDeletingHistory + error.message);");

fs.writeFileSync('src/components/Dashboard.tsx', code);
