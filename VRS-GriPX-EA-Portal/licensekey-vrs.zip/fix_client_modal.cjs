const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldModal = `{showEaModal && (
              <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-slate-200">Muat Turun EA</h3>
                  </div>
                  <div className="p-6">
                    <p className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed mb-8">
                      {eaDescription || 'Tiada keterangan disediakan oleh Admin buat masa ini.'}
                    </p>
                    <div className="flex gap-4">
                      {eaDownloadLink ? (
                        <a 
                          href={eaDownloadLink}
                          target="_blank"
                          rel="noreferrer"
                          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded-lg transition-colors"
                        >
                          <Download className="w-4 h-4" /> Muat Turun Sekarang
                        </a>
                      ) : (
                        <button disabled className="flex-1 px-4 py-3 bg-slate-800 text-slate-500 font-bold rounded-lg cursor-not-allowed">
                          Link Belum Disediakan
                        </button>
                      )}
                      <button 
                        onClick={() => setShowEaModal(false)}
                        className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors"
                      >
                        Tutup
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}`;

const newModal = `{showEaModal && (
              <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-slate-200">{t[lang].downloadEA}</h3>
                  </div>
                  <div className="p-6">
                    {eaList.length > 0 ? (
                      <>
                        <div className="mb-4">
                          <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t[lang].selectEa}</label>
                          <select 
                            value={selectedEaId}
                            onChange={(e) => setSelectedEaId(e.target.value)}
                            className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                          >
                            {eaList.map(ea => (
                              <option key={ea.id} value={ea.id}>{ea.name}</option>
                            ))}
                          </select>
                        </div>
                        {eaList.find(ea => ea.id === selectedEaId) && (
                          <>
                            <div className="p-4 bg-[#0B132B] rounded-lg border border-slate-800 mb-8 max-h-48 overflow-y-auto">
                              <p className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed">
                                {eaList.find(ea => ea.id === selectedEaId)?.description || 'Tiada keterangan disediakan oleh Admin buat masa ini.'}
                              </p>
                            </div>
                            <div className="flex gap-4">
                              {eaList.find(ea => ea.id === selectedEaId)?.link ? (
                                <a 
                                  href={eaList.find(ea => ea.id === selectedEaId)?.link}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded-lg transition-colors"
                                >
                                  <Download className="w-4 h-4" /> Muat Turun Sekarang
                                </a>
                              ) : (
                                <button disabled className="flex-1 px-4 py-3 bg-slate-800 text-slate-500 font-bold rounded-lg cursor-not-allowed">
                                  Link Belum Disediakan
                                </button>
                              )}
                              <button 
                                onClick={() => setShowEaModal(false)}
                                className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors"
                              >
                                {t[lang].close}
                              </button>
                            </div>
                          </>
                        )}
                      </>
                    ) : (
                      <div className="text-center py-6">
                        <p className="text-slate-400 mb-6">Tiada EA disediakan buat masa ini.</p>
                        <button 
                          onClick={() => setShowEaModal(false)}
                          className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors"
                        >
                          {t[lang].close}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}`;

code = code.replace(oldModal, newModal);
fs.writeFileSync('src/components/Dashboard.tsx', code);
