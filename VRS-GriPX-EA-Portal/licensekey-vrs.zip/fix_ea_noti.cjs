const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The notification string to add
const notiLogic = `
   if (MQID_NOTI != "") {
      string expireStr = TimeToString(g_license_expiry_time, TIME_DATE);
      SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\\nLicense expires on: " + expireStr);
   }
`;

// Remove the previously incorrectly inserted blocks first if any exist
code = code.replace(/\n   if \(MQID_NOTI != ""\) \{\n      string expireStr = TimeToString\(g_license_expiry_time, TIME_DATE\);\n      SendNotification\("VRS-GriPX EA has been successfully attached and activated on " \+ _Symbol \+ "!\\\\nLicense expires on: " \+ expireStr\);\n   \}/g, '');

// Find OnInit and insert the notification right before `Comment("");` and `return(INIT_SUCCEEDED);`
const onInitStart = code.indexOf('int OnInit()');
if (onInitStart !== -1) {
    const onInitEnd = code.indexOf('return(INIT_SUCCEEDED);', onInitStart);
    if (onInitEnd !== -1) {
        // Find the last Comment(""); before return(INIT_SUCCEEDED);
        const commentIdx = code.lastIndexOf('Comment("");', onInitEnd);
        if (commentIdx !== -1 && commentIdx > onInitStart) {
            code = code.substring(0, commentIdx) + notiLogic + '\n   ' + code.substring(commentIdx);
            fs.writeFileSync('src/eaCode.ts', code);
            console.log('Successfully injected logic.');
        } else {
            console.log('Could not find Comment("");');
        }
    } else {
        console.log('Could not find return(INIT_SUCCEEDED);');
    }
} else {
    console.log('Could not find int OnInit()');
}
