const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const replacements = [
  ['placeholder="Contoh: 30"', 'placeholder="e.g. 30"'],
  ['placeholder="Contoh: https://chat.whatsapp.com/..."', 'placeholder="e.g. https://chat.whatsapp.com/..."'],
  ['placeholder="Contoh: https://youtube.com/..."', 'placeholder="e.g. https://youtube.com/..."'],
  ['Pautan Langganan / Renew Link', 'Subscription / Renew Link'],
  ['placeholder="Contoh: https://toyyibpay.com/..."', 'placeholder="e.g. https://toyyibpay.com/..."'],
  ['Pautan ini akan dipaparkan di portal pelanggan jika mereka sudah menebus Free Trial.', 'This link will be displayed on the client portal if they have already claimed the Free Trial.'],
  ['E-mel Pelanggan', 'Client Email'],
  ['setClientRegError(\'E-mel ini telah didaftarkan.\')', 'setClientRegError(\'This email has already been registered.\')'],
  ['Akses Ditolak: E-mel [', 'Access Denied: Email ['],
  ['] tiada dalam senarai Team Access.\\n\\nSila hubungi Admin untuk mendapatkan akses.', '] is not in the Team Access list.\\n\\nPlease contact the Admin to get access.'],
  ['Tiada lesen dijumpai.', 'No licenses found.'],
  ['Tiada EA ditambah.', 'No EA added.'],
  ['placeholder="Cari emel / nama / kunci..."', 'placeholder="Search email / name / key..."'],
  ['Pendaftaran hanya dibenarkan menggunakan akaun Gmail (@gmail.com).', 'Registration is only allowed using a Gmail account (@gmail.com).'],
  ['Kata laluan Admin salah.', 'Incorrect Admin password.'],
  ['alert("Password salah.");', 'alert("Incorrect password.");'],
  ['Daftar Akaun', 'Register Account'],
  ['<Plus className="w-4 h-4" /> Daftar', '<Plus className="w-4 h-4" /> Register'],
  ['placeholder="E-mel Anda"', 'placeholder="Your Email"'],
];

replacements.forEach(([oldStr, newStr]) => {
  if (code.includes(oldStr)) {
    code = code.split(oldStr).join(newStr);
  } else {
    console.log("NOT FOUND:", oldStr);
  }
});

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log("Done");
