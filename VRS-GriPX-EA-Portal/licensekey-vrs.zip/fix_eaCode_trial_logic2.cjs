const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const regex = /if \(StringFind\(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"active\\\\\\"\\"\) > 0\) \\n        \{\\n            \/\/ Check for expiration date/;

const newCheck = `if (StringFind(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"active\\\\\\"\\") > 0) \\n        {\\n            if (StringFind(resultStr, \\"\\\\\\"isTrial\\\\\\":{\\\\\\"booleanValue\\\\\\":true}\\") > 0 || StringFind(licenseKey, \\"TRIAL-\\") == 0) {\\n                g_is_trial = true;\\n            } else {\\n                g_is_trial = false;\\n            }\\n            \\n            // Check for expiration date`;

if (regex.test(code)) {
    code = code.replace(regex, newCheck);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Replaced logic successfully!");
} else {
    console.log("Could not find the check logic string via regex.");
}
