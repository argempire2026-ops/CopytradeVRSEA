const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/settingsLoading \? settingsLoading \? t\[lang\].saving : t\[lang\].saveSettings}/g, 'settingsLoading ? t[lang].saving : t[lang].saveSettings}');

fs.writeFileSync('src/components/Dashboard.tsx', code);
