const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

let lines = code.split('\\n');
for(let i=0; i<lines.length; i++) {
   if(lines[i].includes('g_is_trial')) {
      console.log("Line " + (i+1) + ": " + lines[i]);
   }
}
