const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Add translation keys
const tReplaceEn = `
    removeEa: 'Remove',
    selectEa: 'Select EA to view details',
    downloadNow: 'Download Now',
    linkNotProvided: 'Link Not Provided',
    noEaProvided: 'No EA provided at this time.',
    noDescription: 'No description provided by Admin at this time.'
  },`;

const tReplaceMs = `
    removeEa: 'Buang',
    selectEa: 'Pilih EA untuk lihat butiran',
    downloadNow: 'Muat Turun Sekarang',
    linkNotProvided: 'Link Belum Disediakan',
    noEaProvided: 'Tiada EA disediakan buat masa ini.',
    noDescription: 'Tiada keterangan disediakan oleh Admin buat masa ini.'
  }
};`;

code = code.replace(/removeEa: 'Remove',\n\s*selectEa: 'Select EA to view details'\n\s*},\n/m, tReplaceEn + '\n');
code = code.replace(/removeEa: 'Buang',\n\s*selectEa: 'Pilih EA untuk lihat butiran'\n\s*}\n};\n/m, tReplaceMs + '\n');

// Replace hardcoded strings
code = code.replace(/<Download className="w-4 h-4" \/> Muat Turun Sekarang/g, '<Download className="w-4 h-4" /> {t[lang].downloadNow}');
code = code.replace(/>\s*Link Belum Disediakan\s*<\/button>/g, '>{t[lang].linkNotProvided}</button>');
code = code.replace(/Tiada keterangan disediakan oleh Admin buat masa ini\./g, '{t[lang].noDescription}');
code = code.replace(/Tiada EA disediakan buat masa ini\./g, '{t[lang].noEaProvided}');

fs.writeFileSync('src/components/Dashboard.tsx', code);
