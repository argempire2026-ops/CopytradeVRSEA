const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldRenderError = `{trialResult.error ? (
                  <p className="text-red-500 font-medium">{trialResult.error}</p>
                ) : (`;

const newRenderError = `{trialResult.error ? (
                  <>
                    <p className="text-red-500 font-medium mb-4">{trialResult.error}</p>
                    <button onClick={() => setTrialResult(null)} className="text-[#D4AF37] text-sm hover:underline">Kembali</button>
                  </>
                ) : (`;

code = code.replace(oldRenderError, newRenderError);
fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Fixed render error');
