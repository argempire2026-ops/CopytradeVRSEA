const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add logHistory
const logHistoryFn = `  const logHistory = async (email: string, keyStr: string, action: string, reason: string) => {
    try {
      await addDoc(collection(db, 'licenseHistory'), {
        clientEmail: email,
        key: keyStr,
        action,
        reason,
        timestamp: serverTimestamp()
      });
    } catch (e) {
      console.error('Failed to log history', e);
    }
  };
`;

code = code.replace("export default function Dashboard() {", "export default function Dashboard() {\n" + logHistoryFn);

// 2. Fix the error about \`id\` on handleToggleStatus
code = code.replace("handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${id}\`);", "handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${k.id}\`);");

fs.writeFileSync('src/components/Dashboard.tsx', code);
