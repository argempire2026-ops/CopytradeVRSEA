const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const logHistoryOld = `  const logHistory = async (email: string, keyStr: string, action: string, reason: string) => {
    try {
      await addDoc(collection(db, 'licenseHistory'), {
        clientEmail: email,`;

const logHistoryNew = `  const logHistory = async (email: string, keyStr: string, action: string, reason: string) => {
    try {
      await addDoc(collection(db, 'licenseHistory'), {
        clientEmail: email.toLowerCase().trim(),`;

code = code.replace(logHistoryOld, logHistoryNew);

const createKeyOld = `      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: customerEmail.trim(),`;

const createKeyNew = `      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: customerEmail.toLowerCase().trim(),`;

code = code.replace(createKeyOld, createKeyNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
