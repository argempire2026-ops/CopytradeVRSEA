const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add states
code = code.replace(
  "const [clients, setClients] = useState<any[]>([]);",
  "const [clients, setClients] = useState<any[]>([]);\n  const [deleteConfirm, setDeleteConfirm] = useState<{type: 'client'|'key', id: string} | null>(null);\n  const [deletePasswordInput, setDeletePasswordInput] = useState('');"
);

// 2. Replace handleDeleteClient
const oldHandleDeleteClient = `  const handleDeleteClient = async (email: string) => {
    try {
      await deleteDoc(doc(db, 'clients', email));
    } catch (err: any) {
      alert('Gagal padam akaun: ' + err.message);
    }
  };`;

const newHandleDeleteClient = `  const handleDeleteClient = (email: string) => {
    setDeleteConfirm({ type: 'client', id: email });
  };`;

code = code.replace(oldHandleDeleteClient, newHandleDeleteClient);

// 3. Replace handleDelete
const oldHandleDelete = `  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'licenseKeys', id));
    } catch (error) {
      alert(\`Failed to delete key: \${error instanceof Error ? error.message : 'Unknown error'}\`);
      handleFirestoreError(error, OperationType.DELETE, \`licenseKeys/\${id}\`);
    }
  };`;

const newHandleDelete = `  const handleDelete = (id: string) => {
    setDeleteConfirm({ type: 'key', id: id });
  };`;

code = code.replace(oldHandleDelete, newHandleDelete);

// 4. Add executeDelete near handleLogoClick
const executeDeleteFunc = `  const executeDelete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (deletePasswordInput !== "VRS123") {
      alert("Kata laluan Admin salah.");
      setDeletePasswordInput('');
      return;
    }
    
    if (!deleteConfirm) return;
    
    try {
      if (deleteConfirm.type === 'client') {
        await deleteDoc(doc(db, 'clients', deleteConfirm.id));
      } else if (deleteConfirm.type === 'key') {
        await deleteDoc(doc(db, 'licenseKeys', deleteConfirm.id));
      }
      setDeleteConfirm(null);
      setDeletePasswordInput('');
    } catch (error: any) {
      alert('Gagal padam: ' + error.message);
    }
  };

  const handleLogoClick`;

code = code.replace("  const handleLogoClick", executeDeleteFunc);

// 5. Add Delete Modal
const deleteModal = `        {deleteConfirm && (
          <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
            <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-lg max-w-sm w-full p-6">
              <h3 className="text-lg font-bold text-rose-500 mb-2">Pengesahan Padam</h3>
              <p className="text-sm text-slate-400 mb-4">Adakah anda pasti untuk padam {deleteConfirm.type === 'client' ? 'akaun pelanggan' : 'lesen'} ini? Sila masukkan kata laluan admin untuk sahkan.</p>
              
              <form onSubmit={executeDelete} className="space-y-4">
                <div>
                  <input
                    type="password"
                    value={deletePasswordInput}
                    onChange={(e) => setDeletePasswordInput(e.target.value)}
                    placeholder="Kata Laluan Admin"
                    className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-colors outline-none text-white placeholder:text-slate-500"
                    autoFocus
                    required
                  />
                </div>
                
                <div className="flex justify-end gap-3 pt-2">
                  <button 
                    type="button"
                    onClick={() => {
                      setDeleteConfirm(null);
                      setDeletePasswordInput('');
                    }}
                    className="px-4 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 rounded"
                  >
                    Batal
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-2 text-sm font-bold bg-rose-600 hover:bg-rose-500 text-white rounded transition-colors"
                  >
                    Sah & Padam
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </main>
    </div>
  );`;

code = code.replace("      </main>\n    </div>\n  );", deleteModal);

fs.writeFileSync('src/components/Dashboard.tsx', code);
