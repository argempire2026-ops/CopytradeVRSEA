const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldCatch = `          } catch (e) {
            alert('Akses Ditolak: E-mel anda tiada dalam senarai Team Access.');
            await auth.signOut();
            setUser(null);
            setKeys([]);
            setLoading(true);
            setShowAdminLogin(false);
          }`;

const newCatch = `          } catch (e) {
            alert('Akses Ditolak: E-mel [' + (currentUser.email || '') + '] tiada dalam senarai Team Access.\\n\\nSila hubungi Admin untuk mendapatkan akses.');
            await auth.signOut();
            setUser(null);
            setKeys([]);
            setLoading(true);
          }`;

code = code.replace(oldCatch, newCatch);
fs.writeFileSync('src/components/Dashboard.tsx', code);
