const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');
code = code.replace(
  /fetch\('\/dashboard-export\.html\?v=' \+ new Date\(\)\.getTime\(\)\)[\s\S]*?\.catch\(err => console\.error\("Failed to load HTML code", err\)\);/,
  ""
);
fs.writeFileSync('src/components/Dashboard.tsx', code);
