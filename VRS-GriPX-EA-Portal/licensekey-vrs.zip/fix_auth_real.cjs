const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Find the start of the useEffect block for auth
const startMatch = "  useEffect(() => {\n    // Wait for auth to initialize before fetching data\n    const unsubscribeAuth = auth.onAuthStateChanged(";
const startIndex = code.indexOf(startMatch);

if (startIndex === -1) {
    console.error("Could not find start match");
    process.exit(1);
}

// Find the end of the block which is the next useEffect
const endMatch = "  useEffect(() => {\n    if (user && user.email === 'mfrdotbiz@gmail.com') {";
const endIndex = code.indexOf(endMatch, startIndex);

if (endIndex === -1) {
    console.error("Could not find end match");
    process.exit(1);
}

const oldBlock = code.substring(startIndex, endIndex);

const newBlock = `  useEffect(() => {
    let unsubscribeSnapshot = null;
    
    const unsubscribeAuth = auth.onAuthStateChanged(async (currentUser) => {
      if (currentUser) {
        // Validate admin access
        if (currentUser.email === 'mfrdotbiz@gmail.com') {
          setUser(currentUser);
          subscribeToKeys();
        } else {
          try {
            const adminDoc = await getDoc(doc(db, 'admins', currentUser.email || ''));
            if (adminDoc.exists()) {
              setUser(currentUser);
              subscribeToKeys();
            } else {
              throw new Error('Not admin');
            }
          } catch (e) {
            alert('Akses Ditolak: E-mel [' + (currentUser.email || '') + '] tiada dalam senarai Team Access.\\n\\nSila hubungi Admin untuk mendapatkan akses.');
            await auth.signOut();
            setUser(null);
            setKeys([]);
            setLoading(true);
          }
        }
      } else {
        setUser(null);
        setKeys([]);
        setLoading(true);
        if (unsubscribeSnapshot) unsubscribeSnapshot();
      }
    });

    const subscribeToKeys = () => {
      const q = query(collection(db, 'licenseKeys'));
      unsubscribeSnapshot = onSnapshot(q, (snapshot) => {
        const now = new Date();
        const keysData = [];
        
        snapshot.docs.forEach(document => {
          const data = document.data();
          const keyId = document.id;
          
          if (data.expiresAt && new Date(data.expiresAt) < now) {
            deleteDoc(doc(db, 'licenseKeys', keyId)).catch(console.error);
          } else {
            keysData.push({
              ...data,
              id: keyId,
              createdAt: data.createdAt?.toDate() || new Date()
            });
          }
        });
        
        // Sort client-side to avoid needing an index right away
        keysData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        
        setKeys(keysData);
        setLoading(false);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'licenseKeys');
        setLoading(false);
      });
    };

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

`;

code = code.replace(oldBlock, newBlock);
fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log("Successfully replaced");
