const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const oldCheck = '        if (StringFind(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"active\\\\\\"\\") > 0)\\n        {\\n            // Check for expiration date';

const newCheck = `        if (StringFind(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"active\\\\\\"\\") > 0)
        {
            if (StringFind(resultStr, \\"\\\\\\"isTrial\\\\\\":{\\\\\\"booleanValue\\\\\\":true}\\") > 0 || StringFind(licenseKey, \\"TRIAL-\\") == 0) {
                g_is_trial = true;
            } else {
                g_is_trial = false;
            }
            
            // Check for expiration date`.replace(/\n/g, '\\n');

if (code.includes(oldCheck)) {
    code = code.replace(oldCheck, newCheck);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Replaced logic successfully!");
} else {
    console.log("Could not find the check logic string.");
}
