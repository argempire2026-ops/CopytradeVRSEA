const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const oldExpired = `        else if (StringFind(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"expired\\\\\\"\\") > 0) \\n        {\\n            Alert(\\"License anda telah TAMAT TEMPOH (Expired)!\\");\\n            return false;\\n        }`;

const newExpired = `        else if (StringFind(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"expired\\\\\\"\\") > 0) \\n        {\\n            Alert(\\"License anda telah TAMAT TEMPOH (Expired)! Posisi sedia ada diuruskan untuk Close Profit.\\");\\n            g_is_expired = true;\\n            return true;\\n        }`;

// We will use regex just in case there are spacing differences
const expiredRegex = /else if \(StringFind\(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"expired\\\\\\"\\"\) > 0\) \\n        \{\\n            Alert\(\\"License anda telah TAMAT TEMPOH \(Expired\)!\\"\);\\n            return false;\\n        \}/;

if (expiredRegex.test(code)) {
    code = code.replace(expiredRegex, newExpired);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Fixed expired logic!");
} else {
    console.log("Could not find expired logic with regex.");
}
