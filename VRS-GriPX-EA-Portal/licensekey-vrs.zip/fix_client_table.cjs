const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add handleUpdateClientMaxTrials function
const functionToAdd = `
  const handleUpdateClientMaxTrials = async (clientId: string, maxTrials: number) => {
    try {
      if (isNaN(maxTrials)) return;
      await updateDoc(doc(db, 'clients', clientId), {
        maxTrials: maxTrials
      });
    } catch (err: any) {
      alert('Failed to update max trials: ' + err.message);
    }
  };
`;
code = code.replace(
  "const handleCreateClient = async (e: React.FormEvent) => {",
  functionToAdd + "\n  const handleCreateClient = async (e: React.FormEvent) => {"
);

// 2. Update the clients table
const tableOld = `<th className="px-6 py-3 whitespace-nowrap">Nama</th>
                        <th className="px-6 py-3 whitespace-nowrap">E-mel</th>
                        <th className="px-6 py-3 whitespace-nowrap">{t.passwordPlaceholder}</th>
                        <th className="px-6 py-3 whitespace-nowrap text-right">{t.actions}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clients.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-6 py-8 text-center text-slate-400 text-xs font-medium">
                            Tiada pelanggan berdaftar.
                          </td>
                        </tr>
                      ) : (
                        clients.map(client => (
                          <tr key={client.id} className="hover:bg-[#050914]">
                            <td className="px-6 py-4 text-sm font-medium text-slate-200">{client.name}</td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-400">{client.email}</td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded font-mono text-xs">{client.password}</span>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button onClick={() => handleDeleteClient(client.email)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-500/10 rounded transition-colors" title="Delete Account">`;

const tableNew = `<th className="px-6 py-3 whitespace-nowrap">Name</th>
                        <th className="px-6 py-3 whitespace-nowrap">Email</th>
                        <th className="px-6 py-3 whitespace-nowrap">{t.passwordPlaceholder}</th>
                        <th className="px-6 py-3 whitespace-nowrap">Max Trials</th>
                        <th className="px-6 py-3 whitespace-nowrap text-right">{t.actions}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clients.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-8 text-center text-slate-400 text-xs font-medium">
                            No registered clients.
                          </td>
                        </tr>
                      ) : (
                        clients.map(client => (
                          <tr key={client.id} className="hover:bg-[#050914]">
                            <td className="px-6 py-4 text-sm font-medium text-slate-200">{client.name}</td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-400">{client.email}</td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded font-mono text-xs">{client.password}</span>
                            </td>
                            <td className="px-6 py-4">
                              <input 
                                type="number" 
                                min="0"
                                defaultValue={client.maxTrials !== undefined ? client.maxTrials : defaultMaxTrials} 
                                onBlur={(e) => handleUpdateClientMaxTrials(client.id, parseInt(e.target.value))}
                                className="w-16 p-1 bg-slate-800 border border-slate-700 rounded text-slate-300 text-xs text-center" 
                              />
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button onClick={() => handleDeleteClient(client.email)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-500/10 rounded transition-colors" title="Delete Account">`;

code = code.replace(tableOld, tableNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
