const admin = require('firebase-admin');
const fs = require('fs');
const blueprint = JSON.parse(fs.readFileSync('firebase-blueprint.json'));
const sa = require(blueprint.firebaseAdminServiceAccountKeyPath);

admin.initializeApp({
  credential: admin.credential.cert(sa)
});

const db = admin.firestore();
db.settings({ databaseId: 'ai-studio-245cc25a-6f6b-40e7-ad09-9650e6274c82' });

async function run() {
  const snapshot = await db.collection('licenseKeys').limit(1).get();
  if (snapshot.empty) {
    console.log("No keys found.");
  } else {
    snapshot.forEach(doc => {
      console.log("KEY_ID:", doc.id);
    });
  }
}
run();
