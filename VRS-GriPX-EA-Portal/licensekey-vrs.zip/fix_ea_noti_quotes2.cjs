const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// I will look for SendNotification("VRS-GriPX EA
// and replace it with SendNotification(\"VRS-GriPX EA
// using split and join to avoid regex backslash interpolation.

const wrongStr1 = 'SendNotification(\\"VRS-GriPX EA has been successfully attached and activated on \\" + _Symbol + \\"!\\\\nLicense expires on: \\" + expireStr);';
const wrongStr2 = 'SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\\nLicense expires on: " + expireStr);';

// What we want inside eaCode.ts (so that when Vite bundles it as a JS string, it's valid):
// SendNotification(\"VRS-GriPX EA has been successfully attached and activated on \" + _Symbol + \"!\\nLicense expires on: \" + expireStr);
const correctStr = 'SendNotification(\\"VRS-GriPX EA has been successfully attached and activated on \\" + _Symbol + \\"!\\\\nLicense expires on: \\" + expireStr);';

code = code.split(wrongStr1).join(correctStr);
code = code.split(wrongStr2).join(correctStr);

fs.writeFileSync('src/eaCode.ts', code);
console.log('Fixed EA code');
