const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  /const handleRenew = async \(id: string, newDate: string\) => {[\s\S]*?handleFirestoreError\(error, OperationType\.UPDATE, `licenseKeys\/\$\{id\}`\);\n    }\n  };/,
  `const handleRenew = async (id: string, newDate: string, newAllowedAccounts: string = '') => {
    try {
      const updates: any = { status: 'active' };
      if (newDate.trim() === '') { 
        updates.expiresAt = deleteField();
      } else { 
        updates.expiresAt = newDate.trim();
      }
      if (newAllowedAccounts.trim() === '') {
        updates.allowedAccounts = deleteField();
      } else {
        updates.allowedAccounts = newAllowedAccounts.trim();
      }
      await updateDoc(doc(db, 'licenseKeys', id), updates);
      setRenewKey(null);
      alert('License updated successfully!');
    } catch (error) {
      alert(\`Failed to update: \${error instanceof Error ? error.message : 'Unknown error'}\`);
      handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${id}\`);
    }
  };`
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
