const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/'Diperbaharui', 'Maklumat \/ tarikh luput lesen dikemas kini\.'/g, "'Renewed', 'License information / expiry date updated.'");
code = code.replace(/1 Bulan \(\+ dari hari ini\)/g, "1 Month (+ from today)");
code = code.replace(/3 Bulan \(\+ dari hari ini\)/g, "3 Months (+ from today)");
code = code.replace(/6 Bulan \(\+ dari hari ini\)/g, "6 Months (+ from today)");
code = code.replace(/1 Tahun \(\+ dari hari ini\)/g, "1 Year (+ from today)");
code = code.replace(/Tindakan ini akan memadam KESEMUA rekod License History & Status untuk SEMUA pelanggan\. Tindakan ini tidak boleh dipulihkan\./g, "This action will delete ALL License History & Status records for ALL clients. This action cannot be undone.");


fs.writeFileSync('src/components/Dashboard.tsx', code);
