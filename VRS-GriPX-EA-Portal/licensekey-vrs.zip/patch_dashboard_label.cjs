const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  '<label className="block text-sm font-medium text-slate-700 mb-1">Nombor Akaun MT5</label>',
  '<label className="block text-sm font-medium text-slate-700 mb-1">Nama Penuh Berdaftar Dengan Broker</label>'
);

code = code.replace(
  'placeholder="Contoh: 12345678"',
  'placeholder="Contoh: MUHAMAD FAAIZ..."'
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
