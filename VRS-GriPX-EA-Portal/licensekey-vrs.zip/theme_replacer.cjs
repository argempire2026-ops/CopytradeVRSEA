const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Replace Main Wrappers
code = code.replace(/bg-\[\#F1F5F9\] text-slate-900/g, 'bg-[#0B132B] text-slate-200');
code = code.replace(/bg-\[\#F1F5F9\]/g, 'bg-[#0B132B]');
code = code.replace(/bg-white/g, 'bg-[#131E3A]');

// Sidebar & Header Borders
code = code.replace(/border-slate-200/g, 'border-slate-800');
code = code.replace(/border-slate-100/g, 'border-slate-800/50');
code = code.replace(/border-b md:border-b-0 md:border-r border-slate-200/g, 'border-b md:border-b-0 md:border-r border-slate-800');

// Header Text & Backgrounds
code = code.replace(/bg-slate-50\/50/g, 'bg-[#0A1024]');
code = code.replace(/bg-slate-50/g, 'bg-[#050914]');
code = code.replace(/bg-slate-100/g, 'bg-slate-800');

// Text Colors
code = code.replace(/text-slate-900/g, 'text-white');
code = code.replace(/text-slate-800/g, 'text-slate-200');
code = code.replace(/text-slate-600/g, 'text-slate-400');
code = code.replace(/text-slate-500/g, 'text-slate-400');
code = code.replace(/text-indigo-600/g, 'text-[#D4AF37]');
code = code.replace(/text-indigo-700/g, 'text-[#F1C40F]');

// Buttons & Accents (Indigo -> Gold)
// Note: Some buttons have text-white, we want text-slate-900 for dark text on gold button
code = code.replace(/bg-indigo-600 hover:bg-indigo-700 text-white/g, 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900');
code = code.replace(/bg-indigo-600 hover:bg-indigo-500 text-white/g, 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900');
code = code.replace(/bg-indigo-600 text-white/g, 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md');

// Focus Rings
code = code.replace(/focus:ring-indigo-500/g, 'focus:ring-[#D4AF37]');
code = code.replace(/focus:border-indigo-500/g, 'focus:border-[#D4AF37]');

// Status Badges
code = code.replace(/bg-emerald-100 text-emerald-800/g, 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30');
code = code.replace(/bg-rose-100 text-rose-800/g, 'bg-rose-500/20 text-rose-400 border border-rose-500/30');

// Admin Panel Borders
code = code.replace(/border-indigo-200/g, 'border-[#D4AF37]/50');

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Replacements complete');
