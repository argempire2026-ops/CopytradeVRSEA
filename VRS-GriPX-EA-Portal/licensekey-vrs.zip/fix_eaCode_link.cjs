const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf8');

const targetUrl = "https://t.me/TeamVRS";
const newUrl = "https://chat.whatsapp.com/J5qaR7JZdNaAp4PwWPiYSf";

if (code.includes(targetUrl)) {
    code = code.split(targetUrl).join(newUrl);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Successfully updated URLs in src/eaCode.ts");
} else {
    console.log("Could not find the target URL.");
}
