const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The file should be wrapped in backticks or we need to escape the newlines.
// It's probably easier to just replace actual newlines inside the string with \n
const parts = code.split('export const EA_CODE = "');
if (parts.length > 1) {
    let eaString = parts[1];
    // Remove the trailing "; or ";\n
    eaString = eaString.substring(0, eaString.lastIndexOf('"'));
    
    // Replace all literal newlines with \n
    eaString = eaString.replace(/\r?\n/g, '\\n');
    
    // Write it back
    fs.writeFileSync('src/eaCode.ts', 'export const EA_CODE = "' + eaString + '";\n');
}
