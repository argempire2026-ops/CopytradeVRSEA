const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldClaim = `  const handleClaimTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialMt5.trim()) return;
    
    setTrialLoading(true);
    setTrialResult(null);
    try {
      // Create a 1 day expiry
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const expiryStr = tomorrow.toISOString(); // e.g. "2026-09-03T14:15:00.000Z"
      
      const generatedKey = 'TRIAL-' + generateRandomKey().substring(0, 8);
      
      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: 'trial@auto',
        customerName: 'Trial MT5: ' + trialMt5.trim(),
        allowedAccounts: trialMt5.trim(),
        status: 'active',
        ownerUid: 'system_trial', // No specific user
        createdAt: serverTimestamp(),
        expiresAt: expiryStr,
        isTrial: true
      };

      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      
      setTrialResult({ key: generatedKey });
      setTrialMt5('');
    } catch (err: any) {
      console.error(err);
      setTrialResult({ key: '', error: 'Gagal menjana key. Sila cuba lagi.' });
    } finally {
      setTrialLoading(false);
    }
  };`;

const newClaim = `  const handleClaimTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialMt5.trim()) return;
    
    setTrialLoading(true);
    setTrialResult(null);
    try {
      // Check if trial already exists for this account
      const q = query(collection(db, 'licenseKeys'), where('allowedAccounts', '==', trialMt5.trim()));
      const querySnapshot = await getDocs(q);
      
      let existingActive = null;
      let existingExpired = null;
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        if (data.isTrial || data.customerEmail === 'trial@auto') {
          const isExpired = data.expiresAt && new Date(data.expiresAt) <= new Date();
          if (!isExpired && data.status !== 'revoked') {
            existingActive = data;
          } else {
            existingExpired = data;
          }
        }
      });
      
      if (existingActive) {
        setTrialResult({ key: existingActive.key, expiresAt: existingActive.expiresAt, existing: true });
        setTrialLoading(false);
        return;
      }
      
      if (existingExpired) {
        setTrialResult({ key: '', error: 'Maaf, akaun ini telah menggunakan kemudahan Trial sebelum ini dan ia telah tamat tempoh.' });
        setTrialLoading(false);
        return;
      }

      // Create a 1 day expiry
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const expiryStr = tomorrow.toISOString(); // e.g. "2026-09-03T14:15:00.000Z"
      
      const generatedKey = 'TRIAL-' + generateRandomKey().substring(0, 8);
      
      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: 'trial@auto',
        customerName: 'Trial MT5: ' + trialMt5.trim(),
        allowedAccounts: trialMt5.trim(),
        status: 'active',
        ownerUid: 'system_trial', // No specific user
        createdAt: serverTimestamp(),
        expiresAt: expiryStr,
        isTrial: true
      };

      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      
      setTrialResult({ key: generatedKey, expiresAt: expiryStr });
      setTrialMt5('');
    } catch (err: any) {
      console.error(err);
      setTrialResult({ key: '', error: 'Gagal menjana key. Sila cuba lagi.' });
    } finally {
      setTrialLoading(false);
    }
  };`;

if(code.includes('const handleClaimTrial = async (e: React.FormEvent) => {')) {
    code = code.replace(oldClaim, newClaim);
    fs.writeFileSync('src/components/Dashboard.tsx', code);
    console.log("Updated handleClaimTrial");
} else {
    console.log("Could not find handleClaimTrial block");
}
