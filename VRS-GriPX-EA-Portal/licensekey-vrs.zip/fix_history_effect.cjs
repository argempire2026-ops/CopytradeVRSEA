const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldEffect = `  useEffect(() => {
    if (clientUser) {
      const q = query(collection(db, 'licenseKeys'), where('customerEmail', '==', clientUser.email));
      const unsub = onSnapshot(q, (snapshot) => {
        const data: any[] = [];
        snapshot.forEach(d => data.push({ id: d.id, ...d.data() }));
        setClientKeys(data);
      });

      const hq = query(collection(db, 'licenseHistory'), where('clientEmail', '==', clientUser.email.toLowerCase().trim()));
      const unsubHistory = onSnapshot(hq, (snapshot) => {
        const historyList: any[] = [];
        const now = new Date();
        const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
        
        snapshot.forEach(docSnap => {
          const data = docSnap.data();
          const docTime = data.timestamp?.toDate() || new Date();
          
          if (now.getTime() - docTime.getTime() > thirtyDaysMs) {
            deleteDoc(docSnap.ref).catch(console.error);
          } else {
            historyList.push({ id: docSnap.id, ...data });
          }
        });
        historyList.sort((a, b) => (b.timestamp?.toMillis() || 0) - (a.timestamp?.toMillis() || 0));
        setClientHistory(historyList);
      });

      return () => { unsub(); unsubHistory(); };
    }
  }, [clientUser]);`;

const newEffect = `  useEffect(() => {
    if (clientUser) {
      const q = query(collection(db, 'licenseKeys'), where('customerEmail', '==', clientUser.email));
      const unsub = onSnapshot(q, (snapshot) => {
        const data: any[] = [];
        snapshot.forEach(d => data.push({ id: d.id, ...d.data() }));
        setClientKeys(data);
      });

      const hq = query(collection(db, 'licenseHistory'), where('clientEmail', '==', clientUser.email.toLowerCase().trim()));
      const unsubHistory = onSnapshot(hq, (snapshot) => {
        const historyList: any[] = [];
        const now = new Date();
        const expiryMs = (historyDays || 30) * 24 * 60 * 60 * 1000;
        
        snapshot.forEach(docSnap => {
          const data = docSnap.data();
          const docTime = data.timestamp?.toDate() || new Date();
          
          if (now.getTime() - docTime.getTime() > expiryMs) {
            deleteDoc(docSnap.ref).catch(console.error);
          } else {
            historyList.push({ id: docSnap.id, ...data });
          }
        });
        historyList.sort((a, b) => (b.timestamp?.toMillis() || 0) - (a.timestamp?.toMillis() || 0));
        setClientHistory(historyList);
      });

      return () => { unsub(); unsubHistory(); };
    }
  }, [clientUser, historyDays]);`;

code = code.replace(oldEffect, newEffect);
fs.writeFileSync('src/components/Dashboard.tsx', code);
