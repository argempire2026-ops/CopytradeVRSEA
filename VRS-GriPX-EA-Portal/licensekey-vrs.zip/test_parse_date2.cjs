const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');
let parseCode = code.match(/if \\(StringFind\\(resultStr, \\\\\\"stringValue\\\\\\":\\\\\\"active\\\\\\"\\) > 0\\).*?ObjectSetString/s);
if (parseCode) {
    console.log(parseCode[0].substring(0, 1500));
} else {
    console.log("Not found");
}
