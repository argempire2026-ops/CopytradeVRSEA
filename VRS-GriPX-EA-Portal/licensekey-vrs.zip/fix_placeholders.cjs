const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/placeholder="\{t\[lang\]\.passwordPlaceholder\}"/g, 'placeholder={t[lang].passwordPlaceholder}');
code = code.replace(/placeholder="\{t\[lang\]\.registeredEmailPlaceholder\}"/g, 'placeholder={t[lang].registeredEmailPlaceholder}');
code = code.replace(/placeholder="\{t\[lang\]\.passwordPlaceholder\} Admin"/g, 'placeholder={`${t[lang].passwordPlaceholder} Admin`}');

fs.writeFileSync('src/components/Dashboard.tsx', code);
