const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The file might contain literal `\"` if it was escaped inside `export const EA_CODE = "...";`
code = code.replace(/\\"Allow WebRequest\\"/g, "'Allow WebRequest'");
code = code.replace(/"Allow WebRequest"/g, "'Allow WebRequest'");

fs.writeFileSync('src/eaCode.ts', code);
console.log('Fixed EA code');
