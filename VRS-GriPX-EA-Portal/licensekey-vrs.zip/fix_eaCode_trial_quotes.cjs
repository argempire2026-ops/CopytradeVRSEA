const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

code = code.replace(/\\\\"License Expiry: \\\\"/g, '\\"License Expiry: \\"');
code = code.replace(/\\\\"TRIAL LICENSE - Expiry: \\\\"/g, '\\"TRIAL LICENSE - Expiry: \\"');
code = code.replace(/\\\\"VRS_UI_License_Lbl\\\\"/g, '\\"VRS_UI_License_Lbl\\"');

fs.writeFileSync('src/eaCode.ts', code);
