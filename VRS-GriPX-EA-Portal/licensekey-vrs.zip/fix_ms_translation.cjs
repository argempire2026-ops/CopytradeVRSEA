const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldMsEnd = `    removeEa: 'Buang',
    selectEa: 'Pilih EA untuk lihat butiran',
    downloadNow: 'Muat Turun Sekarang',
    linkNotProvided: 'Link Belum Disediakan',
    noEaProvided: '{t[lang].noEaProvided}',
    noDescription: '{t[lang].noDescription}'
  }
};`;

const newMsEnd = `    removeEa: 'Buang',
    selectEa: 'Pilih EA untuk lihat butiran',
    downloadNow: 'Muat Turun Sekarang',
    linkNotProvided: 'Link Belum Disediakan',
    noEaProvided: 'Tiada EA disediakan buat masa ini.',
    noDescription: 'Tiada keterangan disediakan oleh Admin buat masa ini.',
    clientLogin: 'Log Masuk Pelanggan',
    registeredEmailPlaceholder: 'E-mel Mendaftar',
    passwordPlaceholder: 'Kata Laluan',
    loginBtn: 'Log Masuk',
    welcomeMsg: 'Selamat datang ke Portal Pelanggan VRS Community.\\nSila log masuk atau daftar akaun baru.',
    registerNewAccount: 'Daftar Akaun Baru',
    backBtn: 'Kembali',
    clientRegister: 'Pendaftaran Pelanggan',
    adminAccess: 'Akses Admin',
    invalidPassword: 'Kata Laluan Tidak Sah'
  }
};`;

code = code.replace(oldMsEnd, newMsEnd);

fs.writeFileSync('src/components/Dashboard.tsx', code);
