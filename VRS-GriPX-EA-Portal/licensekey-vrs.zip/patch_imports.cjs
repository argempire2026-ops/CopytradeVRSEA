const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const oldLucide = "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download, Users } from 'lucide-react';";
const newLucide = "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download, Users, Lock, UserPlus } from 'lucide-react';\nimport { motion } from 'motion/react';";

if (code.includes(oldLucide)) {
    code = code.replace(oldLucide, newLucide);
    fs.writeFileSync('src/components/Dashboard.tsx', code);
    console.log("Imports updated successfully.");
} else {
    console.log("Could not find lucide imports.");
}
