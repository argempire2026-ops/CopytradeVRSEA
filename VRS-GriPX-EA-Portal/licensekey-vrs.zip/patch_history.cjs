const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. imports
code = code.replace("getDocs,  addDoc", "getDocs, getDoc, addDoc");

// 2. add logHistory
const logHistoryFn = `
  const logHistory = async (email: string, keyStr: string, action: string, reason: string) => {
    try {
      await addDoc(collection(db, 'licenseHistory'), {
        clientEmail: email,
        key: keyStr,
        action,
        reason,
        timestamp: serverTimestamp()
      });
    } catch (e) {
      console.error('Failed to log history', e);
    }
  };
`;
code = code.replace("const Dashboard = () => {", "const Dashboard = () => {\n" + logHistoryFn);

// 3. state for clientHistory
code = code.replace("const [clientKeys, setClientKeys] = useState<any[]>([]);", "const [clientKeys, setClientKeys] = useState<any[]>([]);\n  const [clientHistory, setClientHistory] = useState<any[]>([]);");

// 4. fetch clientHistory & cleanup
const fetchClientKeysOld = `      const q = query(collection(db, 'licenseKeys'), where('customerEmail', '==', clientUser.email));
      const unsub = onSnapshot(q, (snapshot) => {
        const keys: any[] = [];
        snapshot.forEach(docSnap => {
          keys.push({ id: docSnap.id, ...docSnap.data() });
        });
        setClientKeys(keys);
      });
      return () => unsub();`;
const fetchClientKeysNew = `      const q = query(collection(db, 'licenseKeys'), where('customerEmail', '==', clientUser.email));
      const unsub = onSnapshot(q, (snapshot) => {
        const keys: any[] = [];
        snapshot.forEach(docSnap => {
          keys.push({ id: docSnap.id, ...docSnap.data() });
        });
        setClientKeys(keys);
      });

      const hq = query(collection(db, 'licenseHistory'), where('clientEmail', '==', clientUser.email));
      const unsubHistory = onSnapshot(hq, (snapshot) => {
        const historyList: any[] = [];
        const now = new Date();
        const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
        
        snapshot.forEach(docSnap => {
          const data = docSnap.data();
          const docTime = data.timestamp?.toDate() || new Date();
          
          if (now.getTime() - docTime.getTime() > thirtyDaysMs) {
            deleteDoc(docSnap.ref).catch(console.error);
          } else {
            historyList.push({ id: docSnap.id, ...data });
          }
        });
        historyList.sort((a, b) => (b.timestamp?.toMillis() || 0) - (a.timestamp?.toMillis() || 0));
        setClientHistory(historyList);
      });

      return () => { unsub(); unsubHistory(); };`;
code = code.replace(fetchClientKeysOld, fetchClientKeysNew);

// 5. Update renewKey state & usage
code = code.replace(
  "const [renewKey, setRenewKey] = useState<{id: string, expiry: string, allowedAccounts?: string} | null>(null);",
  "const [renewKey, setRenewKey] = useState<{id: string, expiry: string, allowedAccounts?: string, email?: string, keyString?: string} | null>(null);"
);
code = code.replace(
  "onClick={() => setRenewKey({id: k.id, expiry: k.expiresAt || '', allowedAccounts: k.allowedAccounts || ''})}",
  "onClick={() => setRenewKey({id: k.id, expiry: k.expiresAt || '', allowedAccounts: k.allowedAccounts || '', email: k.customerEmail, keyString: k.key})}"
);

// 6. Update executeDelete
const executeDeleteOld = `      if (deleteConfirm.type === 'client') {
        await deleteDoc(doc(db, 'clients', deleteConfirm.id));
      } else if (deleteConfirm.type === 'key') {
        await deleteDoc(doc(db, 'licenseKeys', deleteConfirm.id));
      }`;
const executeDeleteNew = `      if (deleteConfirm.type === 'client') {
        await deleteDoc(doc(db, 'clients', deleteConfirm.id));
      } else if (deleteConfirm.type === 'key') {
        const keyRef = doc(db, 'licenseKeys', deleteConfirm.id);
        const keySnap = await getDoc(keyRef);
        if (keySnap.exists()) {
          const data = keySnap.data();
          await logHistory(data.customerEmail, data.key, 'Dipadam', 'Lesen telah dipadam oleh Admin.');
        }
        await deleteDoc(keyRef);
      }`;
code = code.replace(executeDeleteOld, executeDeleteNew);

// 7. Update handleToggleStatus
const toggleStatusOld = `  const handleToggleStatus = async (id: string, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'active' ? 'revoked' : 'active';
      await updateDoc(doc(db, 'licenseKeys', id), { status: newStatus });
    } catch (error) {`;
const toggleStatusNew = `  const handleToggleStatus = async (k: any) => {
    try {
      const newStatus = k.status === 'active' ? 'revoked' : 'active';
      await updateDoc(doc(db, 'licenseKeys', k.id), { status: newStatus });
      await logHistory(k.customerEmail, k.key, newStatus === 'active' ? 'Diaktifkan Semula' : 'Dibatalkan', newStatus === 'active' ? 'Lesen telah diaktifkan semula.' : 'Lesen dibatalkan oleh Admin.');
    } catch (error) {`;
code = code.replace(toggleStatusOld, toggleStatusNew);
code = code.replace("onClick={() => handleToggleStatus(k.id, k.status)}", "onClick={() => handleToggleStatus(k)}");

// 8. Update handleRenew
const renewOld = `      await updateDoc(doc(db, 'licenseKeys', id), updates);
      setRenewKey(null);
      alert('License updated successfully!');`;
const renewNew = `      await updateDoc(doc(db, 'licenseKeys', id), updates);
      if (renewKey?.email && renewKey?.keyString) {
        await logHistory(renewKey.email, renewKey.keyString, 'Diperbaharui', 'Maklumat / tarikh luput lesen dikemas kini.');
      }
      setRenewKey(null);
      alert('License updated successfully!');`;
code = code.replace(renewOld, renewNew);

// 9. Update handleCreate
const createOld = `      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      
      setCustomerEmail('');`;
const createNew = `      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      await logHistory(customerEmail.trim(), generatedKey, 'Dicipta', 'Lesen baru telah dijana.');
      
      setCustomerEmail('');`;
code = code.replace(createOld, createNew);

// 10. Update handleClaimTrial
const trialOld = `      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      await updateDoc(doc(db, 'clients', clientUser.email), { trialCount: currentTrialCount + 1 });
      
      setClientUser({ ...clientUser, trialCount: currentTrialCount + 1 });`;
const trialNew = `      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      await logHistory(clientUser.email, generatedKey, 'Trial', 'Berjaya tuntut Free Trial 1 Hari.');
      await updateDoc(doc(db, 'clients', clientUser.email), { trialCount: currentTrialCount + 1 });
      
      setClientUser({ ...clientUser, trialCount: currentTrialCount + 1 });`;
code = code.replace(trialOld, trialNew);

// 11. UI in Client Portal for History
const clientPortalUINew = `            </div>
            
            <h2 className="text-xl font-bold text-slate-200 mb-6 mt-8">Sejarah & Status Lesen (30 Hari)</h2>
            <div className="bg-[#131E3A] rounded-xl shadow-lg border border-slate-800 overflow-hidden mb-12">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-3 whitespace-nowrap">Tarikh/Masa</th>
                      <th className="px-6 py-3 whitespace-nowrap">License Key</th>
                      <th className="px-6 py-3 whitespace-nowrap">Tindakan</th>
                      <th className="px-6 py-3">Catatan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {clientHistory.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-slate-400">
                          <p className="text-sm font-semibold text-slate-700">Tiada rekod sejarah dalam masa 30 hari.</p>
                        </td>
                      </tr>
                    ) : (
                      clientHistory.map(h => (
                        <tr key={h.id} className="hover:bg-[#050914]">
                          <td className="px-6 py-4 text-xs text-slate-400 whitespace-nowrap">
                            {h.timestamp ? h.timestamp.toDate().toLocaleString('ms-MY') : '-'}
                          </td>
                          <td className="px-6 py-4 font-mono text-xs text-slate-300">{h.key}</td>
                          <td className="px-6 py-4">
                            <span className={\`inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider 
                              \${h.action === 'Dicipta' || h.action === 'Trial' || h.action === 'Diaktifkan Semula' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 
                                h.action === 'Diperbaharui' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 
                                'bg-rose-500/20 text-rose-400 border border-rose-500/30'}\`}>
                              {h.action}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-xs text-slate-400">{h.reason}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </main>
        </div>
      );`;

code = code.replace("            </div>\n          </main>\n        </div>\n      );", clientPortalUINew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
