const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const tReplaceEn = `
    totalLicenses: 'Total Licenses',
    actions: 'Actions',
    addEa: 'Add New EA',
    eaName: 'EA Name',
    removeEa: 'Remove',
    selectEa: 'Select EA to view details'
  },`;

const tReplaceMs = `
    totalLicenses: 'Jumlah Lesen',
    actions: 'Tindakan',
    addEa: 'Tambah EA Baru',
    eaName: 'Nama EA',
    removeEa: 'Buang',
    selectEa: 'Pilih EA untuk lihat butiran'
  }
};`;

code = code.replace(/totalLicenses: 'Total Licenses',\n\s*actions: 'Actions'\n\s*},\n/m, tReplaceEn + '\n');
code = code.replace(/totalLicenses: 'Jumlah Lesen',\n\s*actions: 'Tindakan'\n\s*}\n};\n/m, tReplaceMs + '\n');

fs.writeFileSync('src/components/Dashboard.tsx', code);
