const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const targetIndex = code.indexOf(') : (\n              <div className="text-center space-y-6 py-4">');

if (targetIndex !== -1) {
    const endStr = '      </div>\n    );\n  }';
    const endIndex = code.indexOf(endStr, targetIndex);
    
    if (endIndex !== -1) {
        const fullEndIndex = endIndex + endStr.length;
        const oldSection = code.substring(targetIndex, fullEndIndex);
        
        const newSection = `) : (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="text-center space-y-6 py-4"
              >
                 <p className="text-slate-300 text-sm leading-relaxed mb-6">
                   {t.welcomeMsg.split('\\n').map((line, i) => <React.Fragment key={i}>{line}<br/></React.Fragment>)}
                 </p>
                 <div className="flex flex-col gap-4">
                   <button 
                     onClick={() => setShowClientLogin(true)} 
                     className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden"
                   >
                     <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                     <Lock size={18} className="text-slate-800" />
                     {t.clientLogin}
                   </button>
                   <button 
                     onClick={() => setShowClientRegister(true)} 
                     className="w-full py-3.5 px-4 bg-slate-800/80 backdrop-blur-sm border border-slate-700/50 text-slate-300 font-bold rounded-lg shadow-lg transition-all hover:bg-slate-700 hover:text-white hover:border-slate-500 hover:shadow-[0_4px_14px_0_rgba(255,255,255,0.05)] flex items-center justify-center gap-2"
                   >
                     <UserPlus size={18} />
                     {t.registerNewAccount}
                   </button>
                 </div>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    );
  }`;

        code = code.replace(oldSection, newSection);
        fs.writeFileSync('src/components/Dashboard.tsx', code);
        console.log("Buttons block updated successfully using indexOf.");
    } else {
        console.log("Could not find endIndex.");
    }
} else {
    console.log("Could not find targetIndex.");
}
