const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// Replace all occurrences of "bool g_is_trial = false;"
code = code.replace(/bool g_is_trial = false;/g, '');
// And then add it back right after "bool g_is_expired = false;" once
code = code.replace(/bool g_is_expired = false;/g, 'bool g_is_expired = false;\\nbool g_is_trial = false;');

fs.writeFileSync('src/eaCode.ts', code);
