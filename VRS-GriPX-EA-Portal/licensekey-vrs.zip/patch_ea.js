const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// 1. Add input string MQID
const licenseInputRegex = /input string\s+USER_LICENSE_KEY\s*=\s*"ENTER_YOUR_KEY_HERE";/;
code = code.replace(licenseInputRegex, `input string             USER_LICENSE_KEY = "ENTER_YOUR_KEY_HERE";
input string             MQID_NOTI        = ""; // Enter MQID for Notifications (Optional)`);

// 2. Add license expiry notification
const mytNowRegex = /datetime myt_now = TimeGMT\(\) \+ \(Malaysia_GMT_Offset \* 3600\);/;
const licenseExpiryInjection = `datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
                        if (MQID_NOTI != "") {
                            int daysLeft = (int)((g_license_expiry_time - myt_now) / 86400);
                            if (daysLeft == 7 || daysLeft == 3) {
                                SendNotification("VRS Alert : License key expires in " + IntegerToString(daysLeft) + " days. Please contact admin to renew.");
                            }
                        }`;
code = code.replace(mytNowRegex, licenseExpiryInjection);

// 3. Add news notification
// First, add a global variable for tracking
const globalsRegex = /bool     is_news_blocked = false;/;
code = code.replace(globalsRegex, `bool     is_news_blocked = false;\nbool     last_news_blocked_state = false;`);

// Then find where OnTick is, or where we can inject the news check.
// Wait, `is_news_blocked` is updated in `OnTick()` or `OnTimer()`?
