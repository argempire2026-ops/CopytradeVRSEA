const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/Memproses\.\.\./g, "Processing...");
code = code.replace(/Tuntut Trial/g, "Claim Trial");
code = code.replace(/Nama MT5 \(Allowed\)/g, "MT5 Name (Allowed)");
code = code.replace(/>Tamat Tempoh</g, ">Expiry Date<");
code = code.replace(/Sejarah & Status Lesen/g, "License History & Status");
code = code.replace(/\(\{historyDays\} Hari\)/g, "({historyDays} Days)");
code = code.replace(/>Tarikh\/Masa</g, ">Date/Time<");
code = code.replace(/>Catatan</g, ">Remarks<");
code = code.replace(/Tiada rekod sejarah dalam masa \{historyDays\} hari\./g, "No history records within {historyDays} days.");
code = code.replace(/Tindakan ini akan memadam KESEMUA rekod Sejarah & Status Lesen untuk SEMUA pelanggan\. Tindakan ini tidak boleh dipulihkan\./g, "This action will delete ALL License History & Status records for ALL clients. This action cannot be undone.");

// Double check for any other 'Hari'
code = code.replace(/Hari\)/g, "Days)");
code = code.replace(/\(Hari\)/g, "(Days)");
code = code.replace(/\{historyDays\} hari\./g, "{historyDays} days.");
code = code.replace(/Tempoh hari sebelum sejarah lesen klien dipadam secara automatik\./g, "Number of days before client license history is automatically deleted.");


fs.writeFileSync('src/components/Dashboard.tsx', code);
