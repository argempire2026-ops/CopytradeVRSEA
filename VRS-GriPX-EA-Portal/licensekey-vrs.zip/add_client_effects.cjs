const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const newEffects = `  useEffect(() => {
    if (user) {
      const q = query(collection(db, 'clients'));
      const unsub = onSnapshot(q, (snapshot) => {
        const data: any[] = [];
        snapshot.forEach(d => data.push({ id: d.id, ...d.data() }));
        setClients(data);
      });
      return () => unsub();
    }
  }, [user]);

  useEffect(() => {
    if (clientUser) {
      const q = query(collection(db, 'licenseKeys'), where('customerEmail', '==', clientUser.email));
      const unsub = onSnapshot(q, (snapshot) => {
        const data: any[] = [];
        snapshot.forEach(d => data.push({ id: d.id, ...d.data() }));
        setClientKeys(data);
      });
      return () => unsub();
    }
  }, [clientUser]);

  const handleClientLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setClientLoginError('');
    try {
      const q = query(collection(db, 'clients'), where('email', '==', clientEmail.toLowerCase().trim()));
      const snap = await getDocs(q);
      if (snap.empty) {
        setClientLoginError('Akaun tidak dijumpai.');
        return;
      }
      
      let matchedClient = null;
      snap.forEach(docSnap => {
        if (docSnap.data().password === clientPassword) {
          matchedClient = docSnap.data();
        }
      });
      
      if (!matchedClient) {
        setClientLoginError('Kata laluan salah.');
        return;
      }
      
      setClientUser({ email: matchedClient.email, name: matchedClient.name });
    } catch (err) {
      setClientLoginError('Ralat sistem.');
      console.error(err);
    }
  };

  const handleCreateClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientEmail.trim() || !newClientPassword.trim()) return;
    try {
      const clientRef = doc(db, 'clients', newClientEmail.toLowerCase().trim());
      await setDoc(clientRef, {
        email: newClientEmail.toLowerCase().trim(),
        name: newClientName.trim(),
        password: newClientPassword,
        createdAt: serverTimestamp()
      });
      setNewClientEmail('');
      setNewClientName('');
      setNewClientPassword('');
      alert('Akaun pelanggan berjaya dicipta!');
    } catch (err: any) {
      alert('Gagal mencipta akaun: ' + err.message);
    }
  };

  const handleDeleteClient = async (email: string) => {
    try {
      await deleteDoc(doc(db, 'clients', email));
    } catch (err: any) {
      alert('Gagal padam akaun: ' + err.message);
    }
  };

  const handleLogoClick = () => {`;

code = code.replace("  const handleLogoClick = () => {", newEffects);
fs.writeFileSync('src/components/Dashboard.tsx', code);
