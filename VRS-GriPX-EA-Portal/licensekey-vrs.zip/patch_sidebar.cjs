const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy } from 'lucide-react';",
  "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download } from 'lucide-react';"
);

code = code.replace(
  '<span className="text-sm font-medium">EA Code Source</span>\n          </div>',
  '<span className="text-sm font-medium">EA Code Source</span>\n          </div>\n          <a \n            href="/dashboard-export.html" \n            download="Dashboard_App.html"\n            className="flex items-center gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors hover:bg-slate-800 text-slate-400 mt-4 border border-slate-700 hover:border-slate-600"\n          >\n            <Download className="w-4 h-4" />\n            <span className="text-sm font-medium">Download App HTML</span>\n          </a>'
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
