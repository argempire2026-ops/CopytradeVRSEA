const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const oldBlock = `    return (
      <div className="h-screen w-full bg-[#0B132B] flex items-center justify-center font-sans p-4">
        <div className="bg-[#131E3A] p-8 rounded-xl shadow-sm border border-slate-800 flex flex-col items-center max-w-sm w-full">
          <img 
            onClick={handleLogoClick} 
            src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" 
            alt="VRS Logo"
            className="w-20 h-20 rounded-2xl mb-4 cursor-pointer select-none object-cover"
          />
          <h1 className="text-2xl font-bold text-slate-200 mb-1 text-center">VRS (EXPERT ADVISOR)</h1>
          <p className="text-sm text-slate-400 text-center mb-6 font-medium">VRS Community</p>`;

const newBlock = `    return (
      <div className="h-screen w-full bg-[#0B132B] flex items-center justify-center font-sans p-4 relative overflow-hidden">
        {/* Animated Background Mesh */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-cyan-900/20 blur-[120px]"></div>
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-fuchsia-900/15 blur-[120px]"></div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="relative z-10 bg-[#131E3A]/70 backdrop-blur-xl p-8 rounded-2xl shadow-[0_8px_32px_0_rgba(0,255,200,0.05)] border border-white/10 flex flex-col items-center max-w-sm w-full"
        >
          <div className="relative mb-6 group">
            <div className="absolute inset-0 bg-cyan-500/30 blur-2xl rounded-full opacity-50 group-hover:opacity-80 transition-opacity duration-500"></div>
            <img 
              onClick={handleLogoClick} 
              src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" 
              alt="VRS Logo"
              className="relative z-10 w-24 h-24 rounded-2xl cursor-pointer select-none object-cover border border-white/20 shadow-2xl transition-transform hover:scale-105 duration-300"
            />
          </div>
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-100 to-slate-400 mb-1 text-center tracking-tight"
          >
            VRS (EXPERT ADVISOR)
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-xs text-cyan-400/80 text-center mb-6 font-semibold tracking-[0.2em] uppercase"
          >
            VRS Community
          </motion.p>`;

if (code.includes(oldBlock)) {
    code = code.replace(oldBlock, newBlock);
    fs.writeFileSync('src/components/Dashboard.tsx', code);
    console.log("Top block updated.");
} else {
    console.log("Old block not found.");
}
