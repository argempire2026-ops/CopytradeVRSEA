const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const search = 'attached and activated';
let pos = 0;
let first = true;
let count = 0;

let startIndex = -1;
let endIndex = -1;

while(true) {
   let idx = code.indexOf(search, pos);
   if(idx === -1) break;
   
   if (count === 1) { // Second occurrence
      // find the 'if' before this
      startIndex = code.lastIndexOf('if (MQID_NOTI != "")', idx);
      // find the '}' after this
      endIndex = code.indexOf('}', idx) + 1;
   }
   
   count++;
   pos = idx + 1;
}

if (startIndex !== -1 && endIndex !== -1) {
    code = code.substring(0, startIndex) + code.substring(endIndex);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log('Removed second occurrence.');
}
