const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const newStates = `  const [historyDays, setHistoryDays] = useState(30);
  const [eaDownloadLink, setEaDownloadLink] = useState('');
  const [eaDescription, setEaDescription] = useState('');
  const [whatsappLink, setWhatsappLink] = useState('');
  const [tutorialLink, setTutorialLink] = useState('');
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showEaModal, setShowEaModal] = useState(false);
`;

code = code.replace("  const [showClientLogin", newStates + "  const [showClientLogin");

const fetchSettings = `  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'general'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.historyDays) setHistoryDays(data.historyDays);
        if (data.eaDownloadLink) setEaDownloadLink(data.eaDownloadLink);
        if (data.eaDescription) setEaDescription(data.eaDescription);
        if (data.whatsappLink) setWhatsappLink(data.whatsappLink);
        if (data.tutorialLink) setTutorialLink(data.tutorialLink);
      }
    });
    return () => unsub();
  }, []);
`;

code = code.replace("  useEffect(() => {\n    if (user) {", fetchSettings + "\n  useEffect(() => {\n    if (user) {");

fs.writeFileSync('src/components/Dashboard.tsx', code);
