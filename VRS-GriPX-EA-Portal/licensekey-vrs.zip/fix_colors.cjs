const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/text-slate-700/g, 'text-slate-200');
code = code.replace(/bg-emerald-100 text-emerald-700/g, 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30');
code = code.replace(/bg-rose-100 text-rose-700/g, 'bg-rose-500/20 text-rose-400 border border-rose-500/30');

// also replace divide-slate-100 with divide-slate-800
code = code.replace(/divide-slate-100/g, 'divide-slate-800');

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Fixed colors');
