const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldAdminUI = `<div className="pt-4 border-t border-slate-800">
                  <h3 className="text-lg font-bold text-slate-200 mb-4">{t[lang].eaUpdate}</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t[lang].eaDownloadLink}</label>
                      <input
                        type="url"
                        value={eaDownloadLink}
                        onChange={(e) => setEaDownloadLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://drive.google.com/file/d/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t[lang].eaDesc}</label>
                      <textarea
                        value={eaDescription}
                        onChange={(e) => setEaDescription(e.target.value)}
                        rows={4}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Masukkan keterangan versi atau panduan ringkas..."
                      />
                    </div>
                  </div>
                </div>`;

const newAdminUI = `<div className="pt-4 border-t border-slate-800">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-slate-200">{t[lang].eaUpdate}</h3>
                    <button
                      type="button"
                      onClick={() => setEaList([...eaList, { id: 'ea_' + Date.now(), name: 'New EA', link: '', description: '' }])}
                      className="px-3 py-1.5 bg-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/30 text-xs font-bold rounded transition-colors"
                    >
                      + {t[lang].addEa}
                    </button>
                  </div>
                  <div className="space-y-6">
                    {eaList.map((ea, index) => (
                      <div key={ea.id} className="p-4 bg-[#050914] rounded-lg border border-slate-800 relative">
                        <button
                          type="button"
                          onClick={() => setEaList(eaList.filter((_, i) => i !== index))}
                          className="absolute top-2 right-2 text-rose-500 hover:text-rose-400 p-1"
                          title={t[lang].removeEa}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <div className="space-y-4 mt-2">
                          <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t[lang].eaName}</label>
                            <input
                              type="text"
                              value={ea.name}
                              onChange={(e) => {
                                const newList = [...eaList];
                                newList[index].name = e.target.value;
                                setEaList(newList);
                              }}
                              className="w-full bg-[#131E3A] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t[lang].eaDownloadLink}</label>
                            <input
                              type="url"
                              value={ea.link}
                              onChange={(e) => {
                                const newList = [...eaList];
                                newList[index].link = e.target.value;
                                setEaList(newList);
                              }}
                              className="w-full bg-[#131E3A] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t[lang].eaDesc}</label>
                            <textarea
                              value={ea.description}
                              onChange={(e) => {
                                const newList = [...eaList];
                                newList[index].description = e.target.value;
                                setEaList(newList);
                              }}
                              rows={3}
                              className="w-full bg-[#131E3A] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                    {eaList.length === 0 && (
                      <p className="text-sm text-slate-500 text-center py-4">Tiada EA ditambah.</p>
                    )}
                  </div>
                </div>`;

code = code.replace(oldAdminUI, newAdminUI);
fs.writeFileSync('src/components/Dashboard.tsx', code);
