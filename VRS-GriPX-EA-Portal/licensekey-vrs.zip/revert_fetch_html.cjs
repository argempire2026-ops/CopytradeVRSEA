const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');
code = code.replace(
  "setEaCode(EA_CODE);",
  "setEaCode(EA_CODE);\n    fetch('/dashboard-export.html?v=' + new Date().getTime()).then(res => res.text()).then(text => setHtmlCode(text)).catch(err => console.error(err));"
);
fs.writeFileSync('src/components/Dashboard.tsx', code);
