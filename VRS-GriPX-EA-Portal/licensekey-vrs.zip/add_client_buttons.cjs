const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const buttonsHtml = `<div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <button 
                onClick={() => setShowEaModal(true)}
                className="flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl font-bold shadow-lg transition-transform hover:-translate-y-1"
              >
                <Download className="w-5 h-5" /> Muat Turun EA
              </button>
              
              <a 
                href={whatsappLink || '#'} 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white rounded-xl font-bold shadow-lg transition-transform hover:-translate-y-1"
                onClick={(e) => { if (!whatsappLink) { e.preventDefault(); alert('Pautan belum dikemaskini oleh Admin.'); } }}
              >
                Join Group WhatsApp
              </a>

              <a 
                href={tutorialLink || '#'} 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white rounded-xl font-bold shadow-lg transition-transform hover:-translate-y-1"
                onClick={(e) => { if (!tutorialLink) { e.preventDefault(); alert('Pautan belum dikemaskini oleh Admin.'); } }}
              >
                Panduan Tutorial
              </a>
            </div>

            {showEaModal && (
              <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-slate-200">Muat Turun EA</h3>
                  </div>
                  <div className="p-6">
                    <p className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed mb-8">
                      {eaDescription || 'Tiada keterangan disediakan oleh Admin buat masa ini.'}
                    </p>
                    <div className="flex gap-4">
                      {eaDownloadLink ? (
                        <a 
                          href={eaDownloadLink}
                          target="_blank"
                          rel="noreferrer"
                          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded-lg transition-colors"
                        >
                          <Download className="w-4 h-4" /> Muat Turun Sekarang
                        </a>
                      ) : (
                        <button disabled className="flex-1 px-4 py-3 bg-slate-800 text-slate-500 font-bold rounded-lg cursor-not-allowed">
                          Link Belum Disediakan
                        </button>
                      )}
                      <button 
                        onClick={() => setShowEaModal(false)}
                        className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors"
                      >
                        Tutup
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}`;

code = code.replace(
  `<main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
            <div className="flex justify-between items-center mb-6">`,
  `<main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
            ${buttonsHtml}
            <div className="flex justify-between items-center mb-6">`
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
