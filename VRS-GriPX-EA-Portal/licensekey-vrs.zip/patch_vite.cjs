const fs = require('fs');
let code = fs.readFileSync('vite.config.ts', 'utf-8');

code = code.replace(
  "import {defineConfig} from 'vite';",
  "import {defineConfig} from 'vite';\nimport { viteSingleFile } from 'vite-plugin-singlefile';"
);

code = code.replace(
  "plugins: [react(), tailwindcss()],",
  "plugins: [react(), tailwindcss(), viteSingleFile()],"
);

fs.writeFileSync('vite.config.ts', code);
