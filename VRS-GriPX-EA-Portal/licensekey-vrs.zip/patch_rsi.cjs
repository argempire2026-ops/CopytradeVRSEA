const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

const oldRsi = `double GET_RSI_VALUE(int index = 1) {
   if(RSI_HANDLE == INVALID_HANDLE) return 0;
   double rsiArray[]; ArraySetAsSeries(rsiArray, true);
   if(CopyBuffer(RSI_HANDLE, 0, 0, index + 1, rsiArray) < 0) return 0;
   return NormalizeDouble(rsiArray[index], 2);
}`;

const newRsi = `double GET_RSI_VALUE(int index = 1) {
   if(RSI_HANDLE == INVALID_HANDLE) return 0;
   double rsiArray[]; 
   if(CopyBuffer(RSI_HANDLE, 0, 0, index + 1, rsiArray) < 0) return 0;
   ArraySetAsSeries(rsiArray, true); // Mesti set selepas CopyBuffer
   return NormalizeDouble(rsiArray[index], 2);
}`;

code = code.replace(oldRsi, newRsi);

fs.writeFileSync('public/ea-code.txt', code);
