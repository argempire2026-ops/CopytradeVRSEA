const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  /<Download className="w-5 h-5" \/> Muat Turun EA/g, 
  '<Download className="w-5 h-5" /> {t[lang].downloadEA}'
);

code = code.replace(
  />\s*Join Group WhatsApp\s*<\/a>/g, 
  '>{t[lang].joinWhatsapp}</a>'
);

code = code.replace(
  />\s*Panduan Tutorial\s*<\/a>/g, 
  '>{t[lang].tutorialGuide}</a>'
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
