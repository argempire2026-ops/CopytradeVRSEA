const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldLabel = '<h3 className="text-lg font-semibold text-slate-200 mb-4">{t.claimTrial}</h3>';
const newLabel = '<h3 className="text-lg font-semibold text-slate-200 mb-4">\n                {earlyBirdLimit > 0 && earlyBirdClaimed < earlyBirdLimit \n                  ? `Claim ${earlyBirdDays}-Day Free Trial (Early Bird Promo!)`\n                  : `Claim ${defaultTrialDays}-Day Free Trial`}\n              </h3>';

code = code.replace(oldLabel, newLabel);
fs.writeFileSync('src/components/Dashboard.tsx', code);
