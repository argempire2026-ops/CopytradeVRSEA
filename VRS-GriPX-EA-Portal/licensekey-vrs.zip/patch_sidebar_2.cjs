const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  '<a \n            href="/dashboard-export.html" \n            download="Dashboard_App.html"\n            className="flex items-center gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors hover:bg-slate-800 text-slate-400 mt-4 border border-slate-700 hover:border-slate-600"\n          >\n            <Download className="w-4 h-4" />\n            <span className="text-sm font-medium">Download App HTML</span>\n          </a>',
  '<div \n            onClick={() => setActiveTab(\'html\')}\n            className={`flex items-center gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors ${activeTab === \'html\' ? \'bg-indigo-600 text-white\' : \'hover:bg-slate-800 text-slate-400\'}`}\n          >\n            <Code className="w-4 h-4" />\n            <span className="text-sm font-medium">Web HTML Source</span>\n          </div>'
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
