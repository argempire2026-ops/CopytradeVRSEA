const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const settingsUI = `          ) : activeTab === 'settings' ? (
            <div className="flex-1 overflow-auto bg-[#131E3A] border border-slate-800 rounded-xl p-6 shadow-lg max-w-2xl mx-auto w-full mt-4">
              <h2 className="text-xl font-bold text-slate-200 mb-6">Tetapan Sistem</h2>
              <form onSubmit={handleSaveSettings} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Sejarah (Hari)</label>
                  <input
                    type="number"
                    value={historyDays}
                    onChange={(e) => setHistoryDays(Number(e.target.value))}
                    className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                    placeholder="Contoh: 30"
                  />
                  <p className="text-xs text-slate-500 mt-1">Tempoh hari sebelum sejarah lesen klien dipadam secara automatik.</p>
                </div>
                
                <div className="pt-4 border-t border-slate-800">
                  <h3 className="text-lg font-bold text-slate-200 mb-4">Kemaskini EA (Client Portal)</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Muat Turun EA</label>
                      <input
                        type="url"
                        value={eaDownloadLink}
                        onChange={(e) => setEaDownloadLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://drive.google.com/file/d/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Keterangan / Changelog EA</label>
                      <textarea
                        value={eaDescription}
                        onChange={(e) => setEaDescription(e.target.value)}
                        rows={4}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Masukkan keterangan versi atau panduan ringkas..."
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <h3 className="text-lg font-bold text-slate-200 mb-4">Pautan Luaran</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Group WhatsApp</label>
                      <input
                        type="url"
                        value={whatsappLink}
                        onChange={(e) => setWhatsappLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://chat.whatsapp.com/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Panduan Tutorial</label>
                      <input
                        type="url"
                        value={tutorialLink}
                        onChange={(e) => setTutorialLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://youtube.com/..."
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4 pb-8">
                  <button
                    type="submit"
                    disabled={settingsLoading}
                    className="px-6 py-2 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded shadow-lg transition-all disabled:opacity-50"
                  >
                    {settingsLoading ? 'Menyimpan...' : 'Simpan Tetapan'}
                  </button>
                </div>
              </form>
            </div>
          ) : activeTab === 'clients' ? (`;

const target = ") : activeTab === 'clients' ? (";
if (code.includes(target)) {
    code = code.replace(target, settingsUI);
    console.log("Successfully replaced the UI block");
} else {
    console.log("Could not find the target string!");
}

fs.writeFileSync('src/components/Dashboard.tsx', code);
