const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const oldParse = `                        datetime expTimeUTC = StructToTime(dt);
                        // Convert UTC expiry to MYT for display and logic
                        datetime expTimeMYT = expTimeUTC + (Malaysia_GMT_Offset * 3600);
                        string displayDate = TimeToString(expTimeMYT, TIME_DATE|TIME_MINUTES);`;

const newParse = `                        datetime parsed_as_local = StructToTime(dt);
                        int tz_offset = (int)(TimeLocal() - TimeGMT());
                        datetime expTimeUTC = parsed_as_local + tz_offset;
                        // Convert UTC expiry to MYT for display and logic
                        datetime expTimeMYT = expTimeUTC + (Malaysia_GMT_Offset * 3600);
                        string displayDate = TimeToString(expTimeMYT, TIME_DATE|TIME_MINUTES);`;

code = code.replace(oldParse, newParse);
fs.writeFileSync('src/eaCode.ts', code);
