const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf8');

const oldCode = `   if (MQID_NOTI != "") {
      string expireStr = TimeToString(g_license_expiry_time, TIME_DATE);
      SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\\nLicense expires on: " + expireStr);
   }`;

const newCode = `   if (MQID_NOTI != "") {
      string expireStr = (g_license_expiry_time > 0) ? TimeToString(g_license_expiry_time, TIME_DATE) : "Lifetime";
      SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\\nLicense expires on: " + expireStr);
   }`;

if (code.includes(oldCode)) {
    code = code.replace(oldCode, newCode);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Successfully updated notification logic in src/eaCode.ts");
} else {
    console.log("Could not find the target code block.");
}
