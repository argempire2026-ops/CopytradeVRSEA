const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The file was wrapped in `export const EA_CODE = " ... "` 
// so all internal quotes were originally escaped.
// I injected things with unescaped quotes!
code = code.replace(/MQID_NOTI != ""/g, 'MQID_NOTI != \\"\\"');
code = code.replace(/"VRS Alert : License key expires in "/g, '\\"VRS Alert : License key expires in \\"');
code = code.replace(/" days\. Please contact admin to renew\."/g, '\\" days. Please contact admin to renew.\\"');
code = code.replace(/"VRS Alert : No entry for now\. "/g, '\\"VRS Alert : No entry for now. \\"');
code = code.replace(/" Impact News will occur at "/g, '\\" Impact News will occur at \\"');
code = code.replace(/MQID_NOTI\s*=\s*""/g, 'MQID_NOTI        = \\"\\"');

fs.writeFileSync('src/eaCode.ts', code);
