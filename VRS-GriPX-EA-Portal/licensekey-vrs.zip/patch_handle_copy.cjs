const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "const handleCopyCode = async () => {\n    try {\n      await navigator.clipboard.writeText(eaCode);\n      setCopied(true);\n      setTimeout(() => setCopied(false), 2000);\n    } catch (err) {\n      console.error(\"Failed to copy\", err);\n    }\n  };",
  "const handleCopyCode = async () => {\n    try {\n      const textToCopy = activeTab === 'ea' ? eaCode : htmlCode;\n      await navigator.clipboard.writeText(textToCopy);\n      setCopied(true);\n      setTimeout(() => setCopied(false), 2000);\n    } catch (err) {\n      console.error(\"Failed to copy\", err);\n    }\n  };"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
