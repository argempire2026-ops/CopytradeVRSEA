const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

code = code.replace("status license tidak diketahui. Sila hubungi admin.", "unknown license status. Please contact admin.");
code = code.replace("Gagal berhubung dengan server Firebase", "Failed to connect to Firebase server");
code = code.replace("License anda telah TAMAT TEMPOH (", "Your license has EXPIRED (");
code = code.replace("EA EXPIRED! Sila renew license anda.\\nPosisi sedia ada diuruskan untuk Close Profit.\\nEntry awal baru telah diberhentikan.", "EA EXPIRED! Please renew your license.\\nExisting positions will be managed to Close in Profit.\\nNew entries have been stopped.");
code = code.replace("! EA tidak akan buka entry baru, posisi sedia ada dibiarkan close profit.", "! EA will not open new entries, existing positions will be managed to close in profit.");
fs.writeFileSync('src/eaCode.ts', code);
