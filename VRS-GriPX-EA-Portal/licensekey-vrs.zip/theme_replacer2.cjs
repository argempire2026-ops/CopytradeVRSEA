const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/bg-indigo-100/g, 'bg-[#D4AF37]/20');
code = code.replace(/hover:bg-indigo-50/g, 'hover:bg-[#D4AF37]/10');
code = code.replace(/text-white bg-indigo-600 hover:bg-indigo-700/g, 'text-slate-900 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] font-bold');

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Second pass replacements complete');
