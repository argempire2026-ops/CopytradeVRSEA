const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  /} else {\n                g_license_expiry = "Lifetime";\n            }/,
  '} else {\n                g_license_expiry = "Lifetime";\n                g_license_expiry_time = 0;\n            }'
);

fs.writeFileSync('public/ea-code.txt', code);
