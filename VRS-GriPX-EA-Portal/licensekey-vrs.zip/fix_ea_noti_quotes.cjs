const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The faulty string has unescaped double quotes that broke the JS string literal.
// We need to escape them: `\"` instead of `"`
// The current code has:
// SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\nLicense expires on: " + expireStr);

code = code.replace(
    /SendNotification\("VRS-GriPX EA has been successfully attached and activated on " \+ _Symbol \+ "!\\nLicense expires on: " \+ expireStr\);/g,
    'SendNotification(\\"VRS-GriPX EA has been successfully attached and activated on \\" + _Symbol + \\"!\\\\nLicense expires on: \\" + expireStr);'
);

fs.writeFileSync('src/eaCode.ts', code);
console.log('Fixed quotes in EA code');
