const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download } from 'lucide-react';",
  "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download } from 'lucide-react';\nimport { EA_CODE } from '../eaCode';"
);

code = code.replace(
  /fetch\('\/ea-code\.txt\?v=' \+ new Date\(\)\.getTime\(\)\)[\s\S]*?\.catch\(err => console\.error\("Failed to load EA code", err\)\);/,
  "setEaCode(EA_CODE);"
);

// Fallback if the previous regex fails due to different match
code = code.replace(
  /fetch\('\/ea-code\.txt(.*?)\)[\s\S]*?\.catch\(err => console\.error\("Failed to load EA code", err\)\);/,
  "setEaCode(EA_CODE);"
);


fs.writeFileSync('src/components/Dashboard.tsx', code);
