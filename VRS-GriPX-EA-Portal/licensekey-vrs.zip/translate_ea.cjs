const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// Replace alerts
code = code.replace(
    /"Sila masukkan License Key di bahagian input parameter!"/g, 
    '"Please enter the License Key in the input parameter section!"'
);
code = code.replace(
    /"License anda telah TAMAT TEMPOH pada "/g, 
    '"Your license has EXPIRED on "'
);
code = code.replace(
    /"! EA hanya akan menguruskan posisi sedia ada untuk close profit."/g, 
    '"! EA will only manage existing positions to close in profit."'
);
code = code.replace(
    /"Sistem gagal untuk parse maklumat license."/g, 
    '"System failed to parse license information."'
);
code = code.replace(
    /"Tiada maklumat expiresAt dijumpai \(Trial tidak sah\)."/g, 
    '"No expiresAt information found (Invalid Trial)."'
);
code = code.replace(
    /tidak didaftarkan untuk license ini!"/g, 
    'is not registered for this license!"'
);
code = code.replace(
    /"Akaun "/g, 
    '"Account "'
);
code = code.replace(
    /"Sila hubungi Admin untuk mendaftar akaun."/g, 
    '"Please contact Admin to register the account."'
);
code = code.replace(
    /"License Key anda TIDAK SAH atau TELAH DIBATALKAN!"/g, 
    '"Your License Key is INVALID or HAS BEEN CANCELLED!"'
);
code = code.replace(
    /"Menyemak sistem Firebase License..."/g, 
    '"Checking Firebase License system..."'
);
code = code.replace(
    /"License anda telah TAMAT TEMPOH \("/g, 
    '"Your license has EXPIRED ("'
);
code = code.replace(
    /"\)! EA tidak akan buka entry baru, posisi sedia ada dibiarkan close profit."/g, 
    '")! EA will not open new entries, existing positions will be left to close in profit."'
);

fs.writeFileSync('src/eaCode.ts', code);
