const fs = require('fs');
let code = fs.readFileSync('src/firebase.ts', 'utf-8');

code = code.replace(
  /export const db = getFirestore\(app, "ai-studio-245cc25a-6f6b-40e7-ad09-9650e6274c82"\);/,
  "export const db = getFirestore(app);"
);

fs.writeFileSync('src/firebase.ts', code);
