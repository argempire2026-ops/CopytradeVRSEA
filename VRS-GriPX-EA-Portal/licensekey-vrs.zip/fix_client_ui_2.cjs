const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldClientUI = `              {trialResult ? (
                <div className="p-4 rounded-lg border bg-[#050914] text-center max-w-md mx-auto">
                  {trialResult.error ? (
                    <>
                      <p className="text-red-500 font-medium mb-4">{trialResult.error}</p>
                      <button onClick={() => setTrialResult(null)} className="text-[#D4AF37] text-sm hover:underline">{t.backBtn}</button>
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-slate-400 mb-2">{t.copyKeyValid}</p>
                      <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                        {trialResult.key}
                      </div>
                      {trialResult.expiresAt && (
                        <p className="text-xs text-rose-400 mb-4">
                          {t.expires} {new Date(trialResult.expiresAt).toLocaleDateString('ms-MY', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                      <div className="flex gap-4 justify-center">
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(trialResult.key);
                            alert('Key copied!');
                          }}
                          className="px-4 py-2 bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#F1C40F]/20 hover:text-[#F1C40F] rounded transition-colors"
                        >Copy Key</button>
                        <button onClick={() => setTrialResult(null)} className="px-4 py-2 bg-slate-800 text-slate-300 text-sm hover:bg-slate-700 rounded transition-colors">{t.close}</button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <form onSubmit={handleClaimTrial} className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-1 w-full max-w-md">
                    <label className="block text-sm font-medium text-slate-300 mb-1">{t.mt5Name}</label>
                    <input
                      type="text"
                      value={trialMt5}
                      onChange={(e) => setTrialMt5(e.target.value)}
                      placeholder="Contoh: MUHAMAD FAAIZ"
                      className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={trialLoading}
                    className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all whitespace-nowrap disabled:opacity-50"
                  >
                    {trialLoading ? 'Processing...' : t.claimNow}
                  </button>
                </form>
              )}`;

const newClientUI = `              {(clientUser.trialCount || 0) >= 1 ? (
                <div className="p-6 rounded-lg border border-slate-800 bg-[#050914] text-center max-w-lg">
                  <div className="w-12 h-12 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-6 h-6 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                  </div>
                  <h4 className="text-lg font-bold text-slate-200 mb-2">Anda telah menebus Free Trial</h4>
                  <p className="text-sm text-slate-400 mb-6">Untuk meneruskan penggunaan, sila buat langganan (renew).</p>
                  <a
                    href={renewLink || '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all whitespace-nowrap"
                    onClick={(e) => { if (!renewLink) { e.preventDefault(); alert('Pautan langganan belum ditetapkan oleh Admin.'); } }}
                  >
                    Buat Langganan / Renew
                  </a>
                </div>
              ) : trialResult ? (
                <div className="p-4 rounded-lg border bg-[#050914] text-center max-w-md mx-auto">
                  {trialResult.error ? (
                    <>
                      <p className="text-red-500 font-medium mb-4">{trialResult.error}</p>
                      <button onClick={() => setTrialResult(null)} className="text-[#D4AF37] text-sm hover:underline">{t.backBtn}</button>
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-slate-400 mb-2">{t.copyKeyValid}</p>
                      <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                        {trialResult.key}
                      </div>
                      {trialResult.expiresAt && (
                        <p className="text-xs text-rose-400 mb-4">
                          {t.expires} {new Date(trialResult.expiresAt).toLocaleDateString('ms-MY', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                      <div className="flex gap-4 justify-center">
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(trialResult.key);
                            alert('Key copied!');
                          }}
                          className="px-4 py-2 bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#F1C40F]/20 hover:text-[#F1C40F] rounded transition-colors"
                        >Copy Key</button>
                        <button onClick={() => setTrialResult(null)} className="px-4 py-2 bg-slate-800 text-slate-300 text-sm hover:bg-slate-700 rounded transition-colors">{t.close}</button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <form onSubmit={handleClaimTrial} className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-1 w-full max-w-md">
                    <label className="block text-sm font-medium text-slate-300 mb-1">{t.mt5Name}</label>
                    <input
                      type="text"
                      value={trialMt5}
                      onChange={(e) => setTrialMt5(e.target.value)}
                      placeholder="Contoh: MUHAMAD FAAIZ"
                      className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={trialLoading}
                    className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all whitespace-nowrap disabled:opacity-50"
                  >
                    {trialLoading ? 'Processing...' : t.claimNow}
                  </button>
                </form>
              )}`;

code = code.replace(oldClientUI, newClientUI);
fs.writeFileSync('src/components/Dashboard.tsx', code);
