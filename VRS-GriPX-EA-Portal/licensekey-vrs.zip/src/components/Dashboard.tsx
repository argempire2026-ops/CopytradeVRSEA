import React, { useState, useEffect } from 'react';
import { collection, getDocs, getDoc, addDoc, onSnapshot, query, deleteDoc, doc, serverTimestamp, updateDoc, setDoc, where, deleteField, increment } from 'firebase/firestore';
import { db, auth, googleProvider, signInWithPopup, signOut } from '../firebase';
import { User } from 'firebase/auth';
import { LicenseKey } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';
import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download, Users, Lock, UserPlus } from 'lucide-react';
import { motion } from 'motion/react';
import { EA_CODE } from '../eaCode';
import { format } from 'date-fns';

function generateRandomKey() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 16; i++) {
    if (i > 0 && i % 4 === 0) result += '-';
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}


const t = {
    clientPortal: 'Client Portal Login',
    registeredEmail: 'Registered Email',
    password: 'Password',
    login: 'Login',
    welcome: 'Welcome',
    logout: 'Logout',
    downloadEA: 'Download EA',
    joinWhatsapp: 'Join WhatsApp Group',
    tutorialGuide: 'Tutorial Guide',
    activeLicense: 'Your Active License',
    historyStatus: 'License History & Status',
    claimTrial: 'Claim Free Trial',
    copyKeyValid: 'Please copy your License Key (Valid for 3 Days):',
    expires: 'Expires:',
    copyKey: 'Copy Key',
    close: 'Close',
    mt5Name: 'MT5 Name (Registered with Broker)',
    claimNow: 'Claim Now',
    linkNotSetWarning: 'Link not updated by Admin.',
    adminSettings: 'System Settings',
    manageClients: 'Manage Clients',
    teamAccess: 'Team Access',
    eaSource: 'EA Code Source',
    htmlSource: 'Web HTML Source',
    overview: 'Overview',
    historyDays: 'History (Days)',
    historyDaysDesc: 'Number of days before client license history is automatically deleted.',
    deleteAllNow: 'Delete All Now',
    eaUpdate: 'EA Update (Client Portal)',
    eaDownloadLink: 'EA Download Link',
    eaDesc: 'EA Description / Changelog',
    extLinks: 'External Links',    whatsappLink: 'WhatsApp Group Link',
    tutorialLink: 'Tutorial Guide Link',
    saveSettings: 'Save Settings',
    saving: 'Saving...',
    areYouSure: 'Are you sure?',
    deleteAllWarning: 'This action will delete ALL License History & Status records for ALL clients. This action cannot be undone.',
    cancel: 'Cancel',
    confirmDeleteAll: 'Agree to Delete All History',
    deleting: 'Deleting...',
    clientsList: 'Clients List',
    clientEmail: 'Client Email',
    
    totalLicenses: 'Total Licenses',
    actions: 'Actions',
    addEa: 'Add New EA',
    eaName: 'EA Name',
    
    
    
    removeEa: 'Remove',
    selectEa: 'Select EA to view details',
    downloadNow: 'Download Now',
    linkNotProvided: 'Link Not Provided',
    noEaProvided: 'No EA provided at this time.',
    noDescription: 'No description provided by Admin at this time.',
    clientLogin: 'Client Login',
    registeredEmailPlaceholder: 'Registered Email',
    passwordPlaceholder: 'Password',
    loginBtn: 'Login',
    welcomeMsg: 'Welcome to VRS Community Client Portal.\nPlease log in or register a new account.',
    registerNewAccount: 'Register New Account',
    backBtn: 'Back',
    clientRegister: 'Client Registration',
    adminAccess: 'Admin Access',
    invalidPassword: 'Invalid Password',
    accountNotFound: 'Account not found.',
    incorrectPassword: 'Incorrect password.',
    systemError: 'System error.',
    errorDeletingHistory: 'Error deleting history: '
  };

export default function Dashboard() {
  const logHistory = async (email: string, keyStr: string, action: string, reason: string) => {
    try {
      await addDoc(collection(db, 'licenseHistory'), {
        clientEmail: email.toLowerCase().trim(),
        key: keyStr,
        action,
        reason,
        timestamp: serverTimestamp()
      });
    } catch (e) {
      console.error('Failed to log history', e);
    }
  };

  const [activeTab, setActiveTab] = useState<'keys' | 'ea' | 'html' | 'team' | 'clients' | 'settings'>('keys');
  const [admins, setAdmins] = useState<{email: string}[]>([]);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [htmlCode, setHtmlCode] = useState<string>('');
  const [eaCode, setEaCode] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [keys, setKeys] = useState<LicenseKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [allowedAccounts, setAllowedAccounts] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [expiryPreset, setExpiryPreset] = useState('lifetime');
  const [renewExpiryPreset, setRenewExpiryPreset] = useState('custom');
  const [isCreating, setIsCreating] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [renewKey, setRenewKey] = useState<{id: string, expiry: string, allowedAccounts?: string, email?: string, keyString?: string} | null>(null);

  const [adminUnlockClicks, setAdminUnlockClicks] = useState(0);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [historyDays, setHistoryDays] = useState(30);
  const [defaultMaxTrials, setDefaultMaxTrials] = useState(1);
  const [defaultTrialDays, setDefaultTrialDays] = useState(3);

  const [eaList, setEaList] = useState<{id: string, name: string, link: string, description: string}[]>([]);
  const [selectedEaId, setSelectedEaId] = useState<string>('');
  const [whatsappLink, setWhatsappLink] = useState('');
  const [tutorialLink, setTutorialLink] = useState('');
  const [renewLink, setRenewLink] = useState('');
  const [freeClaimLink, setFreeClaimLink] = useState('');
  const [showFreeClaimModal, setShowFreeClaimModal] = useState(false);
  const [freeClaimInputKey, setFreeClaimInputKey] = useState('');
  const [freeClaimError, setFreeClaimError] = useState('');
  const [freeClaimLoading, setFreeClaimLoading] = useState(false);
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [clearingHistory, setClearingHistory] = useState(false);
    const [showClearHistoryConfirm, setShowClearHistoryConfirm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showEaModal, setShowEaModal] = useState(false);
  const [showClientLogin, setShowClientLogin] = useState(false);
  const [clientEmail, setClientEmail] = useState('');
  const [clientPassword, setClientPassword] = useState('');
  const [clientUser, setClientUser] = useState<any>(null);
  const [clientKeys, setClientKeys] = useState<any[]>([]);
  const [clientHistory, setClientHistory] = useState<any[]>([]);
  const [clientLoginError, setClientLoginError] = useState('');
  const [clients, setClients] = useState<any[]>([]);
  const [deleteConfirm, setDeleteConfirm] = useState<{type: 'client'|'key', id: string} | null>(null);
  const [deletePasswordInput, setDeletePasswordInput] = useState('');
  const [newClientEmail, setNewClientEmail] = useState('');
  const [newClientPassword, setNewClientPassword] = useState('');
  const [newClientName, setNewClientName] = useState('');
  const [showClientRegister, setShowClientRegister] = useState(false);
  const [regClientEmail, setRegClientEmail] = useState('');
  const [regClientName, setRegClientName] = useState('');
  const [regClientPassword, setRegClientPassword] = useState('');
  const [clientRegError, setClientRegError] = useState('');
  const [trialMt5, setTrialMt5] = useState('');
  const [trialLoading, setTrialLoading] = useState(false);
  const [trialResult, setTrialResult] = useState<{ key: string, error?: string, expiresAt?: string, existing?: boolean } | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'general'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.historyDays) setHistoryDays(data.historyDays);
        if (data.defaultMaxTrials !== undefined) setDefaultMaxTrials(data.defaultMaxTrials);
        if (data.defaultTrialDays !== undefined) setDefaultTrialDays(data.defaultTrialDays);

        if (data.eaList) {
          setEaList(data.eaList);
          if (data.eaList.length > 0) setSelectedEaId(data.eaList[0].id);
        } else if (data.eaDownloadLink || data.eaDescription) {
          // Backward compatibility
          const fallback = [{
            id: 'default_ea',
            name: 'Main EA',
            link: data.eaDownloadLink || '',
            description: data.eaDescription || ''
          }];
          setEaList(fallback);
          setSelectedEaId('default_ea');
        }
        if (data.whatsappLink) setWhatsappLink(data.whatsappLink);
        if (data.tutorialLink) setTutorialLink(data.tutorialLink);
        if (data.renewLink) setRenewLink(data.renewLink);
        if (data.freeClaimLink) setFreeClaimLink(data.freeClaimLink);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(collection(db, 'clients'));
      const unsub = onSnapshot(q, (snapshot) => {
        const data: any[] = [];
        snapshot.forEach(d => data.push({ id: d.id, ...d.data() }));
        setClients(data);
      });
      return () => unsub();
    }
  }, [user]);

  useEffect(() => {
    if (clientUser) {
      const q = query(collection(db, 'licenseKeys'), where('customerEmail', '==', clientUser.email));
      const unsub = onSnapshot(q, (snapshot) => {
        const data: any[] = [];
        snapshot.forEach(d => data.push({ id: d.id, ...d.data() }));
        setClientKeys(data);
      });

      const hq = query(collection(db, 'licenseHistory'), where('clientEmail', '==', clientUser.email.toLowerCase().trim()));
      const unsubHistory = onSnapshot(hq, (snapshot) => {
        const historyList: any[] = [];
        const now = new Date();
        const expiryMs = (historyDays || 30) * 24 * 60 * 60 * 1000;
        
        snapshot.forEach(docSnap => {
          const data = docSnap.data();
          const docTime = data.timestamp?.toDate() || new Date();
          
          if (now.getTime() - docTime.getTime() > expiryMs) {
            deleteDoc(docSnap.ref).catch(console.error);
          } else {
            historyList.push({ id: docSnap.id, ...data });
          }
        });
        historyList.sort((a, b) => (b.timestamp?.toMillis() || 0) - (a.timestamp?.toMillis() || 0));
        setClientHistory(historyList);
      });

      return () => { unsub(); unsubHistory(); };
    }
  }, [clientUser, historyDays]);

  const handleClientLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setClientLoginError('');
    try {
      const q = query(collection(db, 'clients'), where('email', '==', clientEmail.toLowerCase().trim()));
      const snap = await getDocs(q);
      if (snap.empty) {
        setClientLoginError(t.accountNotFound);
        return;
      }
      
      let matchedClient = null;
      snap.forEach(docSnap => {
        if (docSnap.data().password === clientPassword) {
          matchedClient = docSnap.data();
        }
      });
      
      if (!matchedClient) {
        setClientLoginError(t.incorrectPassword);
        return;
      }
      
      setClientUser({ email: matchedClient.email, name: matchedClient.name, trialCount: matchedClient.trialCount || 0, maxTrials: matchedClient.maxTrials });
    } catch (err) {
      setClientLoginError(t.systemError);
      console.error(err);
    }
  };

  const handleClientRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setClientRegError('');
    if (!regClientEmail.trim() || !regClientName.trim() || !regClientPassword.trim()) return;
    
    if (!regClientEmail.toLowerCase().trim().endsWith('@gmail.com')) {
      setClientRegError('Registration is only allowed using a Gmail account (@gmail.com).');
      return;
    }
    
    try {
      const emailKey = regClientEmail.toLowerCase().trim();
      const clientRef = doc(db, 'clients', emailKey);
      
      const q = query(collection(db, 'clients'), where('email', '==', emailKey));
      const snap = await getDocs(q);
      
      if (!snap.empty) {
        setClientRegError('This email has already been registered.');
        return;
      }
      
      await setDoc(clientRef, {
        email: emailKey,
        name: regClientName.trim(),
        password: regClientPassword,
        createdAt: serverTimestamp()
      });
      
      alert('Registration successful! Please login.');
      setShowClientRegister(false);
      setRegClientEmail('');
      setRegClientName('');
      setRegClientPassword('');
      setShowClientLogin(true);
    } catch (err: any) {
      setClientRegError('Failed to register: ' + err.message);
    }
  };

  const handlePresetChange = (preset: string) => {
    setExpiryPreset(preset);
    const d = new Date();
    if (preset === 'lifetime') {
      setExpiryDate('');
    } else if (preset === '1_month') {
      d.setMonth(d.getMonth() + 1); setExpiryDate(d.toISOString().slice(0,16));
    } else if (preset === '3_months') {
      d.setMonth(d.getMonth() + 3); setExpiryDate(d.toISOString().slice(0,16));
    } else if (preset === '6_months') {
      d.setMonth(d.getMonth() + 6); setExpiryDate(d.toISOString().slice(0,16));
    } else if (preset === '1_year') {
      d.setFullYear(d.getFullYear() + 1); setExpiryDate(d.toISOString().slice(0,16));
    }
  };

  const handleRenewPresetChange = (preset: string, currentExpiryStr: string | null) => {
    setRenewExpiryPreset(preset);
    // If renewing from an existing expiry, use that as base? 
    // Usually renewals are from *now*, or we just use *now* to be safe and simple.
    const d = new Date();
    if (preset === 'lifetime') {
      setRenewKey(prev => prev ? {...prev, expiry: ''} : null);
    } else if (preset === '1_month') {
      d.setMonth(d.getMonth() + 1); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    } else if (preset === '3_months') {
      d.setMonth(d.getMonth() + 3); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    } else if (preset === '6_months') {
      d.setMonth(d.getMonth() + 6); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    } else if (preset === '1_year') {
      d.setFullYear(d.getFullYear() + 1); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    }
  };

  
  const handleUpdateClientMaxTrials = async (clientId: string, maxTrials: number) => {
    try {
      if (isNaN(maxTrials)) return;
      await updateDoc(doc(db, 'clients', clientId), {
        maxTrials: maxTrials
      });
    } catch (err: any) {
      alert('Failed to update max trials: ' + err.message);
    }
  };

  const handleCreateClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientEmail.trim() || !newClientPassword.trim()) return;
    
    if (!newClientEmail.toLowerCase().trim().endsWith('@gmail.com')) {
      alert('Registration is only allowed using a Gmail account (@gmail.com).');
      return;
    }
    
    try {
      const clientRef = doc(db, 'clients', newClientEmail.toLowerCase().trim());
      await setDoc(clientRef, {
        email: newClientEmail.toLowerCase().trim(),
        name: newClientName.trim(),
        password: newClientPassword,
        createdAt: serverTimestamp()
      });
      setNewClientEmail('');
      setNewClientName('');
      setNewClientPassword('');
      alert('Client account created successfully!');
    } catch (err: any) {
      alert('Failed to create account: ' + err.message);
    }
  };

  const handleDeleteClient = (email: string) => {
    setDeleteConfirm({ type: 'client', id: email });
  };

  const executeDelete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (deletePasswordInput !== "VRS123") {
      alert("Incorrect Admin password.");
      setDeletePasswordInput('');
      return;
    }
    
    if (!deleteConfirm) return;
    
    try {
      if (deleteConfirm.type === 'client') {
        await deleteDoc(doc(db, 'clients', deleteConfirm.id));
      } else if (deleteConfirm.type === 'key') {
        const keyRef = doc(db, 'licenseKeys', deleteConfirm.id);
        const keySnap = await getDoc(keyRef);
        if (keySnap.exists()) {
          const data = keySnap.data();
          await logHistory(data.customerEmail, data.key, 'Deleted', 'License deleted by Admin.');
        }
        await deleteDoc(keyRef);
      }
      setDeleteConfirm(null);
      setDeletePasswordInput('');
    } catch (error: any) {
      alert('Failed to delete: ' + error.message);
    }
  };

  const handleLogoClick = () => {
    if (showAdminLogin || showPasswordPrompt) return;
    setAdminUnlockClicks(prev => {
      const clicks = prev + 1;
      if (clicks >= 5) {
        setShowPasswordPrompt(true);
        return 0;
      }
      return clicks;
    });
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === "VRS123") {
      setShowAdminLogin(true);
      setShowPasswordPrompt(false);
      setAdminPassword('');
    } else {
      alert("Incorrect password.");
      setShowPasswordPrompt(false);
      setAdminPassword('');
    }
  };

  const handleFreeClaimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFreeClaimError('');
    if (!freeClaimInputKey.trim()) return;
    
    setFreeClaimLoading(true);
    try {
      const keyDoc = await getDoc(doc(db, 'licenseKeys', freeClaimInputKey.trim()));
      if (!keyDoc.exists()) {
        setFreeClaimError('Invalid License Key. Please check and try again.');
        setFreeClaimLoading(false);
        return;
      }
      
      const keyData = keyDoc.data();
      if (keyData.isTrial === true) {
        setFreeClaimError('Trial keys are not eligible for Free Claim. Please enter a subscribed premium license key.');
        setFreeClaimLoading(false);
        return;
      }

      setShowFreeClaimModal(false);
      setFreeClaimInputKey('');
      if (freeClaimLink) {
        window.open(freeClaimLink, '_blank');
      } else {
        alert('Free Claim URL has not been set by Admin.');
      }
    } catch (err: any) {
      setFreeClaimError('Error validating key: ' + err.message);
    }
    setFreeClaimLoading(false);
  };

  const handleClaimTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialMt5.trim() || !clientUser) return;
    
    const maxAllowed = clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials;
    if (clientUser.trialCount >= maxAllowed) {
      setTrialResult({ key: '', error: `You have reached the maximum allowed trial claims (${maxAllowed}).` });
      return;
    }

    setTrialLoading(true);
    setTrialResult(null);
    try {
      // Update trial count in client doc
      const clientQuery = query(collection(db, 'clients'), where('email', '==', clientUser.email));
      const clientSnap = await getDocs(clientQuery);
      if (!clientSnap.empty) {
        const clientDoc = clientSnap.docs[0];
        await updateDoc(doc(db, 'clients', clientDoc.id), {
          trialCount: (clientUser.trialCount || 0) + 1
        });
        setClientUser({ ...clientUser, trialCount: (clientUser.trialCount || 0) + 1 });
      }

      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + defaultTrialDays);
      const expiryStr = expiryDate.toISOString();
      
      const generatedKey = 'TRIAL-' + generateRandomKey().substring(0, 8);
      
      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: clientUser.email,
        customerName: 'Trial MT5: ' + trialMt5.trim(),
        allowedAccounts: trialMt5.trim(),
        status: 'active',
        ownerUid: 'system_trial',
        createdAt: serverTimestamp(),
        expiresAt: expiryStr,
        isTrial: true
      };
      
      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      // No history log for trial
      
      setTrialResult({ key: generatedKey, expiresAt: expiryStr });
      setTrialMt5('');
    } catch (error: any) {
      console.error(error);
      setTrialResult({ key: '', error: 'Failed to generate trial. ' + error.message });
    } finally {
      setTrialLoading(false);
    }
  };

  const handleCopyKey = async (key: string) => {
    try {
      await navigator.clipboard.writeText(key);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    } catch (err) {
      console.error("Failed to copy key", err);
    }
  };

  useEffect(() => {
    setEaCode(EA_CODE);
    fetch('/dashboard-export.html?v=' + new Date().getTime()).then(res => { if (!res.ok) throw new Error('Not found'); return res.text(); }).then(text => setHtmlCode(text)).catch(err => setHtmlCode('// Please run \"npm run build && cp dist/index.html public/dashboard-export.html\" to view this HTML code.\n// Failed to load HTML source code.'));

    
  }, []);

  useEffect(() => {
    let unsubscribeSnapshot = null;
    
    const unsubscribeAuth = auth.onAuthStateChanged(async (currentUser) => {
      if (currentUser) {
        // Validate admin access
        if (currentUser.email === 'mfrdotbiz@gmail.com') {
          setUser(currentUser);
          subscribeToKeys();
        } else {
          try {
            const adminDoc = await getDoc(doc(db, 'admins', currentUser.email || ''));
            if (adminDoc.exists()) {
              setUser(currentUser);
              subscribeToKeys();
            } else {
              throw new Error('Not admin');
            }
          } catch (e) {
            alert('Access Denied: Email [' + (currentUser.email || '') + '] is not in the Team Access list.\n\nPlease contact the Admin to get access.');
            await auth.signOut();
            setUser(null);
            setKeys([]);
            setLoading(true);
          }
        }
      } else {
        setUser(null);
        setKeys([]);
        setLoading(true);
        if (unsubscribeSnapshot) unsubscribeSnapshot();
      }
    });

    const subscribeToKeys = () => {
      const q = query(collection(db, 'licenseKeys'));
      unsubscribeSnapshot = onSnapshot(q, (snapshot) => {
        const now = new Date();
        const keysData = [];
        
        snapshot.docs.forEach(document => {
          const data = document.data();
          const keyId = document.id;
          
          if (data.expiresAt && new Date(data.expiresAt) < now) {
            deleteDoc(doc(db, 'licenseKeys', keyId)).catch(console.error);
          } else {
            keysData.push({
              ...data,
              id: keyId,
              createdAt: data.createdAt?.toDate() || new Date()
            });
          }
        });
        
        // Sort client-side to avoid needing an index right away
        keysData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        
        setKeys(keysData);
        setLoading(false);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'licenseKeys');
        setLoading(false);
      });
    };

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  useEffect(() => {
    if (user && user.email === 'mfrdotbiz@gmail.com') {
      const q = query(collection(db, 'admins'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const adminsData = [];
        snapshot.docs.forEach(doc => adminsData.push({ email: doc.id }));
        setAdmins(adminsData);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim()) return;
    try {
      await setDoc(doc(db, 'admins', newAdminEmail.trim().toLowerCase()), { addedAt: serverTimestamp() });
      setNewAdminEmail('');
    } catch (error) {
      alert("Failed to add admin: " + error.message);
    }
  };

  const handleRemoveAdmin = async (email: string) => {
    try {
      await deleteDoc(doc(db, 'admins', email));
    } catch (error) {
      alert("Failed to remove admin: " + error.message);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !customerEmail.trim() || !customerName.trim()) return;

    setIsCreating(true);
    try {
      const generatedKey = generateRandomKey();
      
      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: customerEmail.toLowerCase().trim(),
        customerName: customerName.trim(),
        status: 'active',
        ownerUid: user.uid,
        createdAt: serverTimestamp()
      };

      if (expiryDate) {
        newKey.expiresAt = expiryDate;
      }
      if (allowedAccounts.trim()) {
        newKey.allowedAccounts = allowedAccounts.trim();
      }

      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      // No history log for create
      
      setCustomerEmail('');
      setCustomerName('');
      setAllowedAccounts('');
      setExpiryDate('');
      setExpiryPreset('lifetime');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'licenseKeys');
    } finally {
      setIsCreating(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsLoading(true);
    try {
      await setDoc(doc(db, 'settings', 'general'), {
        historyDays,
        defaultMaxTrials,
        defaultTrialDays,

        eaList,
        whatsappLink,
        tutorialLink,
        renewLink,
        freeClaimLink
      }, { merge: true });
      alert('Settings saved successfully!');
    } catch (err: any) {
      alert('Failed to save settings: ' + err.message);
    }
    setSettingsLoading(false);
  };

  const executeClearAllHistory = async () => {
    setClearingHistory(true);
    try {
      const snap = await getDocs(collection(db, 'licenseHistory'));
      let count = 0;
      const deletePromises: any[] = [];
      snap.forEach((docSnap) => {
        deletePromises.push(deleteDoc(docSnap.ref));
        count++;
      });
      await Promise.all(deletePromises);
      setShowClearHistoryConfirm(false);
    } catch (error: any) {
      alert(t.errorDeletingHistory + error.message);
    }
    setClearingHistory(false);
  };

  const handleCopyCode = async () => {
    try {
      const textToCopy = activeTab === 'ea' ? eaCode : htmlCode;
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy", err);
    }
  };

  const handleDelete = (id: string) => {
    setDeleteConfirm({ type: 'key', id: id });
  };

  const handleRenew = async (id: string, newDate: string, newAllowedAccounts: string = '') => {
    try {
      const updates: any = { status: 'active' };
      if (newDate.trim() === '') { 
        updates.expiresAt = deleteField();
      } else { 
        updates.expiresAt = newDate.trim();
      }
      if (newAllowedAccounts.trim() === '') {
        updates.allowedAccounts = deleteField();
      } else {
        updates.allowedAccounts = newAllowedAccounts.trim();
      }
      await updateDoc(doc(db, 'licenseKeys', id), updates);
      if (renewKey?.email && renewKey?.keyString) {
        await logHistory(renewKey.email, renewKey.keyString, 'Renewed', 'License information / expiry date updated.');
      }
      setRenewKey(null);
      alert('License updated successfully!');
    } catch (error) {
      alert(`Failed to update: ${error instanceof Error ? error.message : 'Unknown error'}`);
      handleFirestoreError(error, OperationType.UPDATE, `licenseKeys/${id}`);
    }
  };

  const handleToggleStatus = async (k: any) => {
    try {
      const newStatus = k.status === 'active' ? 'revoked' : 'active';
      await updateDoc(doc(db, 'licenseKeys', k.id), { status: newStatus });
      await logHistory(k.customerEmail, k.key, newStatus === 'active' ? 'Reactivated' : 'Revoked', newStatus === 'active' ? 'License reactivated.' : 'License revoked by Admin.');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `licenseKeys/${k.id}`);
    }
  };

  if (!user) {
    if (clientUser) {
      return (
        <div className="min-h-screen w-full bg-[#0B132B] flex flex-col font-sans">
          <header className="h-16 bg-[#131E3A] border-b border-slate-800 flex items-center justify-between px-4 md:px-8">
            <div className="flex items-center gap-2">
              <img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-8 h-8 rounded object-cover" alt="VRS Logo" />
              <h1 className="text-white font-bold tracking-tight text-lg">VRS Client Portal</h1>
            </div>
            <div className="flex items-center gap-4">
                            <p className="text-sm text-slate-300 hidden md:block">{t.welcome}, {clientUser.name || clientUser.email}</p>
              <button 
                onClick={() => setClientUser(null)} 
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded text-sm hover:bg-slate-700 transition-colors"
              >Logout</button>
            </div>
          </header>
          <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <button 
                onClick={() => setShowEaModal(true)}
                className="flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl font-bold shadow-lg transition-transform hover:-translate-y-1"
              >
                <Download className="w-5 h-5" /> {t.downloadEA}
              </button>
              
              <a 
                href={whatsappLink || '#'} 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white rounded-xl font-bold shadow-lg transition-transform hover:-translate-y-1"
                onClick={(e) => { if (!whatsappLink) { e.preventDefault(); alert(t.linkNotSetWarning); } }}
              >{t.joinWhatsapp}</a>

              <a 
                href={tutorialLink || '#'} 
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white rounded-xl font-bold shadow-lg transition-transform hover:-translate-y-1"
                onClick={(e) => { if (!tutorialLink) { e.preventDefault(); alert(t.linkNotSetWarning); } }}
              >{t.tutorialGuide}</a>
            </div>

            {showFreeClaimModal && (
              <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-slate-200">Free Claim Verification</h3>
                  </div>
                  <form onSubmit={handleFreeClaimSubmit} className="p-6">
                    <p className="text-sm text-slate-300 mb-4">Please enter your License Key after subscribing to proceed with your Free Claim.</p>
                    
                    {freeClaimError && (
                      <div className="mb-4 p-3 bg-red-500/10 border border-red-500/50 rounded text-red-500 text-sm">
                        {freeClaimError}
                      </div>
                    )}

                    <div className="mb-6">
                      <label className="block text-sm font-medium text-slate-400 mb-2">License Key</label>
                      <input
                        type="text"
                        value={freeClaimInputKey}
                        onChange={(e) => setFreeClaimInputKey(e.target.value)}
                        placeholder="Enter your valid premium license key"
                        className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                        required
                      />
                    </div>

                    <div className="flex justify-end gap-3">
                      <button
                        type="button"
                        onClick={() => setShowFreeClaimModal(false)}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={freeClaimLoading || !freeClaimInputKey.trim()}
                        className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all disabled:opacity-50"
                      >
                        {freeClaimLoading ? 'Verifying...' : 'Verify & Claim'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {showEaModal && (
              <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-slate-200">{t.downloadEA}</h3>
                  </div>
                  <div className="p-6">
                    {eaList.length > 0 ? (
                      <>
                        <div className="mb-4">
                          <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.selectEa}</label>
                          <select 
                            value={selectedEaId}
                            onChange={(e) => setSelectedEaId(e.target.value)}
                            className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                          >
                            {eaList.map(ea => (
                              <option key={ea.id} value={ea.id}>{ea.name}</option>
                            ))}
                          </select>
                        </div>
                        {eaList.find(ea => ea.id === selectedEaId) && (
                          <>
                            <div className="p-4 bg-[#0B132B] rounded-lg border border-slate-800 mb-8 max-h-48 overflow-y-auto">
                              <p className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed">
                                {eaList.find(ea => ea.id === selectedEaId)?.description || '{t.noDescription}'}
                              </p>
                            </div>
                            <div className="flex gap-4">
                              {eaList.find(ea => ea.id === selectedEaId)?.link ? (
                                <a 
                                  href={eaList.find(ea => ea.id === selectedEaId)?.link}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded-lg transition-colors"
                                >
                                  <Download className="w-4 h-4" /> {t.downloadNow}
                                </a>
                              ) : (
                                <button disabled className="flex-1 px-4 py-3 bg-slate-800 text-slate-500 font-bold rounded-lg cursor-not-allowed">{t.linkNotProvided}</button>
                              )}
                              <button 
                                onClick={() => setShowEaModal(false)}
                                className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors"
                              >
                                {t.close}
                              </button>
                            </div>
                          </>
                        )}
                      </>
                    ) : (
                      <div className="text-center py-6">
                        <p className="text-slate-400 mb-6">{t.noEaProvided}</p>
                        <button 
                          onClick={() => setShowEaModal(false)}
                          className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg transition-colors"
                        >
                          {t.close}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-slate-200">{t.activeLicense}</h2>
              <button
                onClick={() => {
                  setFreeClaimError('');
                  setFreeClaimInputKey('');
                  setShowFreeClaimModal(true);
                }}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-500 hover:from-blue-500 hover:to-indigo-400 text-white text-sm font-bold rounded shadow transition-all"
              >
                Free Claim
              </button>
            </div>
            
            <div className="bg-[#131E3A] p-6 rounded-xl shadow-lg border border-slate-800 mb-8">
                            <div className="mb-4">
                <h3 className="text-lg font-semibold text-slate-200">Claim {defaultTrialDays}-Day Free Trial</h3>
              </div>
              {(clientUser.trialCount || 0) >= 1 || trialResult ? (
                <div className="p-6 rounded-lg border border-slate-800 bg-[#050914] text-center max-w-lg mx-auto">
                  <div className="w-12 h-12 bg-[#D4AF37]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-6 h-6 text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                  </div>
                  <h4 className="text-lg font-bold text-slate-200 mb-2">You have claimed the Free Trial</h4>
                  
                  {(() => {
                    const currentTrialKey = trialResult?.key || keys.find(k => k.isTrial)?.key;
                    if (currentTrialKey) {
                      return (
                        <div className="mb-6 mt-4 p-4 bg-[#131E3A] border border-[#D4AF37]/30 rounded-lg">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Your Trial Key</p>
                          <div className="font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all bg-black/30 p-2 rounded">
                            {currentTrialKey}
                          </div>
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(currentTrialKey);
                              alert('Key copied!');
                            }}
                            className="px-4 py-2 bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#F1C40F]/20 hover:text-[#F1C40F] rounded transition-colors"
                          >
                            Copy Key
                          </button>
                        </div>
                      );
                    }
                    return null;
                  })()}

                  <p className="text-sm text-slate-400 mb-6">If you wish to continue using the service after the free trial ends, please subscribe (renew).</p>
                  <a
                    href={renewLink || '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all whitespace-nowrap"
                    onClick={(e) => { if (!renewLink) { e.preventDefault(); alert('Subscribe link has not been set by Admin.'); } }}
                  >
                    Subscribe / Renew
                  </a>
                </div>
              ) : (
                <form onSubmit={handleClaimTrial} className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-1 w-full max-w-md">
                    <label className="block text-sm font-medium text-slate-300 mb-1">{t.mt5Name}</label>
                    <input
                      type="text"
                      value={trialMt5}
                      onChange={(e) => setTrialMt5(e.target.value)}
                      placeholder="e.g. MUHAMAD FAAIZ"
                      className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={trialLoading}
                    className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all whitespace-nowrap disabled:opacity-50"
                  >
                    {trialLoading ? 'Processing...' : t.claimNow}
                  </button>
                </form>
              )}
            </div>
            <div className="bg-[#131E3A] rounded-xl shadow-lg border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-3 whitespace-nowrap">License Key</th>
                      <th className="px-6 py-3 whitespace-nowrap">Status</th>
                      <th className="px-6 py-3 whitespace-nowrap">MT5 Name (Allowed)</th>
                      <th className="px-6 py-3 whitespace-nowrap">Expiry Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {clientKeys.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-slate-400">
                          <p className="text-sm font-semibold text-slate-700">No licenses found.</p>
                        </td>
                      </tr>
                    ) : (
                      clientKeys.map(k => (
                        <tr key={k.id} className="hover:bg-[#050914]">
                          <td className="px-6 py-4 font-mono text-xs text-[#D4AF37] font-medium">{k.key}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${k.status === 'active' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'}`}>
                              {k.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-xs font-semibold text-slate-400">{k.allowedAccounts || 'Any Account'}</td>
                          <td className="px-6 py-4 text-xs text-slate-400 whitespace-nowrap">
                            {k.expiresAt ? new Date(k.expiresAt).toLocaleDateString('ms-MY', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Lifetime'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            
            <h2 className="text-xl font-bold text-slate-200 mb-6 mt-8">License History & Status ({historyDays} Days)</h2>
            <div className="bg-[#131E3A] rounded-xl shadow-lg border border-slate-800 overflow-hidden mb-12">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-3 whitespace-nowrap">Date/Time</th>
                      <th className="px-6 py-3 whitespace-nowrap">License Key</th>
                      <th className="px-6 py-3 whitespace-nowrap">{t.actions}</th>
                      <th className="px-6 py-3">Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {clientHistory.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-slate-400">
                          <p className="text-sm font-semibold text-slate-700">No history records within {historyDays} days.</p>
                        </td>
                      </tr>
                    ) : (
                      clientHistory.map(h => (
                        <tr key={h.id} className="hover:bg-[#050914]">
                          <td className="px-6 py-4 text-xs text-slate-400 whitespace-nowrap">
                            {h.timestamp ? h.timestamp.toDate().toLocaleString('ms-MY') : '-'}
                          </td>
                          <td className="px-6 py-4 font-mono text-xs text-slate-300">{h.key}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider 
                              ${h.action === 'Dicipta' || h.action === 'Created' || h.action === 'Trial' || h.action === 'Diaktifkan Semula' || h.action === 'Reactivated' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 
                                h.action === 'Diperbaharui' || h.action === 'Renewed' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 
                                'bg-rose-500/20 text-rose-400 border border-rose-500/30'}`}>
                              {h.action === 'Dicipta' ? 'Created' : h.action === 'Diaktifkan Semula' ? 'Reactivated' : h.action === 'Diperbaharui' ? 'Renewed' : h.action === 'Dibatalkan' ? 'Revoked' : h.action}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-xs text-slate-400">{h.reason}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </main>
        </div>
      );
    }
    if (showAdminLogin) {
      return (
        <div className="h-screen w-full bg-[#0B132B] flex items-center justify-center font-sans">
          <div className="bg-[#131E3A] p-8 rounded-xl shadow-sm border border-slate-800 flex flex-col items-center max-w-sm w-full">
            <img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-16 h-16 rounded-xl mb-4 object-cover" alt="VRS Logo" />
            <h1 className="text-xl font-bold text-slate-200 mb-2">VRS (EXPERT ADVISOR)</h1>
            <p className="text-sm text-slate-400 text-center mb-6">Sign in to access VRS Community Admin.</p>
            <button 
              onClick={() => {
                signInWithPopup(auth, googleProvider).catch(e => {
                  if (e.code === 'auth/cancelled-popup-request' || e.code === 'auth/popup-closed-by-user') {
                    // Ignore user cancellation errors
                    console.log('Login popup closed by user');
                    return;
                  }
                  console.error('Login error:', e);
                  alert('Login failed: ' + e.message);
                });
              }}
              className="w-full py-2 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors"
            >
              Sign in with Google
            </button>
            <button onClick={() => setShowAdminLogin(false)} className="mt-4 text-xs text-slate-400 hover:text-slate-400">Back</button>
          </div>
        </div>
      );
    }

    return (
      <div className="h-screen w-full bg-[#0B132B] flex items-center justify-center font-sans p-4 relative overflow-hidden">
        {/* Animated Background Mesh */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-cyan-900/20 blur-[120px]"></div>
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-fuchsia-900/15 blur-[120px]"></div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="relative z-10 bg-[#131E3A]/70 backdrop-blur-xl p-8 rounded-2xl shadow-[0_8px_32px_0_rgba(0,255,200,0.05)] border border-white/10 flex flex-col items-center max-w-sm w-full"
        >
          <div className="relative mb-6 group">
            <div className="absolute inset-0 bg-cyan-500/30 blur-2xl rounded-full opacity-50 group-hover:opacity-80 transition-opacity duration-500"></div>
            <img 
              onClick={handleLogoClick} 
              src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" 
              alt="VRS Logo"
              className="relative z-10 w-24 h-24 rounded-2xl cursor-pointer select-none object-cover border border-white/20 shadow-2xl transition-transform hover:scale-105 duration-300"
            />
          </div>
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-100 to-slate-400 mb-1 text-center tracking-tight"
          >
            VRS (EXPERT ADVISOR)
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-xs text-cyan-400/80 text-center mb-6 font-semibold tracking-[0.2em] uppercase"
          >
            VRS Community
          </motion.p>
                    
          <div className="w-full">
            {showPasswordPrompt ? (
              <motion.form 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onSubmit={handlePasswordSubmit} 
                className="space-y-4"
              >
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">{t.adminAccess}</h2>
                <div>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    autoFocus
                  />
                </div>
                <button type="submit" className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  Submit
                </button>
                <button type="button" onClick={() => setShowPasswordPrompt(false)} className="w-full mt-2 py-2 text-sm text-slate-400 hover:text-white transition-colors">Cancel</button>
              </motion.form>
            ) : showClientRegister ? (
              <motion.form 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onSubmit={handleClientRegister} 
                className="space-y-4"
              >
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">{t.clientRegister}</h2>
                {clientRegError && <p className="text-pink-500 text-sm font-medium text-center">{clientRegError}</p>}
                <div>
                  <input
                    type="text"
                    value={regClientName}
                    onChange={(e) => setRegClientName(e.target.value)}
                    placeholder="Nama Penuh"
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <div>
                  <input
                    type="email"
                    value={regClientEmail}
                    onChange={(e) => setRegClientEmail(e.target.value)}
                    placeholder="Your Email"
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={regClientPassword}
                    onChange={(e) => setRegClientPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <button type="submit" className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  Register Account
                </button>
                <div className="flex justify-between mt-4">
                  <button type="button" onClick={() => {setShowClientRegister(false); setShowClientLogin(true);}} className="py-2 text-sm text-[#00FFC8] hover:text-white transition-colors">Already have an account?</button>
                  <button type="button" onClick={() => setShowClientRegister(false)} className="py-2 text-sm text-slate-400 hover:text-white transition-colors">{t.backBtn}</button>
                </div>
              </motion.form>
            ) : showClientLogin ? (
              <motion.form 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onSubmit={handleClientLogin} 
                className="space-y-4"
              >
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">{t.clientLogin}</h2>
                {clientLoginError && <p className="text-pink-500 text-sm font-medium text-center">{clientLoginError}</p>}
                <div>
                  <input
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder={t.registeredEmailPlaceholder}
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={clientPassword}
                    onChange={(e) => setClientPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <button type="submit" className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  {t.loginBtn}
                </button>
                <div className="flex justify-between mt-4">
                  <button type="button" onClick={() => {setShowClientLogin(false); setShowClientRegister(true);}} className="py-2 text-sm text-[#00FFC8] hover:text-white transition-colors">{t.registerNewAccount}</button>
                  <button type="button" onClick={() => setShowClientLogin(false)} className="py-2 text-sm text-slate-400 hover:text-white transition-colors">{t.backBtn}</button>
                </div>
              </motion.form>
            ) : (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="text-center space-y-6 py-4"
              >
                 <p className="text-slate-300 text-sm leading-relaxed mb-6">
                   {t.welcomeMsg.split('\n').map((line, i) => <React.Fragment key={i}>{line}<br/></React.Fragment>)}
                 </p>
                 <div className="flex flex-col gap-4">
                   <button 
                     onClick={() => setShowClientLogin(true)} 
                     className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden"
                   >
                     <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                     <Lock size={18} className="text-slate-800" />
                     {t.clientLogin}
                   </button>
                   <button 
                     onClick={() => setShowClientRegister(true)} 
                     className="w-full py-3.5 px-4 bg-slate-800/80 backdrop-blur-sm border border-slate-700/50 text-slate-300 font-bold rounded-lg shadow-lg transition-all hover:bg-slate-700 hover:text-white hover:border-slate-500 hover:shadow-[0_4px_14px_0_rgba(255,255,255,0.05)] flex items-center justify-center gap-2"
                   >
                     <UserPlus size={18} />
                     {t.registerNewAccount}
                   </button>
                 </div>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-[#0B132B] text-slate-200 font-sans flex flex-col md:flex-row overflow-hidden">
      
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-[#070D1F] text-slate-300 flex flex-col border-b md:border-b-0 md:border-r border-slate-800 shrink-0 z-20">
        <div className="p-4 md:p-6 border-b border-slate-800 flex justify-between items-center md:block">
          <div>
            <div className="flex items-center gap-2">
              <img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-6 h-6 md:w-8 md:h-8 rounded object-cover" alt="VRS Logo" />
              <h1 className="text-white font-bold tracking-tight text-base md:text-lg">VRS (EXPERT ADVISOR)</h1>
            </div>
            <p className="hidden md:block text-[10px] uppercase tracking-widest mt-2 text-slate-400 font-semibold">VRS Community</p>
          </div>
          
          <div className="md:hidden flex items-center gap-3">
             <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white overflow-hidden border border-slate-600">
                {user.photoURL ? <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : 'AD'}
              </div>
             <button onClick={() => signOut(auth)} className="text-slate-400 hover:text-white p-1" title="Sign Out">
                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
             </button>
          </div>
        </div>
        <nav className="flex md:flex-col p-2 md:p-4 gap-2 overflow-x-auto md:overflow-visible hide-scrollbar">
          <div 
            onClick={() => setActiveTab('keys')}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 ${activeTab === 'keys' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <Key className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Product Keys</span>
          </div>
          <div 
            onClick={() => setActiveTab('ea')}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 ${activeTab === 'ea' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <Code className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">EA Code Source</span>
          </div>
          <div 
            onClick={() => setActiveTab('html')}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 ${activeTab === 'html' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <Code className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Web HTML Source</span>
          </div>
          {user?.email === 'mfrdotbiz@gmail.com' && (
          <div 
            onClick={() => setActiveTab('team')}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 ${activeTab === 'team' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Team Access</span>
          </div>
          )}
          <div 
            onClick={() => setActiveTab('clients')}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 ${activeTab === 'clients' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Clients</span>
          </div>
          <div 
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 ${activeTab === 'settings' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <span className="text-xs md:text-sm font-medium">Settings</span>
          </div>
        </nav>
        <div className="px-4 py-2 mt-auto">
                  </div>
        <div className="hidden md:block p-4 border-t border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-3 justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs text-white overflow-hidden">
                {user.photoURL ? <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : 'AD'}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-white leading-tight truncate w-32">{user.displayName || 'Admin'}</p>
                <p className="text-[10px] text-emerald-400">Connected</p>
              </div>
            </div>
            <button 
              onClick={() => signOut(auth)}
              className="text-slate-400 hover:text-white transition-colors"
              title="Sign Out"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        
        {/* Header */}
        <header className="h-16 bg-[#131E3A] border-b border-slate-800 flex items-center justify-between px-4 md:px-8 shrink-0">
          <h2 className="text-xl font-bold text-slate-200">{activeTab === 'keys' ? t.overview : activeTab === 'ea' ? t.eaSource : activeTab === 'html' ? t.htmlSource : activeTab === 'settings' ? t.adminSettings : activeTab === 'clients' ? t.manageClients : t.teamAccess}</h2>
          {activeTab === 'keys' && (
            <div className="flex items-center gap-4">
              <div className="px-3 py-1 bg-slate-800 rounded text-xs font-mono text-slate-400 border border-slate-800">
                Total Keys: {keys.length}
              </div>
            </div>
          )}
        </header>

        <div className="p-4 md:p-8 flex flex-col gap-4 md:gap-6 flex-1 overflow-auto">
          {activeTab === 'ea' ? (
            <div className="flex-1 flex flex-col bg-slate-900 rounded-xl overflow-hidden shadow-lg border border-slate-800">
              <div className="flex justify-between items-center p-4 border-b border-slate-800 bg-slate-900 shrink-0">
                <h3 className="text-sm font-bold text-slate-300 flex items-center gap-2">
                  <Code className="w-4 h-4 text-indigo-400" />
                  VRS-GriPX EA.mq5
                </h3>
                <button
                  onClick={handleCopyCode}
                  className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 text-xs font-bold rounded flex items-center gap-2 transition-colors"
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy Code'}
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4 bg-[#070D1F]">
                <pre className="text-[12px] font-mono text-slate-300 whitespace-pre-wrap font-medium">
                  {eaCode || 'Loading code...'}
                </pre>
              </div>
            </div>
          
          ) : activeTab === 'team' && user?.email === 'mfrdotbiz@gmail.com' ? (
            <div className="flex-1 flex flex-col gap-6">
              <div className="bg-[#131E3A] p-6 rounded-xl border border-slate-800 shadow-sm shrink-0">
                <h3 className="text-sm uppercase font-bold text-slate-200 tracking-wider mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4 text-indigo-500" />
                  Shared Access Management
                </h3>
                <p className="text-xs text-slate-400 mb-6">
                  Add team members' email addresses here. They will be able to log in with their Google account to view and manage license keys. Only you (mfrdotbiz@gmail.com) can add or remove members.
                </p>
                {user.email === 'mfrdotbiz@gmail.com' ? (
                  <form onSubmit={handleAddAdmin} className="flex gap-4 items-end max-w-md">
                    <div className="flex-1">
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Google Email Address</label>
                      <input
                        type="email"
                        value={newAdminEmail}
                        onChange={(e) => setNewAdminEmail(e.target.value)}
                        placeholder="colleague@gmail.com"
                        className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                        required
                      />
                    </div>
                    <button type="submit" className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded text-sm shadow transition-colors whitespace-nowrap">
                      Add Admin
                    </button>
                  </form>
                ) : (
                  <div className="p-4 bg-amber-50 text-amber-800 rounded border border-amber-200 text-sm font-medium">
                    Only the primary owner can manage team members.
                  </div>
                )}
              </div>
              
              <div className="flex-1 bg-[#131E3A] border border-slate-800 rounded-xl overflow-hidden shadow-sm flex flex-col min-h-0">
                <div className="p-4 border-b border-slate-800/50 bg-[#0A1024]">
                  <h3 className="text-sm font-bold text-slate-200 uppercase tracking-tight">Active Team Members</h3>
                </div>
                <div className="flex-1 overflow-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800">
                      <tr>
                        <th className="px-6 py-3 whitespace-nowrap">Email Address</th>
                        <th className="px-6 py-3 whitespace-nowrap">Role</th>
                        <th className="px-6 py-3 whitespace-nowrap text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      <tr className="hover:bg-[#050914]">
                        <td className="px-6 py-4 text-sm font-medium text-slate-200">mfrdotbiz@gmail.com</td>
                        <td className="px-6 py-4"><span className="px-2 py-1 bg-[#D4AF37]/20 text-[#F1C40F] rounded text-[10px] font-bold uppercase tracking-wider">Owner</span></td>
                        <td className="px-6 py-4 text-right"></td>
                      </tr>
                      {admins.map(admin => (
                        <tr key={admin.email} className="hover:bg-[#050914]">
                          <td className="px-6 py-4 text-sm font-medium text-slate-200">{admin.email}</td>
                          <td className="px-6 py-4"><span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold uppercase tracking-wider">Admin</span></td>
                          <td className="px-6 py-4 text-right">
                            {user.email === 'mfrdotbiz@gmail.com' && (
                              <button onClick={() => handleRemoveAdmin(admin.email)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors" title="Remove Access">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
                    ) : activeTab === 'settings' ? (
            <div className="flex-1 overflow-auto bg-[#131E3A] border border-slate-800 rounded-xl p-6 shadow-lg max-w-2xl mx-auto w-full mt-4">
              <h2 className="text-xl font-bold text-slate-200 mb-6">{t.adminSettings}</h2>
              <form onSubmit={handleSaveSettings} className="space-y-6">
                <div>
                                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Default Max Trial Claims</label>
                  <input
                    type="number"
                    min="0"
                    value={defaultMaxTrials}
                    onChange={(e) => setDefaultMaxTrials(parseInt(e.target.value) || 0)}
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-1"
                  />
                  <p className="text-xs text-slate-500 mb-6">Global limit for how many times a client can claim the free trial.</p>

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Default Trial Duration (Days)</label>
                  <input type="number" min="1" value={defaultTrialDays} onChange={(e) => setDefaultTrialDays(parseInt(e.target.value) || 3)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-6" />

                  

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.historyDays}</label>
                  <input
                    type="number"
                    value={historyDays}
                    onChange={(e) => setHistoryDays(Number(e.target.value))}
                    className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                    placeholder="e.g. 30"
                  />
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-slate-500">{t.historyDaysDesc}</p>
                    <button 
                      type="button" 
                      onClick={() => setShowClearHistoryConfirm(true)} 
                      disabled={clearingHistory}
                      className="px-3 py-1.5 bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 hover:text-rose-400 text-xs font-bold rounded transition-colors whitespace-nowrap ml-4 disabled:opacity-50"
                    >
                      {clearingHistory ? t.deleting : t.deleteAllNow}
                    </button>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-slate-800">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-slate-200">{t.eaUpdate}</h3>
                    <button
                      type="button"
                      onClick={() => setEaList([...eaList, { id: 'ea_' + Date.now(), name: 'New EA', link: '', description: '' }])}
                      className="px-3 py-1.5 bg-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/30 text-xs font-bold rounded transition-colors"
                    >
                      + {t.addEa}
                    </button>
                  </div>
                  <div className="space-y-6">
                    {eaList.map((ea, index) => (
                      <div key={ea.id} className="p-4 bg-[#050914] rounded-lg border border-slate-800 relative">
                        <button
                          type="button"
                          onClick={() => setEaList(eaList.filter((_, i) => i !== index))}
                          className="absolute top-2 right-2 text-rose-500 hover:text-rose-400 p-1"
                          title={t.removeEa}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <div className="space-y-4 mt-2">
                          <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.eaName}</label>
                            <input
                              type="text"
                              value={ea.name}
                              onChange={(e) => {
                                const newList = [...eaList];
                                newList[index].name = e.target.value;
                                setEaList(newList);
                              }}
                              className="w-full bg-[#131E3A] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.eaDownloadLink}</label>
                            <input
                              type="url"
                              value={ea.link}
                              onChange={(e) => {
                                const newList = [...eaList];
                                newList[index].link = e.target.value;
                                setEaList(newList);
                              }}
                              className="w-full bg-[#131E3A] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.eaDesc}</label>
                            <textarea
                              value={ea.description}
                              onChange={(e) => {
                                const newList = [...eaList];
                                newList[index].description = e.target.value;
                                setEaList(newList);
                              }}
                              rows={3}
                              className="w-full bg-[#131E3A] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                    {eaList.length === 0 && (
                      <p className="text-sm text-slate-500 text-center py-4">No EA added.</p>
                    )}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <h3 className="text-lg font-bold text-slate-200 mb-4">{t.extLinks}</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.whatsappLink}</label>
                      <input
                        type="url"
                        value={whatsappLink}
                        onChange={(e) => setWhatsappLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="e.g. https://chat.whatsapp.com/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.tutorialLink}</label>
                      <input
                        type="url"
                        value={tutorialLink}
                        onChange={(e) => setTutorialLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="e.g. https://youtube.com/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Subscription / Renew Link</label>
                      <input
                        type="url"
                        value={renewLink}
                        onChange={(e) => setRenewLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="e.g. https://toyyibpay.com/..."
                      />
                      <p className="text-xs text-slate-500 mt-2">This link will be displayed on the client portal if they have already claimed the Free Trial.</p>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 mt-4">Free Claim URL</label>
                      <input
                        type="url"
                        value={freeClaimLink}
                        onChange={(e) => setFreeClaimLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="e.g. https://claim.example.com"
                      />
                      <p className="text-xs text-slate-500 mt-2">This link is used when clients click the Free Claim button with a valid premium license.</p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4 pb-8">
                  <button
                    type="submit"
                    disabled={settingsLoading}
                    className="px-6 py-2 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded shadow-lg transition-all disabled:opacity-50"
                  >
                    {settingsLoading ? t.saving : t.saveSettings}
                  </button>
                </div>
              </form>
            </div>
          ) : activeTab === 'clients' ? (
            <div className="flex-1 flex flex-col gap-6">
              <div className="bg-[#131E3A] p-6 rounded-xl border border-slate-800 shadow-sm shrink-0">
                <h3 className="text-sm uppercase font-bold text-slate-200 tracking-wider mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4 text-indigo-500" />
                  Client Accounts Management
                </h3>
                <p className="text-xs text-slate-400 mb-6">
                  Register new clients here to give them access to the client portal. They can login using this email and password.
                </p>
                <form onSubmit={handleCreateClient} className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Client Email</label>
                    <input
                      type="email"
                      value={newClientEmail}
                      onChange={(e) => setNewClientEmail(e.target.value)}
                      placeholder="client@gmail.com"
                      className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Nama Penuh</label>
                    <input
                      type="text"
                      value={newClientName}
                      onChange={(e) => setNewClientName(e.target.value)}
                      placeholder="Ali Abu"
                      className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-400 mb-1">{t.password}</label>
                    <input
                      type="text"
                      value={newClientPassword}
                      onChange={(e) => setNewClientPassword(e.target.value)}
                      placeholder="Password Sementara"
                      className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 text-xs font-bold rounded flex items-center justify-center gap-2 transition-colors"
                  >
                    <Plus className="w-4 h-4" /> Register
                  </button>
                </form>
              </div>

              <div className="flex-1 flex flex-col bg-[#131E3A] rounded-xl overflow-hidden shadow-lg border border-slate-800">
                <div className="overflow-x-auto flex-1">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800 sticky top-0">
                      <tr>
                        <th className="px-6 py-3 whitespace-nowrap">Name</th>
                        <th className="px-6 py-3 whitespace-nowrap">Email</th>
                        <th className="px-6 py-3 whitespace-nowrap">{t.passwordPlaceholder}</th>
                        <th className="px-6 py-3 whitespace-nowrap">Max Trials</th>
                        <th className="px-6 py-3 whitespace-nowrap text-right">{t.actions}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clients.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-8 text-center text-slate-400 text-xs font-medium">
                            No registered clients.
                          </td>
                        </tr>
                      ) : (
                        clients.map(client => (
                          <tr key={client.id} className="hover:bg-[#050914]">
                            <td className="px-6 py-4 text-sm font-medium text-slate-200">{client.name}</td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-400">{client.email}</td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded font-mono text-xs">{client.password}</span>
                            </td>
                            <td className="px-6 py-4">
                              <input 
                                type="number" 
                                min="0"
                                defaultValue={client.maxTrials !== undefined ? client.maxTrials : defaultMaxTrials} 
                                onBlur={(e) => handleUpdateClientMaxTrials(client.id, parseInt(e.target.value))}
                                className="w-16 p-1 bg-slate-800 border border-slate-700 rounded text-slate-300 text-xs text-center" 
                              />
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button onClick={() => handleDeleteClient(client.email)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-500/10 rounded transition-colors" title="Delete Account">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : activeTab === 'html' ? (
            <div className="flex-1 flex flex-col bg-slate-900 rounded-xl overflow-hidden shadow-lg border border-slate-800">
              <div className="flex justify-between items-center p-4 border-b border-slate-800 bg-slate-900 shrink-0">
                <h3 className="text-sm font-bold text-slate-300 flex items-center gap-2">
                  <Code className="w-4 h-4 text-indigo-400" />
                  index.html (Single File)
                </h3>
                <button
                  onClick={handleCopyCode}
                  className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 text-xs font-bold rounded flex items-center gap-2 transition-colors"
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy HTML'}
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4 bg-[#070D1F]">
                <pre className="text-[12px] font-mono text-slate-300 whitespace-pre-wrap font-medium">
                  {htmlCode || 'Loading code...'}
                </pre>
              </div>
            </div>
          ) : (
            <>
          {/* Create Form */}
          <div className="bg-[#131E3A] p-4 rounded-xl border border-slate-800 shadow-sm shrink-0">
            <h3 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-3 flex items-center gap-2">
              <Key className="w-3 h-3 text-indigo-500" />
              Generate New Key
            </h3>
            <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-3 md:gap-4 items-stretch sm:items-end">
              <div className="flex-1 w-full">
                <input
                  id="customerEmail"
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="Customer Email (e.g. mfrdotbiz@gmail.com)"
                  className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                  required
                  maxLength={100}
                />
              </div>
              <div className="flex-1 w-full">
                <input
                  id="customerName"
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Customer Name (e.g. Acme Corp)"
                  className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                  required
                  maxLength={100}
                />
              </div>
              <div className="flex-1 w-full">
                <input
                  id="allowedAccounts"
                  type="text"
                  value={allowedAccounts}
                  onChange={(e) => setAllowedAccounts(e.target.value)}
                  placeholder="MT5 Account Names (e.g. John Doe, Ali Abu)"
                  className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                />
              </div>
              <div className="flex-1 w-full flex gap-2">
                <select
                  value={expiryPreset}
                  onChange={(e) => handlePresetChange(e.target.value)}
                  className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white font-medium"
                >
                  <option value="lifetime">Lifetime</option>
                  <option value="1_month">1 Bulan</option>
                  <option value="3_months">3 Bulan</option>
                  <option value="6_months">6 Bulan</option>
                  <option value="1_year">1 Tahun</option>
                  <option value="custom">Custom Date</option>
                </select>
                {expiryPreset === 'custom' && (
                  <input
                    id="expiryDate"
                    type="datetime-local"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                  />
                )}
              </div>
              <button
                type="submit"
                disabled={isCreating || !customerEmail.trim() || !customerName.trim()}
                className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded text-xs shadow-lg shadow-[#D4AF37]/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2 h-[34px]"
              >
                <Plus className="w-4 h-4" />
                Generate Key
              </button>
            </form>
          </div>

          {/* Keys List */}
          <div className="flex-1 bg-[#131E3A] border border-slate-800 rounded-xl overflow-hidden shadow-sm flex flex-col min-h-0">
            <div className="p-4 border-b border-slate-800/50 bg-[#0A1024] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shrink-0">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-tight">Recent License Generations</h3>
              <input
                type="text"
                placeholder="Search email / name / key..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-[#050914] text-white rounded px-3 py-1.5 text-xs border border-slate-800 focus:border-[#D4AF37] outline-none w-full sm:w-64"
              />
            </div>
            
            <div className="flex-1 overflow-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#050914] text-slate-400 text-[10px] uppercase font-bold border-b border-slate-800 sticky top-0 z-10">
                  <tr>
                    <th className="px-6 py-3 whitespace-nowrap">License Key</th>
                    <th className="px-6 py-3 whitespace-nowrap">Customer Email</th>
                    <th className="px-6 py-3 whitespace-nowrap">Customer</th>
                    <th className="px-6 py-3 whitespace-nowrap">Status</th>
                    <th className="px-6 py-3 whitespace-nowrap">Allowed Accounts</th>
                    <th className="px-6 py-3 whitespace-nowrap">Expires</th>
                    <th className="px-6 py-3 whitespace-nowrap">Created At</th>
                    <th className="px-6 py-3 whitespace-nowrap text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {loading ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-8 text-center text-slate-400 text-xs font-medium">
                        Loading keys...
                      </td>
                    </tr>
                  ) : keys.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                        <Key className="w-8 h-8 mx-auto text-slate-300 mb-3" />
                        <p className="text-sm font-semibold text-slate-200">No license keys found.</p>
                        <p className="text-xs">Generate one above to get started.</p>
                      </td>
                    </tr>
                  ) : (
                    keys.filter(k => k.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) || (k.customerName && k.customerName.toLowerCase().includes(searchTerm.toLowerCase())) || k.key.toLowerCase().includes(searchTerm.toLowerCase())).map((k) => (
                      <tr key={k.id} className="hover:bg-[#050914] group">
                        <td className="px-6 py-4 font-mono text-xs text-[#D4AF37] whitespace-nowrap font-medium">
                          <div className="flex items-center gap-2">
                            <span>{k.key}</span>
                            <button
                              onClick={() => handleCopyKey(k.key)}
                              className="p-1 text-slate-400 hover:text-[#D4AF37] hover:bg-[#D4AF37]/10 rounded transition-colors"
                              title="Copy License Key"
                            >
                              {copiedKey === k.key ? <CheckCircle className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-xs font-medium text-slate-200 whitespace-nowrap">{k.customerEmail}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-slate-200 whitespace-nowrap">{k.customerName}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                            k.status === 'active' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                            k.status === 'revoked' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                            'bg-slate-800 text-slate-400'
                          }`}>
                            {k.status === 'active' && <CheckCircle className="w-3 h-3" /> || k.status === 'revoked' && <Ban className="w-3 h-3" /> || k.status === 'expired' && <Clock className="w-3 h-3" />}
                            {k.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-xs font-semibold text-slate-400 whitespace-nowrap max-w-[150px] truncate" title={k.allowedAccounts || 'Any Account'}>
                          {k.allowedAccounts || 'Any Account'}
                        </td>
                        <td className="px-6 py-4 text-xs font-semibold text-slate-400 whitespace-nowrap">
                          {k.expiresAt ? format(new Date(k.expiresAt), 'MMM d, yyyy HH:mm') : 'Lifetime'}
                        </td>
                        <td className="px-6 py-4 text-xs text-slate-400 whitespace-nowrap font-medium">
                          {format(new Date(k.createdAt), 'MMM d, yyyy HH:mm')}
                        </td>
                        <td className="px-6 py-4 text-right space-x-2 whitespace-nowrap transition-opacity">
                          <button 
                            onClick={() => setRenewKey({id: k.id, expiry: k.expiresAt || '', allowedAccounts: k.allowedAccounts || '', email: k.customerEmail, keyString: k.key})}
                            className="p-1.5 text-slate-400 hover:text-[#D4AF37] hover:bg-[#D4AF37]/10 rounded transition-colors"
                            title="Edit Expiry & Accounts"
                          >
                            <Clock className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleToggleStatus(k)}
                            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
                            title={k.status === 'active' ? 'Revoke Key' : 'Activate Key'}
                          >
                            <Ban className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(k.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                            title="Delete Key"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
          </>
          )}
        </div>

        {/* Edit Modal */}
        {renewKey && (
          <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
            <div className="bg-[#131E3A] rounded-xl shadow-lg max-w-sm w-full p-6">
              <h3 className="text-lg font-bold text-slate-200 mb-2">Edit License</h3>
              <p className="text-sm text-slate-400 mb-4">Edit expiry and allowed accounts.</p>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Expiry Date</label>
                  <div className="flex gap-2">
                    <select
                      value={renewExpiryPreset}
                      onChange={(e) => handleRenewPresetChange(e.target.value, renewKey.expiry)}
                      className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white font-medium"
                    >
                      <option value="custom">Custom Date</option>
                      <option value="lifetime">Lifetime</option>
                      <option value="1_month">1 Month (+ from today)</option>
                      <option value="3_months">3 Months (+ from today)</option>
                      <option value="6_months">6 Months (+ from today)</option>
                      <option value="1_year">1 Year (+ from today)</option>
                    </select>
                    <input
                      type="datetime-local"
                      value={renewKey.expiry}
                      onChange={(e) => {
                        setRenewExpiryPreset('custom');
                        setRenewKey({...renewKey, expiry: e.target.value});
                      }}
                      className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Allowed Accounts (Comma separated)</label>
                  <input
                    type="text"
                    value={renewKey.allowedAccounts || ''}
                    onChange={(e) => setRenewKey({...renewKey, allowedAccounts: e.target.value})}
                    placeholder="e.g. Ali Abu, John Doe"
                    className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <button 
                  onClick={() => setRenewKey(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 rounded"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleRenew(renewKey.id, renewKey.expiry, renewKey.allowedAccounts)}
                  className="px-4 py-2 text-sm font-medium text-slate-900 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] font-bold rounded"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}

        {deleteConfirm && (
          <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
            <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-lg max-w-sm w-full p-6">
              <h3 className="text-lg font-bold text-rose-500 mb-2">Confirm Delete</h3>
              <p className="text-sm text-slate-400 mb-4">
                Are you sure you want to delete this {deleteConfirm.type === 'client' ? 'client account' : 'license'}? Please enter the admin password to confirm.
              </p>
              
              <form onSubmit={executeDelete} className="space-y-4">
                <div>
                  <input
                    type="password"
                    value={deletePasswordInput}
                    onChange={(e) => setDeletePasswordInput(e.target.value)}
                    placeholder={`${t.passwordPlaceholder} Admin`}
                    className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-colors outline-none text-white placeholder:text-slate-500"
                    autoFocus
                    required
                  />
                </div>
                
                <div className="flex justify-end gap-3 pt-2">
                  <button 
                    type="button"
                    onClick={() => {
                      setDeleteConfirm(null);
                      setDeletePasswordInput('');
                    }}
                    className="px-4 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 rounded"
                  >Cancel</button>
                  <button 
                    type="submit"
                    className="px-4 py-2 text-sm font-bold bg-rose-600 hover:bg-rose-500 text-white rounded transition-colors"
                  >Confirm & Delete</button>
                </div>
              </form>
            </div>
          </div>
        )}


      {/* Clear History Confirmation Modal */}
      {showClearHistoryConfirm && (
        <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#131E3A] border border-rose-500/30 rounded-xl shadow-2xl max-w-sm w-full overflow-hidden">
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-rose-500" />
              </div>
              <h3 className="text-lg font-bold text-slate-200 mb-2">{t.areYouSure}</h3>
              <p className="text-sm text-slate-400 mb-6">
                This action will delete ALL License History & Status records for ALL clients. This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowClearHistoryConfirm(false)}
                  disabled={clearingHistory}
                  className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 font-medium rounded-lg hover:bg-slate-700 transition-colors disabled:opacity-50"
                >Cancel</button>
                <button
                  onClick={executeClearAllHistory}
                  disabled={clearingHistory}
                  className="flex-1 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg transition-colors disabled:opacity-50"
                >
                  {clearingHistory ? t.deleting : t.confirmDeleteAll}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      </main>
    </div>
  );
}
