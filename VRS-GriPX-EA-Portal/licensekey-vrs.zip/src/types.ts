export type LicenseStatus = 'active' | 'revoked' | 'expired';

export interface LicenseKey {
  id: string;
  key: string;
  customerEmail: string;
  customerName: string;
  status: LicenseStatus;
  createdAt: string | Date;
  ownerUid: string;
  expiresAt?: string;
  allowedAccounts?: string;
}
