export const EA_CODE = String.raw`
//+------------------------------------------------------------------+
//|                                                 VRS-GriPX EA.mq5 |
//|                                      COPYRIGHT 2026, TEAM VRS    |
//|                                             https://chat.whatsapp.com/J5qaR7JZdNaAp4PwWPiYSf |
//+------------------------------------------------------------------+
#property copyright   "Copyright 2026, Team VRS"
#property link        "https://chat.whatsapp.com/J5qaR7JZdNaAp4PwWPiYSf"
#property version     "3.0"
#property description "VRS-GriPX EA: Smart Grid Integrated with Cyberpunk UI & News Filter"

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\OrderInfo.mqh>
#include <Trade\SymbolInfo.mqh>
#include <Trade\AccountInfo.mqh>

CTrade         Trade;
CPositionInfo  PosInfo;
CSymbolInfo    m_symbol;

//+------------------------------------------------------------------+
//| Enumerations                                                     |
//+------------------------------------------------------------------+
enum ENUM_STRATEGY
{
   RSI_MODE       = 1,
   Fixed_Points   = 2,
   MANUAL         = 3
};

enum ENUM_TRADE_MODE
{
   BUY_ONLY  = 0,
   SELL_ONLY = 1,
   BOTH      = 2
};

enum ENUM_NEWS_SOURCE
{
   SOURCE_MT5, 
   SOURCE_FF,  
   SOURCE_BOTH 
};

//--- Cyberpunk Color Palette ---
color cp_ui_bg  = C'10,12,18';   
color cp_pink   = C'255,0,127';  
color cp_cyan   = C'0,255,200';  
color cp_purple = C'153,50,204'; 
color cp_yellow = C'255,230,0';  
color cp_orange = C'255,100,0';  
color cp_blue   = C'50,150,255'; 

//+------------------------------------------------------------------+
//| Input Parameters                                                 |
//+------------------------------------------------------------------+
input group "====== LICENSE SETTINGS ======"
input string             USER_LICENSE_KEY = "ENTER_YOUR_KEY_HERE";
input string             MQID_NOTI        = ""; // MetaQuotes ID for notifications (Optional)

input group "====== CORE STRATEGY ======"
input ENUM_TRADE_MODE    MODE             = BOTH;
input ENUM_STRATEGY      STRATEGY         = RSI_MODE;
input int                RSI_PERIOD       = 10;       // RSI Period
input int                UP_LEVEL         = 70;       // RSI Upper Level (Sell Signal)
input int                DN_LEVEL         = 30;       // RSI Lower Level (Buy Signal)
input ENUM_TIMEFRAMES    RSI_TIMEFRAME    = PERIOD_M5;// RSI Timeframe
input int                DISTANCE         = 50;       // Distance in pips (Fixed Points mode)
input int                TIMER_SEC        = 10;       // Timer interval in seconds

input group "====== GRID & OVERLAP ======"
input int                STEP_ORDERS      = 100;      // Grid step in pips
input double             STEP_MULTIPLIER  = 1.1;      // Step multiplier
input int                MAX_STEP         = 1000;     // Maximum grid step
input int                OVERLAP_ORDERS   = 5;        // Min orders before overlap activates
input int                OVERLAP_PIPS     = 10;       // Min profit pips to close overlapping orders

input group "====== LOT & RISK MANAGEMENT ======"
input double             VOLUME           = 0.01;     // Base lot size
input int                FROM_BALANCE     = 10000;    // Balance per base lot (0 = disabled)
input double             RISK_PER_TRADE   = 0.0;      // Risk % per trade (0 = disabled)
input double             LOT_MULTIPLIER   = 1.5;      // Lot multiplier for grid
input double             MAX_LOT          = 999.9;    // Maximum lot size

input group "====== SL, TP & TRAILING ======"
input int                STOPLOSS         = -1;       // Stop Loss in pips (-1 = disabled)
input int                TAKEPROFIT       = 500;      // Take Profit in pips (-1 = disabled)
input int                BREAKEVEN_STOP   = -1;       // Breakeven activation level (-1 = disabled)
input int                BREAKEVEN_STEP   = 10;       // Breakeven step in pips
input int                TRAILING_STOP    = 50;       // Trailing stop level (-1 = disabled)
input int                TRAILING_STEP    = 50;       // Trailing step in pips

input group "====== NEWS FILTER SETTINGS ======"
input bool               Use_News_Filter      = true;             // Enable News Filter
input ENUM_NEWS_SOURCE   News_Source          = SOURCE_BOTH;      // News Data Source
input string             Target_News_Currency = "USD";            // Target Currency
input int                Malaysia_GMT_Offset  = 8;                // Your Local GMT Offset (e.g., +8)
input int                FF_GMT_Offset        = -4;               // ForexFactory GMT Offset
input int                Mins_Before_News     = 60;               // Mins to Stop Before News
input int                Mins_After_News      = 60;               // Mins to Wait After News
input bool               Filter_High_Impact   = true;             // Filter High Impact News
input bool               Filter_Med_Impact    = true;             // Filter Medium Impact News
input bool               Filter_Low_Impact    = false;            // Filter Low Impact News

input group "====== TIME & MISC ======"
input string             START_TIME       = "00:00";  // Start time (00:00 = disabled)
input string             END_TIME         = "00:00";  // End time   (00:00 = disabled)
input int                MAGIC_NUMBER     = 227;      // Magic Number
input string             ORDERS_COMMENT   = "VRS-GriPX EA"; // Order comment

input group "====== UI SETTINGS ======"
input bool               Show_Dashboard   = true;     // Show Cyberpunk Dashboard
input bool               Show_Buttons     = true;     // Show Manual Trade Buttons

//+------------------------------------------------------------------+
//| Global Variables                                                 |
//+------------------------------------------------------------------+
bool   CLOSE_BUY  = false, CLOSE_SELL = false, CLOSE_ALL  = false;
double ZEROLEVEL_ALL = 0, ZEROLEVEL_BUY = 0, ZEROLEVEL_SELL = 0;
double TRAILINGSTOP_BUY = 0, TRAILINGSTEP_BUY = 0, TRAILINGSTOP_SELL = 0, TRAILINGSTEP_SELL = 0;
double BREAKEVENSTOP_BUY = 0, BREAKEVENSTEP_BUY = 0, BREAKEVENSTOP_SELL = 0, BREAKEVENSTEP_SELL = 0;
double TAKEPROFIT_BUY = 0, STOPLOSS_BUY = 0, TAKEPROFIT_SELL = 0, STOPLOSS_SELL = 0;
double BUY_PROFIT = 0, SELL_PROFIT = 0, BUY_LOTS = 0, SELL_LOTS = 0;
double TICKVALUE = 0;
int    SPREAD = 0;
int    PREV_BUYS = 0, PREV_SELLS = 0;
bool   DEINIT = false, FIRST_RUN = true;
int    BUYS = 0, SELLS = 0, BUYLIMITS = 0, SELLLIMITS = 0, BUYSTOPS = 0, SELLSTOPS = 0;

color  BUTTONL_CLR = clrNONE;
double LAST_BID = 0, TEMP_LOT = 0, LAST_LOT = 0;
int    WIN_TYPE = 0, WIN_TICKET = 0;
double WIN_PROFIT = 0, WIN_LOT = 0;
int    LOSS_TYPE = 0, LOSS_TICKET = 0;
double LOSS_PROFIT = 0, LOSS_LOT = 0;
double ZEROLEVEL = 0, OVERLAP_CLOSE = 0;
double LAST_BUY_PRICE = 0, LAST_BUY_LOT = 0, LAST_SELL_PRICE = 0, LAST_SELL_LOT = 0;
double GRID_BUY_PRICE = 0, GRID_SELL_PRICE = 0;
bool   SIGNAL = true, SIGNAL_BUY = true, SIGNAL_SELL = true;
double BUY_PRICE = 0.0, SELL_PRICE = 0.0;
int    INP_TIME = 0;
datetime TIME_CURRENT = 0, TIMER_VAR = 0;

int RSI_HANDLE = INVALID_HANDLE;

// News Filter Globals
datetime last_news_fetch = 0;
bool     is_news_blocked = false;
bool     last_news_blocked_state = false;
datetime next_news_time_myt = 0;
string   next_news_impact_str = "None";
double   max_drawdown_usd = 0;
double   peak_equity = 0;

struct FF_Event { datetime time_utc; int impact; string currency; };
FF_Event ff_events[];

struct DailyNews { datetime time_myt; int impact; };
DailyNews today_news_list[];

//+------------------------------------------------------------------+
//| Filling Mode Detection                                           |
//+------------------------------------------------------------------+
ENUM_ORDER_TYPE_FILLING GetFillingMode(string symbol)
{
   long filling = SymbolInfoInteger(symbol, SYMBOL_FILLING_MODE);
   if((filling & SYMBOL_FILLING_FOK) != 0) return ORDER_FILLING_FOK;
   if((filling & SYMBOL_FILLING_IOC) != 0) return ORDER_FILLING_IOC;
   return ORDER_FILLING_RETURN;
}

string g_license_expiry = "Lifetime";
datetime g_license_expiry_time = 0;
bool g_is_expired = false;
bool g_is_trial = false;



//+------------------------------------------------------------------+
//| Firebase License Validator (Firestore REST API)                  |
//+------------------------------------------------------------------+
bool ValidateLicenseFirebase(string licenseKey, bool silent = false) 
{
    if(licenseKey == "" || licenseKey == "ENTER_YOUR_KEY_HERE" || licenseKey == "PLEASE-ENTER-KEY-HERE") {
        Alert("Please enter the License Key in the input parameter section!");
        return false;
    }
    
    string project_id = "licensekey-ea";
    string database_id = "(default)";
    string api_key = "AIzaSyDW8z9Ef9PgvVF4dbYO4VY7O_Jt_37Vt9E";
    
    string url = "https://firestore.googleapis.com/v1/projects/" + project_id + "/databases/" + database_id + "/documents/licenseKeys/" + licenseKey + "?key=" + api_key;
    
    string cookie = "";
    string headers = "";
    int timeout = 5000;
    char post[], result[];
    string resultStr;
    
    int res = WebRequest("GET", url, cookie, NULL, timeout, post, 0, result, headers);
    
    if (res == 200) 
    {
        resultStr = CharArrayToString(result);
        
        // Clean the string (remove spaces, newlines, carriage returns) for accurate matching
        StringReplace(resultStr, " ", "");
        StringReplace(resultStr, "\n", "");
        StringReplace(resultStr, "\r", "");
        
        if (StringFind(resultStr, "\"stringValue\":\"active\"") > 0) 
        {
            if (StringFind(resultStr, "\"isTrial\":{\"booleanValue\":true}") > 0 || StringFind(licenseKey, "TRIAL-") == 0) {
                g_is_trial = true;
            } else {
                g_is_trial = false;
            }
            
            // Check for expiration date
            int expPos = StringFind(resultStr, "\"expiresAt\":{\"stringValue\":\"");
            if (expPos > 0) {
                int dateStart = expPos + 28; // length of \`"expiresAt":{"stringValue":"\`
                int dateEnd = StringFind(resultStr, "\"", dateStart);
                if (dateEnd > dateStart) {
                    string expDateStr = StringSubstr(resultStr, dateStart, dateEnd - dateStart);
                    
                    // expDateStr can be "YYYY-MM-DD" or "YYYY-MM-DDThh:mm"
                    string dtParts[];
                    StringSplit(expDateStr, 'T', dtParts);
                    
                    string dateParts[];
                    StringSplit(dtParts[0], '-', dateParts);
                    
                    if (ArraySize(dateParts) == 3) {
                        MqlDateTime dt;
                        dt.year = (int)StringToInteger(dateParts[0]);
                        dt.mon = (int)StringToInteger(dateParts[1]);
                        dt.day = (int)StringToInteger(dateParts[2]);
                        
                        if (ArraySize(dtParts) == 2) {
                            string timeParts[];
                            StringSplit(dtParts[1], ':', timeParts);
                            if (ArraySize(timeParts) >= 2) {
                                dt.hour = (int)StringToInteger(timeParts[0]);
                                dt.min = (int)StringToInteger(timeParts[1]);
                                dt.sec = 0;
                            } else {
                                dt.hour = 23; dt.min = 59; dt.sec = 59;
                            }
                        } else {
                            dt.hour = 23; dt.min = 59; dt.sec = 59;
                        }
                        
                        datetime expTimeUTC = StructToTime(dt);
                        datetime expTimeMYT = expTimeUTC + (Malaysia_GMT_Offset * 3600);
                        string displayDate = TimeToString(expTimeMYT, TIME_DATE|TIME_MINUTES);
                        
                        g_license_expiry_time = expTimeMYT; // Simpan masa luput
                        
                        // Use Malaysia timezone (MYT) for expiration check during OnInit
                        datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
                        if (MQID_NOTI != "") {
                            int daysLeft = (int)((g_license_expiry_time - myt_now) / 86400);
                            if (daysLeft == 7 || daysLeft == 3) {
                                SendNotification("VRS Alert : License key expires in " + IntegerToString(daysLeft) + " days. Please contact admin to renew.");
                            }
                        }
                        if (myt_now >= g_license_expiry_time) {
                            if (!silent) Alert("Your license has EXPIRED on " + displayDate + "! EA hanya akan manage existing positions to close in profit.");
                            g_is_expired = true;
                            // Jangan return false di sini, benarkan EA start supaya ia boleh close entry
                        }
                        g_license_expiry = displayDate;
                    }
                }
            } else {
                g_license_expiry = "Lifetime";
                g_license_expiry_time = 0;
            }
            
            // --- MT5 ACCOUNT NAME CHECK MT5 ---
            int accPos = StringFind(resultStr, "\"allowedAccounts\":{\"stringValue\":\"");
            if (accPos > 0) {
                int accStart = accPos + 34; // length of allowedAccounts... stringValue
                int accEnd = StringFind(resultStr, "\"", accStart);
                if (accEnd > accStart) {
                    string allowedAccs = StringSubstr(resultStr, accStart, accEnd - accStart);
                    
                    string currentAcc = AccountInfoString(ACCOUNT_NAME);
                    StringReplace(currentAcc, " ", "");
                    StringToUpper(currentAcc);
                    
                    string accList[];
                    StringSplit(allowedAccs, ',', accList);
                    bool accMatched = false;
                    
                    for (int i=0; i<ArraySize(accList); i++) {
                        string a = accList[i];
                        StringReplace(a, " ", "");
                        StringToUpper(a);
                        if (a == currentAcc || a == "") {
                            accMatched = true;
                            break;
                        }
                    }
                    
                    if (allowedAccs == "" || allowedAccs == "ANY") accMatched = true;
                    
                    if (!accMatched) {
                        if (!silent) Alert("License SAH, but your MT5 Account Name (" + AccountInfoString(ACCOUNT_NAME) + ") is NOT ALLOWED for this license!");
                        g_is_expired = true;
                        return false;
                    }
                }
            }
            
            datetime myt_now_check = TimeGMT() + (Malaysia_GMT_Offset * 3600);
            if (g_license_expiry_time > 0 && myt_now_check >= g_license_expiry_time) {
                // expired date reached
                g_is_expired = true;
            } else {
                if (!silent) Print("🔥 [FIREBASE] License SAH dan AKTIF!");
                g_is_expired = false;
            }
            return true;
        } 
        else if (StringFind(resultStr, "\"stringValue\":\"revoked\"") > 0) 
        {
            Alert("Your license has been REVOKED!");
            ExpertRemove();
            return false;
        }
                else if (StringFind(resultStr, "\"stringValue\":\"expired\"") > 0) 
        {
            Alert("Your license has EXPIRED! Existing positions will be managed to Close in Profit.");
            g_is_expired = true;
            return true;
        }
        else 
        {
            if (!silent) Alert("unknown license status. Please contact admin.");
            Print("Raw response: ", CharArrayToString(result));
            return false;
        }
    } 
    else if (res == 404) 
    {
        Alert("License Key not found (Invalid)! Please check your key again.");
        return false;
    } 
    else if (res == -1)
    {
        Alert("WEBREQUEST ERROR! Please 'Allow WebRequest' for URL: https://firestore.googleapis.com di menu Tools -> Options -> Expert Advisors.");
        return false;
    }
    else 
    {
        Alert("Failed to connect to Firebase server. Ralat kod: ", res);
        return false;
    }
}

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
{
   Comment("Checking Firebase License system...");
   
   // --- FIREBASE LICENSE CHECK ---
   if (!ValidateLicenseFirebase(USER_LICENSE_KEY)) 
   {
       return(INIT_FAILED);
   }
   // ------------------------------
   
   Comment("VRS-GriPX EA - Initializing...");
   m_symbol.Name(_Symbol);
   
   INP_TIME = (TIMER_SEC > 60) ? 60 : TIMER_SEC;
   TEMP_LOT = VOLUME;
   
   RSI_HANDLE = iRSI(_Symbol, RSI_TIMEFRAME, RSI_PERIOD, PRICE_CLOSE);
   if(RSI_HANDLE == INVALID_HANDLE) {
      Print("ERROR: Failed to create RSI handle."); return(INIT_FAILED);
   }

   EventSetTimer(1); // 1-second timer for logic

   LAST_BID  = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   TICKVALUE = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   peak_equity = AccountInfoDouble(ACCOUNT_EQUITY);

   Trade.SetExpertMagicNumber(MAGIC_NUMBER == -1 ? 0 : MAGIC_NUMBER);
   Trade.SetDeviationInPoints(10);
   Trade.SetTypeFilling(GetFillingMode(_Symbol));

   if(!MQLInfoInteger(MQL_OPTIMIZATION) && !MQLInfoInteger(MQL_TESTER))
   {
      ChartSetInteger(0, CHART_SHOW_GRID, false);
      ChartSetInteger(0, CHART_MODE, CHART_CANDLES);
      ChartSetInteger(0, CHART_COLOR_BACKGROUND, clrBlack); 
      ChartSetInteger(0, CHART_COLOR_FOREGROUND, clrWhite);
      ChartSetInteger(0, CHART_COLOR_CANDLE_BULL, cp_cyan);
      ChartSetInteger(0, CHART_COLOR_CANDLE_BEAR, cp_pink);
      
      if(Show_Dashboard) CreateDashboard();
      if(Show_Buttons) DRAW_BUTTON();
   }
   
   if(Use_News_Filter && (News_Source == SOURCE_FF || News_Source == SOURCE_BOTH)) FetchFFNews();
   UpdateNextNewsInfo();

   if (MQID_NOTI != "") {
      string expireStr = (g_license_expiry_time > 0) ? TimeToString(g_license_expiry_time, TIME_DATE) : "Lifetime";
      SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\nLicense expires on: " + expireStr);
   } 

   Comment("");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   string lotText = ObjectGetString(0, "BUTTON_LOT", OBJPROP_TEXT);
   if(lotText != "") LAST_LOT = StringToDouble(lotText);

   EventKillTimer();
   DEINIT = true;

   if(RSI_HANDLE != INVALID_HANDLE) IndicatorRelease(RSI_HANDLE);

   DEINIT_HLINE();
   DEINIT_BUTTON();
   ObjectsDeleteAll(0, "VRS_UI_");
   Comment("");
}

//+------------------------------------------------------------------+
//| Timer                                                            |
//+------------------------------------------------------------------+
void OnTimer()
{
   if(Use_News_Filter && (TimeCurrent() - last_news_fetch >= 3600)) {
       if(News_Source == SOURCE_FF || News_Source == SOURCE_BOTH) FetchFFNews();
       UpdateNextNewsInfo();

   
       last_news_fetch = TimeCurrent();
   }
   OnTick();
}

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id == CHARTEVENT_OBJECT_CLICK) ON_CHART_EVENTS();
}

//+------------------------------------------------------------------+
//| Main tick function                                               |
//+------------------------------------------------------------------+
void OnTick()
{
   if (is_news_blocked && !last_news_blocked_state && MQID_NOTI != "") {
      string timeStr = TimeToString(next_news_time_myt, TIME_MINUTES);
      SendNotification("VRS Alert : No entry for now. " + next_news_impact_str + " Impact News will occur at " + timeStr);
   }
   last_news_blocked_state = is_news_blocked;

   if(!m_symbol.RefreshRates()) return;
   
   // --- PERIODIC FIREBASE LICENSE CHECK (Every 60 seconds) ---
   static datetime last_firebase_check = 0;
   if(TimeCurrent() - last_firebase_check >= 60) {
       last_firebase_check = TimeCurrent();
       ValidateLicenseFirebase(USER_LICENSE_KEY, true);
   }
   
   // --- LICENSE EXPIRATION REAL-TIME CHECK ---
   if (g_license_expiry_time > 0) {
      datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
      if (myt_now >= g_license_expiry_time) {
         if (!g_is_expired) {
             Alert("Your license has EXPIRED (" + g_license_expiry + ")! EA will not open new entries, existing positions will be managed to close in profit.");
             g_is_expired = true;
         }
      }
   }

   // UI Updates
   if(!MQLInfoInteger(MQL_OPTIMIZATION) && !MQLInfoInteger(MQL_TESTER))
   {
      double current_equity = AccountInfoDouble(ACCOUNT_EQUITY);
      if(current_equity > peak_equity) peak_equity = current_equity;
      double current_dd = peak_equity - current_equity;
      if(current_dd > max_drawdown_usd) max_drawdown_usd = current_dd;

      if(Show_Dashboard) UpdateDashboard();
      if(Show_Buttons) DRAW_BUTTON();
      HLINE();
   }
   
   if (g_is_expired) {
      Comment("STATUS: EA EXPIRED! Please renew license anda.\nExisting positions managed for Close Profit.\nNew entry has been stopped.");
      
      int B, S, BL, SL, BS, SS;
      COUNT_ORDERS(B, S, BL, SL, BS, SS, MAGIC_NUMBER);
      if (B == 0 && S == 0) {
         // Padam semua pending orders
         for (int i = OrdersTotal() - 1; i >= 0; i--) {
            ulong ticket = OrderGetTicket(i);
            if (ticket != 0 && OrderGetString(ORDER_SYMBOL) == _Symbol && ((long)OrderGetInteger(ORDER_MAGIC) == MAGIC_NUMBER || MAGIC_NUMBER == -1)) {
               Trade.OrderDelete(ticket);
            }
         }
         ExpertRemove(); // Berhentikan EA sepenuhnya dari chart
         return;
      }
      // Biarkan pelaksanaan diteruskan supaya Trailing Stop, TP, dan Grid berjalan.
   }

   is_news_blocked = CheckNewsBlock();
   if (g_is_expired) is_news_blocked = true; // Paksa block entry baru jika expired
   GET_TICKVALUE();
   BUY_PROFIT = BUY_LOTS = SELL_PROFIT = SELL_LOTS = 0;
   TOTAL_VALUE(BUY_PROFIT, BUY_LOTS, SELL_PROFIT, SELL_LOTS, MAGIC_NUMBER);
   BUYS = SELLS = BUYLIMITS = SELLLIMITS = BUYSTOPS = SELLSTOPS = 0;
   COUNT_ORDERS(BUYS, SELLS, BUYLIMITS, SELLLIMITS, BUYSTOPS, SELLSTOPS, MAGIC_NUMBER);

   if(OVERLAP_ORDERS > 0 && BUYS + SELLS >= OVERLAP_ORDERS) OVERLAP(-1);

   if(BUYS > 0) {
      if(TRAILING_STOP > 0)  VIRTUAL_TRAILINGSTOP((int)POSITION_TYPE_BUY);
      if(BREAKEVEN_STOP > 0) VIRTUAL_BREAKEVEN((int)POSITION_TYPE_BUY);
      if(STOPLOSS + TAKEPROFIT > 0) VIRTUAL_STOPLOSS_TAKEPROFIT((int)POSITION_TYPE_BUY);
   }

   if(SELLS > 0) {
      if(TRAILING_STOP > 0)  VIRTUAL_TRAILINGSTOP((int)POSITION_TYPE_SELL);
      if(BREAKEVEN_STOP > 0) VIRTUAL_BREAKEVEN((int)POSITION_TYPE_SELL);
      if(STOPLOSS + TAKEPROFIT > 0) VIRTUAL_STOPLOSS_TAKEPROFIT((int)POSITION_TYPE_SELL);
   }

   LAST_BUY_PRICE = LAST_BUY_LOT = LAST_SELL_PRICE = LAST_SELL_LOT = 0;
   OPENED_VALUES(LAST_BUY_PRICE, LAST_BUY_LOT, LAST_SELL_PRICE, LAST_SELL_LOT);

   if(WORKING_HOURS(START_TIME, END_TIME))
   {
      double LOT = LOT_CALCULATE(RISK_PER_TRADE, STOPLOSS, FROM_BALANCE, VOLUME);

      //--- STRATEGY 1: RSI Mode
      if(STRATEGY == RSI_MODE)
      {
         double rsiValue = GET_RSI_VALUE(1);

         if(CLOSE_SELL == false && SELLS == 0 && rsiValue >= UP_LEVEL) {
            if(!is_news_blocked) {
               if(MODE == BOTH || MODE == SELL_ONLY) ORDER_SEND(ORDER_TYPE_SELL, LOT, ORDERS_COMMENT, MAGIC_NUMBER);
            }
         }
         if(CLOSE_BUY == false && BUYS == 0 && rsiValue <= DN_LEVEL) {
            if(!is_news_blocked) {
               if(MODE == BOTH || MODE == BUY_ONLY) ORDER_SEND(ORDER_TYPE_BUY, LOT, ORDERS_COMMENT, MAGIC_NUMBER);
            }
         }
      }

      //--- STRATEGY 2: Fixed Points Mode
      if(STRATEGY == Fixed_Points)
      {
         TIME_CURRENT = TimeCurrent();
         if(INP_TIME == 0) SIGNAL = true;
         else {
            if(TIMER_VAR == 0) TIMER_VAR = TIME_CURRENT;
            if(TIME_CURRENT >= TIMER_VAR + INP_TIME) { SIGNAL = true; TIMER_VAR += INP_TIME; }
         }

         if(SIGNAL) {
            if(BUYS == 0)  BUY_PRICE  = SymbolInfoDouble(_Symbol, SYMBOL_ASK) + DISTANCE * _Point;
            if(SELLS == 0) SELL_PRICE = SymbolInfoDouble(_Symbol, SYMBOL_BID) - DISTANCE * _Point;
            SIGNAL = false; SIGNAL_BUY = true; SIGNAL_SELL = true;
         }

         if(SIGNAL_BUY && BUY_PRICE > 0 && !(BUY_PRICE - SymbolInfoDouble(_Symbol, SYMBOL_ASK) > _Point)) {
            if(BUYS == 0 && CLOSE_BUY == false && !is_news_blocked) {
               if(MODE == BOTH || MODE == BUY_ONLY) ORDER_SEND(ORDER_TYPE_BUY, LOT, ORDERS_COMMENT, MAGIC_NUMBER);
               SIGNAL_BUY = false; BUY_PRICE = 0; DEINIT_HLINE();
            }
         }
         if(SIGNAL_SELL && SELL_PRICE > 0 && !(SymbolInfoDouble(_Symbol, SYMBOL_BID) - SELL_PRICE > _Point)) {
            if(SELLS == 0 && CLOSE_SELL == false && !is_news_blocked) {
               if(MODE == BOTH || MODE == SELL_ONLY) ORDER_SEND(ORDER_TYPE_SELL, LOT, ORDERS_COMMENT, MAGIC_NUMBER);
               SIGNAL_SELL = false; SELL_PRICE = 0; DEINIT_HLINE();
            }
         }
         
         if(Show_Dashboard && (!MQLInfoInteger(MQL_OPTIMIZATION) && !MQLInfoInteger(MQL_TESTER))) {
            if(BUY_PRICE > 0)  OBJECT_HLINE("HLINE_BUY",  BUY_PRICE,  "OPEN BUY",  clrRed, 0);
            if(SELL_PRICE > 0) OBJECT_HLINE("HLINE_SELL", SELL_PRICE, "OPEN SELL", clrRed, 0);
         }
      }

      //--- Grid: Add recovery orders
      if(STEP_ORDERS > 0)
      {
         if(BUYS > 0) {
            int STEP = (int)MathMin(STEP_ORDERS, MAX_STEP);
            if(STEP_MULTIPLIER > 1 && BUYS > 1) STEP = (int)MathMin((BUYS - 1) * STEP_MULTIPLIER * STEP_ORDERS, (double)MAX_STEP);

            LOT = LOT_CALCULATE(RISK_PER_TRADE, STOPLOSS, FROM_BALANCE, VOLUME);
            if(LOT_MULTIPLIER > 1 && BUYS > 0) LOT = MathMin(LAST_BUY_LOT * LOT_MULTIPLIER, MAX_LOT);

            GRID_BUY_PRICE = LAST_BUY_PRICE - STEP * _Point;
            if(SymbolInfoDouble(_Symbol, SYMBOL_ASK) <= GRID_BUY_PRICE && !CLOSE_ALL && !CLOSE_BUY)
               ORDER_SEND(ORDER_TYPE_BUY, LOT, ORDERS_COMMENT, MAGIC_NUMBER);
         }
         if(SELLS > 0) {
            int STEP = (int)MathMin(STEP_ORDERS, MAX_STEP);
            if(STEP_MULTIPLIER > 1 && SELLS > 1) STEP = (int)MathMin((SELLS - 1) * STEP_MULTIPLIER * STEP_ORDERS, (double)MAX_STEP);

            LOT = LOT_CALCULATE(RISK_PER_TRADE, STOPLOSS, FROM_BALANCE, VOLUME);
            if(LOT_MULTIPLIER > 1 && SELLS > 0) LOT = MathMin(LAST_SELL_LOT * LOT_MULTIPLIER, MAX_LOT);

            GRID_SELL_PRICE = LAST_SELL_PRICE + STEP * _Point;
            if(SymbolInfoDouble(_Symbol, SYMBOL_BID) >= GRID_SELL_PRICE && !CLOSE_ALL && !CLOSE_SELL)
               ORDER_SEND(ORDER_TYPE_SELL, LOT, ORDERS_COMMENT, MAGIC_NUMBER);
         }
      }
   }

   if(CLOSE_BUY)  { if(BUYS > 0) POSITIONS_CLOSE((int)POSITION_TYPE_BUY); if(BUYS == 0) CLOSE_BUY = false; }
   if(CLOSE_SELL) { if(SELLS > 0) POSITIONS_CLOSE((int)POSITION_TYPE_SELL); if(SELLS == 0) CLOSE_SELL = false; }
   if(CLOSE_ALL)  { if(BUYS + SELLS > 0) POSITIONS_CLOSE(-1); if(BUYS + SELLS == 0) CLOSE_ALL = false; }

   if(PREV_BUYS + PREV_SELLS != BUYS + SELLS || FIRST_RUN) RECALCULATION_PARAMETERS();

   FIRST_RUN  = false; DEINIT = false; PREV_BUYS = BUYS; PREV_SELLS = SELLS;
   LAST_BID   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
}

//+------------------------------------------------------------------+
//| News Filter & WebRequest Logic                                   |
//+------------------------------------------------------------------+
void AddTodayNews(datetime t_myt, int impact) {
   for(int i=0; i<ArraySize(today_news_list); i++) if(today_news_list[i].time_myt == t_myt) return; 
   int s = ArraySize(today_news_list); ArrayResize(today_news_list, s+1);
   today_news_list[s].time_myt = t_myt; today_news_list[s].impact = impact;
   for(int i=0; i<ArraySize(today_news_list)-1; i++) {
      for(int j=0; j<ArraySize(today_news_list)-i-1; j++) {
         if(today_news_list[j].time_myt > today_news_list[j+1].time_myt) {
            DailyNews temp = today_news_list[j]; today_news_list[j] = today_news_list[j+1]; today_news_list[j+1] = temp;
         }
      }
   }
}

void UpdateNextNewsInfo() {
   if(!Use_News_Filter) return;
   ArrayResize(today_news_list, 0); 
   datetime server_now = TimeCurrent(); datetime utc_now = TimeGMT();
   int server_offset_seconds = (int)(server_now - utc_now);
   
   datetime myt_now = utc_now + (Malaysia_GMT_Offset * 3600);
   MqlDateTime dt_myt; TimeToStruct(myt_now, dt_myt); dt_myt.hour = 0; dt_myt.min = 0; dt_myt.sec = 0;
   
   datetime myt_start_of_day = StructToTime(dt_myt);
   datetime utc_start_of_day = myt_start_of_day - (Malaysia_GMT_Offset * 3600);
   datetime utc_end_of_day   = utc_start_of_day + 86399;
   
   datetime found_utc = LONG_MAX; string found_impact = "";
   
   if(News_Source == SOURCE_MT5 || News_Source == SOURCE_BOTH) {
      MqlCalendarValue vals[];
      if(CalendarValueHistory(vals, server_now - 86400, server_now + (86400 * 7), NULL, Target_News_Currency)) {
         for(int i=0; i<ArraySize(vals); i++) {
            MqlCalendarEvent ev;
            if(CalendarEventById(vals[i].event_id, ev)) {
               int imp = (ev.importance == CALENDAR_IMPORTANCE_HIGH) ? 3 : (ev.importance == CALENDAR_IMPORTANCE_MODERATE) ? 2 : 1;
               bool valid = (imp == 3 && Filter_High_Impact) || (imp == 2 && Filter_Med_Impact) || (imp == 1 && Filter_Low_Impact);
               datetime ev_utc = vals[i].time - server_offset_seconds;
               if(valid) {
                  if(ev_utc >= utc_start_of_day && ev_utc <= utc_end_of_day) AddTodayNews(ev_utc + (Malaysia_GMT_Offset * 3600), imp);
                  if(ev_utc < found_utc && ev_utc >= utc_now) { found_utc = ev_utc; found_impact = (imp == 3) ? "HIGH" : (imp == 2) ? "MED" : "LOW"; }
               }
            }
         }
      }
   }
   
   if(News_Source == SOURCE_FF || News_Source == SOURCE_BOTH) {
      for(int i=0; i<ArraySize(ff_events); i++) {
         int imp = ff_events[i].impact;
         bool valid = (imp == 3 && Filter_High_Impact) || (imp == 2 && Filter_Med_Impact) || (imp == 1 && Filter_Low_Impact);
         if(valid && ff_events[i].currency == Target_News_Currency) {
            if(ff_events[i].time_utc >= utc_start_of_day && ff_events[i].time_utc <= utc_end_of_day) AddTodayNews(ff_events[i].time_utc + (Malaysia_GMT_Offset * 3600), imp);
            if(ff_events[i].time_utc >= utc_now && ff_events[i].time_utc < found_utc) { found_utc = ff_events[i].time_utc; found_impact = (imp == 3) ? "HIGH" : (imp == 2) ? "MED" : "LOW"; }
         }
      }
   }
   
   if(found_utc != LONG_MAX) { next_news_time_myt = found_utc + (Malaysia_GMT_Offset * 3600); next_news_impact_str = found_impact; } 
   else { next_news_time_myt = 0; next_news_impact_str = "None"; }
}

bool CheckNewsBlock() {
   if(!Use_News_Filter) return false;
   datetime utc_now = TimeGMT(); int server_offset = (int)(TimeCurrent() - utc_now);
   datetime check_start_utc = utc_now - (Mins_After_News * 60); datetime check_end_utc   = utc_now + (Mins_Before_News * 60);
   
   if(News_Source == SOURCE_MT5 || News_Source == SOURCE_BOTH) {
      MqlCalendarValue vals[];
      if(CalendarValueHistory(vals, check_start_utc + server_offset, check_end_utc + server_offset, NULL, Target_News_Currency)) {
         for(int i=0; i<ArraySize(vals); i++) {
            MqlCalendarEvent ev;
            if(CalendarEventById(vals[i].event_id, ev)) {
               if(ev.importance == CALENDAR_IMPORTANCE_HIGH && Filter_High_Impact) return true;
               if(ev.importance == CALENDAR_IMPORTANCE_MODERATE && Filter_Med_Impact) return true;
               if(ev.importance == CALENDAR_IMPORTANCE_LOW && Filter_Low_Impact) return true;
            }
         }
      }
   }

   if(News_Source == SOURCE_FF || News_Source == SOURCE_BOTH) {
      for(int i=0; i<ArraySize(ff_events); i++) {
         if(ff_events[i].time_utc >= check_start_utc && ff_events[i].time_utc <= check_end_utc && ff_events[i].currency == Target_News_Currency) {
            if(ff_events[i].impact == 1 && Filter_Low_Impact) return true;
            if(ff_events[i].impact == 2 && Filter_Med_Impact) return true;
            if(ff_events[i].impact == 3 && Filter_High_Impact) return true;
         }
      }
   }
   return false;
}

void FetchFFNews() {
   string headers; char post[], result[]; string url = "https://nfs.faireconomy.media/ff_calendar_thisweek.xml";
   ResetLastError();
   if(WebRequest("GET", url, "", NULL, 5000, post, 0, result, headers) == 200) ParseFFXML(CharArrayToString(result));
}

void ParseFFXML(string xml) {
   ArrayResize(ff_events, 0); int start_pos = 0;
   while((start_pos = StringFind(xml, "<event>", start_pos)) >= 0) {
      int end_pos = StringFind(xml, "</event>", start_pos); if(end_pos < 0) break;
      string block = StringSubstr(xml, start_pos, end_pos - start_pos);
      string imp_str = ExtractXMLTag(block, "impact");
      int impact = (imp_str == "High") ? 3 : (imp_str == "Medium") ? 2 : (imp_str == "Low") ? 1 : 0;
      string curr = ExtractXMLTag(block, "country"), d = ExtractXMLTag(block, "date"), t = ExtractXMLTag(block, "time");
      if(impact > 0 && StringLen(curr) == 3 && t != "All Day") {
         string sep[]; StringSplit(d, '-', sep);
         int m = (int)StringToInteger(sep[0]), day = (int)StringToInteger(sep[1]), y = (int)StringToInteger(sep[2]);
         int h=0, min=0; bool is_pm = (StringFind(t, "pm") >= 0); StringReplace(t, "am", ""); StringReplace(t, "pm", "");
         string t_sep[]; StringSplit(t, ':', t_sep);
         if(ArraySize(t_sep)==2) { h = (int)StringToInteger(t_sep[0]); min = (int)StringToInteger(t_sep[1]); if(is_pm && h < 12) h += 12; if(!is_pm && h == 12) h = 0; }
         MqlDateTime dt; dt.year = y; dt.mon = m; dt.day = day; dt.hour = h; dt.min = min; dt.sec = 0;
         datetime ev_utc = StructToTime(dt) - (FF_GMT_Offset * 3600); 
         int s = ArraySize(ff_events); ArrayResize(ff_events, s + 1);
         ff_events[s].time_utc = ev_utc; ff_events[s].impact = impact; ff_events[s].currency = curr;
      }
      start_pos = end_pos + 8;
   }
}

string ExtractXMLTag(string xml, string tag) {
   string start_tag = "<" + tag + ">", end_tag = "</" + tag + ">";
   int s = StringFind(xml, start_tag); if(s < 0) return ""; s += StringLen(start_tag);
   int e = StringFind(xml, end_tag, s); if(e < 0) return ""; return StringSubstr(xml, s, e - s);
}

//+------------------------------------------------------------------+
//| GUI Cyberpunk UI + Grid EA Pro Integration                       |
//+------------------------------------------------------------------+
void CreateRect(string n, int x, int y, int w, int h, color bg, color bd) { ObjectCreate(0, n, OBJ_RECTANGLE_LABEL, 0, 0, 0); ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x); ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y); ObjectSetInteger(0, n, OBJPROP_XSIZE, w); ObjectSetInteger(0, n, OBJPROP_YSIZE, h); ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg); ObjectSetInteger(0, n, OBJPROP_BORDER_TYPE, BORDER_FLAT); ObjectSetInteger(0, n, OBJPROP_COLOR, bd); ObjectSetInteger(0, n, OBJPROP_WIDTH, 2); ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER); ObjectSetInteger(0, n, OBJPROP_BACK, false); ObjectSetInteger(0, n, OBJPROP_ZORDER, 1); }
void CreateLabel(string n, int x, int y, string t, int sz, color c, string f="Arial") { ObjectCreate(0, n, OBJ_LABEL, 0, 0, 0); ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x); ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y); ObjectSetString(0, n, OBJPROP_TEXT, t); ObjectSetInteger(0, n, OBJPROP_COLOR, c); ObjectSetInteger(0, n, OBJPROP_FONTSIZE, sz); ObjectSetString(0, n, OBJPROP_FONT, f); ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER); ObjectSetInteger(0, n, OBJPROP_BACK, false); ObjectSetInteger(0, n, OBJPROP_ZORDER, 2); }

void CreateDashboard()
{
   // Expanded Width to 1050 to prevent clipping
   CreateRect("VRS_UI_BG", 10, 20, 1050, 310, cp_ui_bg, cp_cyan); 
   
   // --- COLUMN 1 (Strategy & Layers) ---
   CreateLabel("VRS_UI_Title", 25, 35, "VRS-GriPX EA", 16, cp_pink, "Arial Bold");
   CreateLabel("VRS_UI_Author", 25, 60, "Cyberpunk Edition | Pro Grid + News", 10, cp_purple, "Arial Italic");
   CreateLabel("VRS_UI_Mode_Lbl",    25, 95,  "Mode / Strat: Loading...", 11, cp_yellow);
   CreateLabel("VRS_UI_Pair_Lbl",    25, 120, "Pair / TF: " + _Symbol + " | Spread: --", 11, cp_yellow);
   CreateLabel("VRS_UI_Equity_Lbl",  25, 145, "Balance: $0.00 | Eq: $0.00", 11, cp_cyan);
   CreateLabel("VRS_UI_Float_Lbl",   25, 170, "Floating P/L: $0.00", 11, cp_cyan);
   CreateLabel("VRS_UI_Layers_Lbl",  25, 195, "Open Layer: B 0 (0.00L) | S 0 (0.00L)", 11, cp_blue);
   CreateLabel("VRS_UI_MaxDD_Lbl",   25, 220, "Max DD USD: $0.00", 11, cp_pink);
   CreateLabel("VRS_UI_License_Lbl", 25, 245, "License Expiry: Checking...", 11, cp_cyan);
   
   // --- COLUMN 2 (News & Time) ---
   CreateLabel("VRS_UI_Col2_Title",  400, 35, "--- TIME & NEWS STATUS (MYT) ---", 11, cp_orange, "Arial Bold");
   CreateLabel("VRS_UI_Clock",       400, 60, "Server: --:-- | MYT: --:--", 11, cp_yellow);
   CreateLabel("VRS_UI_News_Lbl",    400, 85, "Block Status: Checking...", 11, clrWhite);
   CreateLabel("VRS_UI_NextNews_Lbl",400, 110, "Next USD: Checking...", 11, clrWhite);
   CreateLabel("VRS_UI_TodayNewsTitle", 400, 145, "--- Today's News Schedule ---", 11, cp_orange);
   for(int i=0; i<6; i++) { CreateLabel("VRS_UI_TodayNews_"+(string)i, 400, 170+(i*18), " ", 10, clrDarkGray); }
   
   // --- COLUMN 3 (Grid EA Pro Stats) ---
   CreateLabel("VRS_UI_Stats_Title", 750, 35, "--- PROFIT STATS ---", 11, cp_orange, "Arial Bold"); 
   CreateLabel("VRS_UI_Stat_Today",  750, 65, "TODAY: $0.00 (0%)", 11, clrDarkGray);
   CreateLabel("VRS_UI_Stat_Week",   750, 90, "WEEK: $0.00 (0%)", 11, clrDarkGray);
   CreateLabel("VRS_UI_Stat_Month",  750, 115, "MONTH: $0.00 (0%)", 11, clrDarkGray);
   CreateLabel("VRS_UI_Stat_Growth", 750, 140, "GROWTH: $0.00 (0%)", 11, clrDarkGray);
   CreateLabel("VRS_UI_Deco", 750, 270, "SYSTEM: ONLINE // GRID ALGO: ACTIVE", 10, cp_purple, "Arial Bold");
}

void UpdateDashboard()
{
   string mode_str = (MODE == BUY_ONLY) ? "BUY ONLY" : (MODE == SELL_ONLY) ? "SELL ONLY" : "BOTH";
   string strat_str = (STRATEGY == RSI_MODE) ? "RSI" : (STRATEGY == Fixed_Points) ? "Fixed Points" : "Manual";
   ObjectSetString(0, "VRS_UI_Mode_Lbl", OBJPROP_TEXT, "Mode: " + mode_str + " | Strat: " + strat_str + " | Grid Step: " + (string)STEP_ORDERS);

   int spread = (int)SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);
   ObjectSetString(0, "VRS_UI_Pair_Lbl", OBJPROP_TEXT, "Pair / TF: " + _Symbol + " (" + EnumToString(Period()) + ") | Spread: " + (string)spread);

   double bal = AccountInfoDouble(ACCOUNT_BALANCE), eq = AccountInfoDouble(ACCOUNT_EQUITY);
   ObjectSetString(0, "VRS_UI_Equity_Lbl", OBJPROP_TEXT, "Balance: $" + DoubleToString(bal, 2) + " | Eq: $" + DoubleToString(eq, 2));
   
   double total_floating = BUY_PROFIT + SELL_PROFIT;
   ObjectSetString(0, "VRS_UI_Float_Lbl", OBJPROP_TEXT, "Floating P/L: $" + DoubleToString(total_floating, 2));
   ObjectSetInteger(0, "VRS_UI_Float_Lbl", OBJPROP_COLOR, (total_floating >= 0 ? cp_cyan : cp_pink));
   ObjectSetString(0, "VRS_UI_Layers_Lbl", OBJPROP_TEXT, "Layers: B " + (string)BUYS + " (" + DoubleToString(BUY_LOTS, 2) + "L) | S " + (string)SELLS + " (" + DoubleToString(SELL_LOTS, 2) + "L)");
   ObjectSetString(0, "VRS_UI_MaxDD_Lbl", OBJPROP_TEXT, "Max DD USD: $" + DoubleToString(max_drawdown_usd, 2));
      string licenseText = "License Expiry: " + g_license_expiry;
   if (g_is_trial) licenseText = "TRIAL LICENSE - Expiry: " + g_license_expiry;
   ObjectSetString(0, "VRS_UI_License_Lbl", OBJPROP_TEXT, licenseText);
   if (g_is_trial) ObjectSetInteger(0, "VRS_UI_License_Lbl", OBJPROP_COLOR, cp_yellow);

   datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
   ObjectSetString(0, "VRS_UI_Clock", OBJPROP_TEXT, "Server: " + TimeToString(TimeCurrent(), TIME_MINUTES | TIME_SECONDS) + " | MYT: " + TimeToString(myt_now, TIME_MINUTES | TIME_SECONDS));

   if(Use_News_Filter) {
      if(is_news_blocked) { ObjectSetString(0, "VRS_UI_News_Lbl", OBJPROP_TEXT, "Block Status: BLOCKED (No New Entry)"); ObjectSetInteger(0, "VRS_UI_News_Lbl", OBJPROP_COLOR, cp_pink); } 
      else { ObjectSetString(0, "VRS_UI_News_Lbl", OBJPROP_TEXT, "Block Status: SAFE (Running)"); ObjectSetInteger(0, "VRS_UI_News_Lbl", OBJPROP_COLOR, cp_cyan); }
      
      if(next_news_time_myt > 0) {
         ObjectSetString(0, "VRS_UI_NextNews_Lbl", OBJPROP_TEXT, "Next News: " + TimeToString(next_news_time_myt, TIME_DATE | TIME_MINUTES) + " [" + next_news_impact_str + "]");
         ObjectSetInteger(0, "VRS_UI_NextNews_Lbl", OBJPROP_COLOR, (next_news_impact_str == "HIGH") ? cp_pink : (next_news_impact_str == "MED" ? cp_yellow : cp_purple));
      } else {
         ObjectSetString(0, "VRS_UI_NextNews_Lbl", OBJPROP_TEXT, "Next News: No schedule detected"); ObjectSetInteger(0, "VRS_UI_NextNews_Lbl", OBJPROP_COLOR, clrDarkGray);
      }
      
      for(int i=0; i<6; i++) {
          if(i < ArraySize(today_news_list)) {
              string t_str = TimeToString(today_news_list[i].time_myt, TIME_MINUTES);
              string imp_str = (today_news_list[i].impact == 3) ? "HIGH" : (today_news_list[i].impact == 2) ? "MED" : "LOW";
              string status = (today_news_list[i].time_myt < myt_now) ? " [DONE]" : " [WAIT]";
              color c = (today_news_list[i].time_myt < myt_now) ? clrDarkGray : (today_news_list[i].impact == 3 ? cp_pink : (today_news_list[i].impact == 2 ? cp_yellow : cp_cyan));
              ObjectSetString(0, "VRS_UI_TodayNews_"+(string)i, OBJPROP_TEXT, "- " + t_str + " (" + imp_str + " Impact) " + status);
              ObjectSetInteger(0, "VRS_UI_TodayNews_"+(string)i, OBJPROP_COLOR, c);
          } else { ObjectSetString(0, "VRS_UI_TodayNews_"+(string)i, OBJPROP_TEXT, " "); }
      }
   } else {
      ObjectSetString(0, "VRS_UI_News_Lbl", OBJPROP_TEXT, "News Filter is DISABLED"); ObjectSetInteger(0, "VRS_UI_News_Lbl", OBJPROP_COLOR, clrDarkGray);
      ObjectSetString(0, "VRS_UI_NextNews_Lbl", OBJPROP_TEXT, "");
      for(int i=0; i<6; i++) { ObjectSetString(0, "VRS_UI_TodayNews_"+(string)i, OBJPROP_TEXT, " "); }
   }

   // Grid EA Pro Profit Stats Integration
   int g_pips=0, st_pips=0, sw_pips=0, sm_pips=0, sg_pips=0;
   double t=0, w=0, m=0, g=0, vt=0, vw=0, vm=0, vtot=0;
   PROFIT_OTHER_SYMBOLS(t, w, m, g, vt, vw, vm, vtot, g_pips);
   
   double st=0, sw=0, sm=0, sg=0, svt=0, svw=0, svm=0, svtot=0;
   PROFIT_SYMBOL(st, sw, sm, sg, svt, svw, svm, svtot, st_pips, sw_pips, sm_pips, sg_pips);
   
   double today_pct  = (bal - t - st != 0) ? NormalizeDouble(st / (bal - t - st) * 100, 2) : 0;
   double week_pct   = (bal - w - sw != 0) ? NormalizeDouble(sw / (bal - w - sw) * 100, 2) : 0;
   double month_pct  = (bal - m - sm != 0) ? NormalizeDouble(sm / (bal - m - sm) * 100, 2) : 0;
   double growth_pct = (bal - g - sg != 0) ? NormalizeDouble(sg / (bal - g - sg) * 100, 2) : 0;

   string cur = AccountInfoString(ACCOUNT_CURRENCY);
   ObjectSetString(0, "VRS_UI_Stat_Today",  OBJPROP_TEXT, "TODAY: "  + DoubleToString(today_pct,2) + "%, " + DoubleToString(st,2) + " " + cur + ", " + (string)st_pips + " PIPS");
   ObjectSetString(0, "VRS_UI_Stat_Week",   OBJPROP_TEXT, "WEEK: "   + DoubleToString(week_pct,2)  + "%, " + DoubleToString(sw,2) + " " + cur + ", " + (string)sw_pips + " PIPS");
   ObjectSetString(0, "VRS_UI_Stat_Month",  OBJPROP_TEXT, "MONTH: "  + DoubleToString(month_pct,2) + "%, " + DoubleToString(sm,2) + " " + cur + ", " + (string)sm_pips + " PIPS");
   ObjectSetString(0, "VRS_UI_Stat_Growth", OBJPROP_TEXT, "GROWTH: " + DoubleToString(growth_pct,2)+ "%, " + DoubleToString(sg,2) + " " + cur + ", " + (string)sg_pips + " PIPS");
   
   ObjectSetString(0, "VRS_UI_Deco", OBJPROP_TEXT, g_is_expired ? "SYSTEM: OFFLINE // LICENSE EXPIRED" : "SYSTEM: ONLINE // GRID ALGO: ACTIVE");
   ObjectSetInteger(0, "VRS_UI_Deco", OBJPROP_COLOR, g_is_expired ? cp_pink : cp_purple);
   
   ObjectSetInteger(0, "VRS_UI_Stat_Today",  OBJPROP_COLOR, (st > 0 ? cp_cyan : (st < 0 ? cp_pink : clrDarkGray)));
   ObjectSetInteger(0, "VRS_UI_Stat_Week",   OBJPROP_COLOR, (sw > 0 ? cp_cyan : (sw < 0 ? cp_pink : clrDarkGray)));
   ObjectSetInteger(0, "VRS_UI_Stat_Month",  OBJPROP_COLOR, (sm > 0 ? cp_cyan : (sm < 0 ? cp_pink : clrDarkGray)));
   ObjectSetInteger(0, "VRS_UI_Stat_Growth", OBJPROP_COLOR, (sg > 0 ? cp_cyan : (sg < 0 ? cp_pink : clrDarkGray)));
}

//+------------------------------------------------------------------+
//| UI Manual Buttons                                                |
//+------------------------------------------------------------------+
void DRAW_BUTTON()
{
   int X = 10, Y = 350; // Moved below Cyberpunk Dashboard
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(bid != LAST_BID && bid > LAST_BID) BUTTONL_CLR = (color)StringToInteger("0x0E10BE");
   if(bid != LAST_BID && bid < LAST_BID) BUTTONL_CLR = (color)StringToInteger("0xBE100F");

   OBJECT_BUTTON(0,"BUTTON_SELL", 0, X,      Y, 55, 25, CORNER_LEFT_UPPER, "SELL", "Arial", 10, clrWhite, BUTTONL_CLR,           clrBlack, false,false,false,true,0);
   OBJECT_BUTTON(0,"BUTTON_-LOT", 0, X+60,   Y, 20, 25, CORNER_LEFT_UPPER, "-",    "Arial", 10, clrBlack, (color)0xEBEBEB,        clrBlack, false,false,false,true,0);
   OBJECT_EDIT  (0,"BUTTON_LOT",  0, X+85,   Y, 45, 25, DoubleToString(TEMP_LOT,2),"Arial",10,ALIGN_CENTER,false,CORNER_LEFT_UPPER,clrBlack, clrWhite,clrBlack,false,false,false,0);
   OBJECT_BUTTON(0,"BUTTON_+LOT", 0, X+135,  Y, 20, 25, CORNER_LEFT_UPPER, "+",    "Arial", 10, clrBlack, (color)0xEBEBEB,        clrBlack, false,false,false,true,0);
   OBJECT_BUTTON(0,"BUTTON_BUY",  0, X+160,  Y, 55, 25, CORNER_LEFT_UPPER, "BUY",  "Arial", 10, clrWhite, BUTTONL_CLR,           clrBlack, false,false,false,true,0);
}

void DEINIT_BUTTON() { for(int i=ObjectsTotal(0)-1; i>=0; i--) { string name=ObjectName(0, i); if(StringFind(name, "BUTTON")>=0) ObjectDelete(0, name); } }

bool OBJECT_BUTTON(const long CHART_ID=0,const string NAME="",const int SUB_WINDOW=0,const int X=0,const int Y=0,const int WIDTH=50,const int HEIGHT=18,const ENUM_BASE_CORNER CORNER=CORNER_LEFT_UPPER,const string TEXT="",const string FONT="",const int FONT_SIZE=10,const color CLR=clrBlack,const color BACK_CLR=clrNONE,const color BORDER_CLR=clrNONE,const bool state=false,const bool BACK=false,const bool SELECTION=false,const bool HIDDEN=true,const long ZORDER=0) {
   if(ObjectFind(0, NAME)<0) { ObjectCreate(CHART_ID, NAME, OBJ_BUTTON, SUB_WINDOW, 0, 0); ObjectSetInteger(CHART_ID, NAME, OBJPROP_XDISTANCE, X); ObjectSetInteger(CHART_ID, NAME, OBJPROP_YDISTANCE, Y); ObjectSetInteger(CHART_ID, NAME, OBJPROP_XSIZE, WIDTH); ObjectSetInteger(CHART_ID, NAME, OBJPROP_YSIZE, HEIGHT); ObjectSetInteger(CHART_ID, NAME, OBJPROP_CORNER, CORNER); ObjectSetString(CHART_ID, NAME, OBJPROP_TEXT, TEXT); ObjectSetString(CHART_ID, NAME, OBJPROP_FONT, FONT); ObjectSetInteger(CHART_ID, NAME, OBJPROP_FONTSIZE, FONT_SIZE); ObjectSetInteger(CHART_ID, NAME, OBJPROP_COLOR, CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BGCOLOR, BACK_CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BORDER_COLOR,BORDER_CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BACK, BACK); ObjectSetInteger(CHART_ID, NAME, OBJPROP_STATE, state); ObjectSetInteger(CHART_ID, NAME, OBJPROP_SELECTABLE, SELECTION); ObjectSetInteger(CHART_ID, NAME, OBJPROP_SELECTED, SELECTION); ObjectSetInteger(CHART_ID, NAME, OBJPROP_HIDDEN, HIDDEN); ObjectSetInteger(CHART_ID, NAME, OBJPROP_ZORDER, ZORDER); }
   else { ObjectSetInteger(CHART_ID, NAME, OBJPROP_COLOR, CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BGCOLOR, BACK_CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BORDER_COLOR, BORDER_CLR); } ChartRedraw(); return true;
}

bool OBJECT_EDIT(const long CHART_ID=0,const string NAME="",const int SUB_WINDOW=0,const int X=0,const int Y=0,const int WIDTH=0,const int HEIGHT=0,const string TEXT="",const string FONT="",const int FONT_SIZE=0,const ENUM_ALIGN_MODE ALIGN=ALIGN_CENTER,const bool READ_ONLY=false,const ENUM_BASE_CORNER CORNER=CORNER_LEFT_UPPER,const color CLR=clrBlack,const color BACK_CLR=clrWhite,const color BORDER_CLR=clrNONE,const bool BACK=false,const bool SELECTION=false,const bool HIDDEN=true,const long ZORDER=0) {
   if(ObjectFind(0, NAME)<0) { ObjectCreate(CHART_ID, NAME, OBJ_EDIT, SUB_WINDOW, 0, 0); ObjectSetInteger(CHART_ID, NAME, OBJPROP_XDISTANCE, X); ObjectSetInteger(CHART_ID, NAME, OBJPROP_YDISTANCE, Y); ObjectSetInteger(CHART_ID, NAME, OBJPROP_XSIZE, WIDTH); ObjectSetInteger(CHART_ID, NAME, OBJPROP_YSIZE, HEIGHT); ObjectSetString(CHART_ID, NAME, OBJPROP_TEXT, TEXT); ObjectSetString(CHART_ID, NAME, OBJPROP_FONT, FONT); ObjectSetInteger(CHART_ID, NAME, OBJPROP_FONTSIZE, FONT_SIZE); ObjectSetInteger(CHART_ID, NAME, OBJPROP_ALIGN, ALIGN); ObjectSetInteger(CHART_ID, NAME, OBJPROP_READONLY, READ_ONLY); ObjectSetInteger(CHART_ID, NAME, OBJPROP_CORNER, CORNER); ObjectSetInteger(CHART_ID, NAME, OBJPROP_COLOR, CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BGCOLOR, BACK_CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BORDER_COLOR,BORDER_CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BACK, BACK); ObjectSetInteger(CHART_ID, NAME, OBJPROP_SELECTABLE, SELECTION); ObjectSetInteger(CHART_ID, NAME, OBJPROP_SELECTED, SELECTION); ObjectSetInteger(CHART_ID, NAME, OBJPROP_HIDDEN, HIDDEN); ObjectSetInteger(CHART_ID, NAME, OBJPROP_ZORDER, ZORDER); }
   else { ObjectSetInteger(CHART_ID, NAME, OBJPROP_COLOR, CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BGCOLOR, BACK_CLR); ObjectSetInteger(CHART_ID, NAME, OBJPROP_BORDER_COLOR, BORDER_CLR); } ChartRedraw(); return true;
}

void ON_CHART_EVENTS() {
   double minLot = SymbolInfoDouble(NULL, SYMBOL_VOLUME_MIN), maxLot = SymbolInfoDouble(NULL, SYMBOL_VOLUME_MAX);
   TEMP_LOT = StringToDouble(ObjectGetString(0, "BUTTON_LOT", OBJPROP_TEXT));
   if(TEMP_LOT < minLot) ObjectSetString(0, "BUTTON_LOT", OBJPROP_TEXT, DoubleToString(MathMax(LAST_LOT, minLot), 2));

   if((bool)ObjectGetInteger(0, "BUTTON_+LOT", OBJPROP_STATE)) { double lots = StringToDouble(ObjectGetString(0, "BUTTON_LOT", OBJPROP_TEXT)); lots = MathMin(lots + minLot, maxLot); ObjectSetString(0, "BUTTON_LOT", OBJPROP_TEXT, DoubleToString(lots, 2)); TEMP_LOT = lots; ObjectSetInteger(0, "BUTTON_+LOT", OBJPROP_STATE, false); }
   if((bool)ObjectGetInteger(0, "BUTTON_-LOT", OBJPROP_STATE)) { double lots = StringToDouble(ObjectGetString(0, "BUTTON_LOT", OBJPROP_TEXT)); lots = MathMax(lots - minLot, minLot); ObjectSetString(0, "BUTTON_LOT", OBJPROP_TEXT, DoubleToString(lots, 2)); TEMP_LOT = lots; ObjectSetInteger(0, "BUTTON_-LOT", OBJPROP_STATE, false); }
   if((bool)ObjectGetInteger(0, "BUTTON_BUY", OBJPROP_STATE)) { ORDER_SEND(ORDER_TYPE_BUY, TEMP_LOT, ORDERS_COMMENT, MAGIC_NUMBER); ObjectSetInteger(0, "BUTTON_BUY", OBJPROP_STATE, false); BUYS++; }
   if((bool)ObjectGetInteger(0, "BUTTON_SELL", OBJPROP_STATE)) { ORDER_SEND(ORDER_TYPE_SELL, TEMP_LOT, ORDERS_COMMENT, MAGIC_NUMBER); ObjectSetInteger(0, "BUTTON_SELL", OBJPROP_STATE, false); SELLS++; }
}

//+------------------------------------------------------------------+
//| Core Utilities & Helpers                                         |
//+------------------------------------------------------------------+
double GET_RSI_VALUE(int index = 1) {
   if(RSI_HANDLE == INVALID_HANDLE) return 0;
   double rsiArray[]; 
   if(CopyBuffer(RSI_HANDLE, 0, 0, index + 1, rsiArray) < 0) return 0;
   ArraySetAsSeries(rsiArray, true); // Mesti set selepas CopyBuffer
   return NormalizeDouble(rsiArray[index], 2);
}

void ORDER_SEND(ENUM_ORDER_TYPE CMD, double LOTS, string COMMENT, int MAGIC) {
   if(AccountInfoInteger(ACCOUNT_LIMIT_ORDERS) > 0 && PositionsTotal() + OrdersTotal() >= AccountInfoInteger(ACCOUNT_LIMIT_ORDERS)) return;
   double minLot = SymbolInfoDouble(NULL, SYMBOL_VOLUME_MIN), maxLot = SymbolInfoDouble(NULL, SYMBOL_VOLUME_MAX), lotStep = SymbolInfoDouble(NULL, SYMBOL_VOLUME_STEP);
   LOTS = NormalizeDouble(MathRound(MathMax(MathMin(LOTS, maxLot), minLot) / lotStep) * lotStep, 2);

   MqlTradeRequest request = {}; MqlTradeResult result = {};
   request.action = TRADE_ACTION_DEAL; request.symbol = _Symbol; request.volume = LOTS; request.type = CMD;
   request.price = (CMD == ORDER_TYPE_BUY) ? SymbolInfoDouble(_Symbol, SYMBOL_ASK) : SymbolInfoDouble(_Symbol, SYMBOL_BID);
   request.deviation = 10; request.magic = (MAGIC == -1) ? 0 : MAGIC; request.comment = COMMENT; request.type_filling = GetFillingMode(_Symbol);
   if(!OrderSend(request, result)) { Print("OrderSend error: ", GetLastError()); }
}

void OVERLAP(int ORDERTYPE = -1) {
   WIN_TYPE = WIN_TICKET = 0; WIN_PROFIT = WIN_LOT = 0; WIN_POSITION(WIN_TYPE, WIN_TICKET, WIN_PROFIT, WIN_LOT, _Symbol, ORDERTYPE, MAGIC_NUMBER);
   LOSS_TYPE = LOSS_TICKET = 0; LOSS_PROFIT = LOSS_LOT = 0; LOSS_POSITION(LOSS_TYPE, LOSS_TICKET, LOSS_PROFIT, LOSS_LOT, _Symbol, ORDERTYPE, MAGIC_NUMBER);
   if(-LOSS_PROFIT == 0 || WIN_PROFIT == 0) return;

   if(WIN_TYPE == LOSS_TYPE && TICKVALUE * (WIN_LOT + LOSS_LOT) != 0) {
      if(WIN_TYPE == (int)POSITION_TYPE_BUY) { ZEROLEVEL = NormalizeDouble(SymbolInfoDouble(NULL, SYMBOL_BID) - ((WIN_PROFIT + LOSS_PROFIT) / (TICKVALUE * (WIN_LOT + LOSS_LOT)) * _Point), _Digits); OVERLAP_CLOSE = NormalizeDouble(ZEROLEVEL + OVERLAP_PIPS * _Point, _Digits); if(SymbolInfoDouble(NULL, SYMBOL_BID) >= OVERLAP_CLOSE) { POSITIONS_CLOSE_TICKET(WIN_TICKET, WIN_LOT); POSITIONS_CLOSE_TICKET(LOSS_TICKET, LOSS_LOT); ZEROLEVEL = 0; OVERLAP_CLOSE = 0; } }
      if(WIN_TYPE == (int)POSITION_TYPE_SELL) { ZEROLEVEL = NormalizeDouble(SymbolInfoDouble(NULL, SYMBOL_ASK) + ((WIN_PROFIT + LOSS_PROFIT) / (TICKVALUE * (WIN_LOT + LOSS_LOT)) * _Point), _Digits); OVERLAP_CLOSE = NormalizeDouble(ZEROLEVEL - OVERLAP_PIPS * _Point, _Digits); if(SymbolInfoDouble(NULL, SYMBOL_ASK) <= OVERLAP_CLOSE) { POSITIONS_CLOSE_TICKET(WIN_TICKET, WIN_LOT); POSITIONS_CLOSE_TICKET(LOSS_TICKET, LOSS_LOT); ZEROLEVEL = 0; OVERLAP_CLOSE = 0; } }
   } else if(WIN_TYPE != LOSS_TYPE && TICKVALUE * MathAbs(WIN_LOT - LOSS_LOT) != 0) {
      if(WIN_LOT > LOSS_LOT) {
         if(WIN_TYPE == (int)POSITION_TYPE_BUY) { ZEROLEVEL = NormalizeDouble(SymbolInfoDouble(NULL, SYMBOL_BID) - ((WIN_PROFIT + LOSS_PROFIT) / (TICKVALUE * MathAbs(WIN_LOT - LOSS_LOT)) * _Point), _Digits); OVERLAP_CLOSE = NormalizeDouble(ZEROLEVEL + OVERLAP_PIPS * _Point, _Digits); if(SymbolInfoDouble(NULL, SYMBOL_BID) >= OVERLAP_CLOSE) { POSITIONS_CLOSE_TICKET(WIN_TICKET, WIN_LOT); POSITIONS_CLOSE_TICKET(LOSS_TICKET, LOSS_LOT); ZEROLEVEL = 0; OVERLAP_CLOSE = 0; } }
         if(WIN_TYPE == (int)POSITION_TYPE_SELL) { ZEROLEVEL = NormalizeDouble(SymbolInfoDouble(NULL, SYMBOL_ASK) + ((WIN_PROFIT + LOSS_PROFIT) / (TICKVALUE * MathAbs(WIN_LOT - LOSS_LOT)) * _Point), _Digits); OVERLAP_CLOSE = NormalizeDouble(ZEROLEVEL - OVERLAP_PIPS * _Point, _Digits); if(SymbolInfoDouble(NULL, SYMBOL_ASK) <= OVERLAP_CLOSE) { POSITIONS_CLOSE_TICKET(WIN_TICKET, WIN_LOT); POSITIONS_CLOSE_TICKET(LOSS_TICKET, LOSS_LOT); ZEROLEVEL = 0; OVERLAP_CLOSE = 0; } }
      }
      if(WIN_LOT < LOSS_LOT) {
         if(LOSS_TYPE == (int)POSITION_TYPE_BUY) { ZEROLEVEL = NormalizeDouble(SymbolInfoDouble(NULL, SYMBOL_BID) - ((WIN_PROFIT + LOSS_PROFIT) / (TICKVALUE * MathAbs(WIN_LOT - LOSS_LOT)) * _Point), _Digits); OVERLAP_CLOSE = NormalizeDouble(ZEROLEVEL + OVERLAP_PIPS * _Point, _Digits); if(SymbolInfoDouble(NULL, SYMBOL_BID) >= OVERLAP_CLOSE) { POSITIONS_CLOSE_TICKET(WIN_TICKET, WIN_LOT); POSITIONS_CLOSE_TICKET(LOSS_TICKET, LOSS_LOT); ZEROLEVEL = 0; OVERLAP_CLOSE = 0; } }
         if(LOSS_TYPE == (int)POSITION_TYPE_SELL) { ZEROLEVEL = NormalizeDouble(SymbolInfoDouble(NULL, SYMBOL_ASK) + ((WIN_PROFIT + LOSS_PROFIT) / (TICKVALUE * MathAbs(WIN_LOT - LOSS_LOT)) * _Point), _Digits); OVERLAP_CLOSE = NormalizeDouble(ZEROLEVEL - OVERLAP_PIPS * _Point, _Digits); if(SymbolInfoDouble(NULL, SYMBOL_ASK) <= OVERLAP_CLOSE) { POSITIONS_CLOSE_TICKET(WIN_TICKET, WIN_LOT); POSITIONS_CLOSE_TICKET(LOSS_TICKET, LOSS_LOT); ZEROLEVEL = 0; OVERLAP_CLOSE = 0; } }
      }
   }
}

void GET_TICKVALUE() {
   SPREAD = (int)MathMax((SymbolInfoDouble(NULL, SYMBOL_ASK) - SymbolInfoDouble(NULL, SYMBOL_BID)) / _Point, (double)SymbolInfoInteger(NULL, SYMBOL_SPREAD));
   for(int i=0; i<PositionsTotal(); i++) if(PositionGetSymbol(i) == _Symbol) { double profit = PositionGetDouble(POSITION_PROFIT), openPrice = PositionGetDouble(POSITION_PRICE_OPEN), curPrice = PositionGetDouble(POSITION_PRICE_CURRENT), lots = PositionGetDouble(POSITION_VOLUME); if(profit != 0 && (curPrice - openPrice) != 0 && lots > 0) TICKVALUE = MathAbs(profit / ((curPrice - openPrice) / _Point) / lots); }
}

void TOTAL_VALUE(double &PROFIT_BUY, double &LOTS_BUY, double &PROFIT_SELL, double &LOTS_SELL, int MAGIC = -1) {
   PROFIT_BUY = LOTS_BUY = PROFIT_SELL = LOTS_SELL = 0;
   for(int i=0; i<PositionsTotal(); i++) {
      ulong ticket = PositionGetTicket(i); if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol || ((long)PositionGetInteger(POSITION_MAGIC) != MAGIC && MAGIC != -1)) continue;
      double profit = NormalizeDouble(PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP), 2), lots = PositionGetDouble(POSITION_VOLUME); int posType = (int)PositionGetInteger(POSITION_TYPE);
      if(posType == POSITION_TYPE_BUY) { PROFIT_BUY += profit; LOTS_BUY += lots; }
      if(posType == POSITION_TYPE_SELL) { PROFIT_SELL += profit; LOTS_SELL += lots; }
   }
}

void RECALCULATION_PARAMETERS() { ZEROLEVEL_BUY = ZEROLEVEL_SELL = ZEROLEVEL_ALL = ZEROLEVEL = OVERLAP_CLOSE = GRID_BUY_PRICE = GRID_SELL_PRICE = TRAILINGSTOP_BUY = TRAILINGSTEP_BUY = TRAILINGSTOP_SELL = TRAILINGSTEP_SELL = BREAKEVENSTOP_BUY = BREAKEVENSTEP_BUY = BREAKEVENSTOP_SELL = BREAKEVENSTEP_SELL = STOPLOSS_BUY = STOPLOSS_SELL = TAKEPROFIT_BUY = TAKEPROFIT_SELL = 0; }

void POSITIONS_CLOSE(int CMD = -1) { for(int i=PositionsTotal()-1; i>=0; i--) { ulong ticket = PositionGetTicket(i); if(ticket != 0 && PositionGetString(POSITION_SYMBOL) == _Symbol && ((int)PositionGetInteger(POSITION_TYPE) == CMD || CMD == -1) && ((long)PositionGetInteger(POSITION_MAGIC) == MAGIC_NUMBER || MAGIC_NUMBER == -1)) Trade.PositionClose(ticket); } }
void POSITIONS_CLOSE_TICKET(ulong ticket, double lots = -1) { if(!PositionSelectByTicket(ticket)) return; Trade.PositionClose(ticket); }
void COUNT_ORDERS(int &B, int &S, int &BL, int &SL, int &BS, int &SS, int MAGIC = -1) { B=S=BL=SL=BS=SS=0; for(int i=0; i<PositionsTotal(); i++) { ulong ticket = PositionGetTicket(i); if(ticket != 0 && PositionGetString(POSITION_SYMBOL) == _Symbol && ((long)PositionGetInteger(POSITION_MAGIC) == MAGIC || MAGIC == -1)) { int posType = (int)PositionGetInteger(POSITION_TYPE); if(posType == POSITION_TYPE_BUY) B++; if(posType == POSITION_TYPE_SELL) S++; } } }

void DEINIT_HLINE() { for(int i=ObjectsTotal(0, -1, -1)-1; i>=0; i--) { string name=ObjectName(0, i, -1, -1); if(StringFind(name, "HLINE", 0) >= 0) ObjectDelete(0, name); } }
void OBJECT_HLINE(string NAME, double _PRICE, string TEXT, color CLR, int STYLE=3) { if(ObjectFind(0, NAME)<0) { ObjectCreate(0, NAME, OBJ_HLINE, 0, 0, 0); ObjectSetInteger(0, NAME, OBJPROP_COLOR, CLR); ObjectSetInteger(0, NAME, OBJPROP_STYLE, STYLE); ObjectSetInteger(0, NAME, OBJPROP_WIDTH, 1); ObjectSetInteger(0, NAME, OBJPROP_BACK, true); ObjectSetInteger(0, NAME, OBJPROP_SELECTABLE,false); ObjectSetInteger(0, NAME, OBJPROP_SELECTED, false); ObjectSetInteger(0, NAME, OBJPROP_HIDDEN, true); ObjectSetDouble(0, NAME, OBJPROP_PRICE, _PRICE); ObjectSetString(0, NAME, OBJPROP_TOOLTIP, TEXT); } else { ObjectSetDouble(0, NAME, OBJPROP_PRICE, _PRICE); ObjectSetString(0, NAME, OBJPROP_TOOLTIP, TEXT); ObjectSetInteger(0, NAME, OBJPROP_COLOR, CLR); } }

void HLINE() {
   if(ZEROLEVEL>0) OBJECT_HLINE("HLINE_ZEROLEVEL", ZEROLEVEL, "ZEROLEVEL", clrGold, 0); else ObjectDelete(0,"HLINE_ZEROLEVEL");
   if(OVERLAP_CLOSE>0) OBJECT_HLINE("HLINE_OVERLAP_CLOSE", OVERLAP_CLOSE, "OVERLAP CLOSE", clrRed); else ObjectDelete(0,"HLINE_OVERLAP_CLOSE");
   if(GRID_BUY_PRICE>0) OBJECT_HLINE("HLINE_GRID_BUY_PRICE", GRID_BUY_PRICE, "GRID BUY", clrGreen); else ObjectDelete(0,"HLINE_GRID_BUY_PRICE");
   if(GRID_SELL_PRICE>0) OBJECT_HLINE("HLINE_GRID_SELL_PRICE", GRID_SELL_PRICE, "GRID SELL", clrGreen); else ObjectDelete(0,"HLINE_GRID_SELL_PRICE");
   if(TRAILINGSTOP_BUY>0) OBJECT_HLINE("HLINE_TRAILINGSTOP_BUY", TRAILINGSTOP_BUY, "TR BUY", clrYellow); else ObjectDelete(0,"HLINE_TRAILINGSTOP_BUY");
   if(TRAILINGSTOP_SELL>0) OBJECT_HLINE("HLINE_TRAILINGSTOP_SELL", TRAILINGSTOP_SELL, "TR SELL", clrYellow); else ObjectDelete(0,"HLINE_TRAILINGSTOP_SELL");
   if(STOPLOSS_BUY>0) OBJECT_HLINE("HLINE_STOPLOSS_BUY", STOPLOSS_BUY, "SL BUY", clrRed); else ObjectDelete(0,"HLINE_STOPLOSS_BUY");
   if(STOPLOSS_SELL>0) OBJECT_HLINE("HLINE_STOPLOSS_SELL", STOPLOSS_SELL, "SL SELL", clrRed); else ObjectDelete(0,"HLINE_STOPLOSS_SELL");
   if(TAKEPROFIT_BUY>0) OBJECT_HLINE("HLINE_TAKEPROFIT_BUY", TAKEPROFIT_BUY, "TP BUY", clrLime); else ObjectDelete(0,"HLINE_TAKEPROFIT_BUY");
   if(TAKEPROFIT_SELL>0) OBJECT_HLINE("HLINE_TAKEPROFIT_SELL", TAKEPROFIT_SELL, "TP SELL", clrLime); else ObjectDelete(0,"HLINE_TAKEPROFIT_SELL");
}

void WIN_POSITION(int &TYPE, int &TICKET, double &PROFIT, double &LOT, string SYMBOL="", int ORDERTYPE=-1, int MAGIC=-1) {
   double DISTANCE_ = 0.0; TYPE = TICKET = 0; PROFIT = LOT = 0; if(SYMBOL=="") SYMBOL=_Symbol;
   for(int i=0; i<PositionsTotal(); i++) { ulong t = PositionGetTicket(i); if(t!=0 && PositionGetString(POSITION_SYMBOL)==SYMBOL && ((long)PositionGetInteger(POSITION_MAGIC)==MAGIC || MAGIC==-1)) { int posType = (int)PositionGetInteger(POSITION_TYPE); double openP = PositionGetDouble(POSITION_PRICE_OPEN), bid = SymbolInfoDouble(SYMBOL, SYMBOL_BID), ask = SymbolInfoDouble(SYMBOL, SYMBOL_ASK); if((ORDERTYPE==-1 || posType==ORDERTYPE)) { if(posType==POSITION_TYPE_BUY && openP<bid) { double dist = MathAbs(openP-bid); if(dist>DISTANCE_) { DISTANCE_ = dist; TYPE = posType; TICKET = (int)t; PROFIT = NormalizeDouble(PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP),2); LOT = PositionGetDouble(POSITION_VOLUME); } } if(posType==POSITION_TYPE_SELL && openP>ask) { double dist = MathAbs(openP-ask); if(dist>DISTANCE_) { DISTANCE_ = dist; TYPE = posType; TICKET = (int)t; PROFIT = NormalizeDouble(PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP),2); LOT = PositionGetDouble(POSITION_VOLUME); } } } } }
}

void LOSS_POSITION(int &TYPE, int &TICKET, double &PROFIT, double &LOT, string SYMBOL="", int ORDERTYPE=-1, int MAGIC=-1) {
   double DISTANCE_ = 0.0; TYPE = TICKET = 0; PROFIT = LOT = 0; if(SYMBOL=="") SYMBOL=_Symbol;
   for(int i=0; i<PositionsTotal(); i++) { ulong t = PositionGetTicket(i); if(t!=0 && PositionGetString(POSITION_SYMBOL)==SYMBOL && ((long)PositionGetInteger(POSITION_MAGIC)==MAGIC || MAGIC==-1)) { int posType = (int)PositionGetInteger(POSITION_TYPE); double openP = PositionGetDouble(POSITION_PRICE_OPEN), bid = SymbolInfoDouble(SYMBOL, SYMBOL_BID), ask = SymbolInfoDouble(SYMBOL, SYMBOL_ASK); if((ORDERTYPE==-1 || posType==ORDERTYPE)) { if(posType==POSITION_TYPE_BUY && openP>bid) { double dist = MathAbs(openP-bid); if(dist>DISTANCE_) { DISTANCE_ = dist; TYPE = posType; TICKET = (int)t; PROFIT = NormalizeDouble(PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP),2); LOT = PositionGetDouble(POSITION_VOLUME); } } if(posType==POSITION_TYPE_SELL && openP<ask) { double dist = MathAbs(openP-ask); if(dist>DISTANCE_) { DISTANCE_ = dist; TYPE = posType; TICKET = (int)t; PROFIT = NormalizeDouble(PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP),2); LOT = PositionGetDouble(POSITION_VOLUME); } } } } }
}

void OPENED_VALUES(double &PRICE_BUY, double &LOTS_BUY, double &PRICE_SELL, double &LOTS_SELL) {
   PRICE_BUY = LOTS_BUY = PRICE_SELL = LOTS_SELL = 0; ulong lastT = 0;
   for(int i=0; i<PositionsTotal(); i++) { ulong t = PositionGetTicket(i); if(t!=0 && PositionGetString(POSITION_SYMBOL)==_Symbol && ((long)PositionGetInteger(POSITION_MAGIC)==MAGIC_NUMBER || MAGIC_NUMBER==-1) && t>lastT) { int posType = (int)PositionGetInteger(POSITION_TYPE); if(posType==POSITION_TYPE_BUY) { PRICE_BUY = PositionGetDouble(POSITION_PRICE_OPEN); LOTS_BUY = PositionGetDouble(POSITION_VOLUME); } if(posType==POSITION_TYPE_SELL) { PRICE_SELL = PositionGetDouble(POSITION_PRICE_OPEN); LOTS_SELL = PositionGetDouble(POSITION_VOLUME); } lastT = t; } }
}

void VIRTUAL_TRAILINGSTOP(int CMD = -1) {
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID), ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   if(CMD == POSITION_TYPE_BUY && BUYS>0 && TICKVALUE*BUY_LOTS>0) { ZEROLEVEL_BUY = NormalizeDouble(bid-(BUY_PROFIT/(TICKVALUE*BUY_LOTS)*_Point), _Digits); TRAILINGSTOP_BUY = NormalizeDouble((TRAILINGSTEP_BUY>0?TRAILINGSTEP_BUY:ZEROLEVEL_BUY)+(TRAILING_STOP+TRAILING_STEP)*_Point, _Digits); if(bid>=NormalizeDouble(ZEROLEVEL_BUY+(TRAILING_STOP+TRAILING_STEP)*_Point, _Digits) && (NormalizeDouble(bid-(TRAILING_STOP+TRAILING_STEP)*_Point, _Digits)>=TRAILINGSTEP_BUY || TRAILINGSTEP_BUY==0)) TRAILINGSTEP_BUY = NormalizeDouble(bid-TRAILING_STEP*_Point, _Digits); if(TRAILINGSTEP_BUY>0 && bid<=TRAILINGSTEP_BUY) CLOSE_BUY = true; }
   if(CMD == POSITION_TYPE_SELL && SELLS>0 && TICKVALUE*SELL_LOTS>0) { ZEROLEVEL_SELL = NormalizeDouble(ask+(SELL_PROFIT/(TICKVALUE*SELL_LOTS)*_Point), _Digits); TRAILINGSTOP_SELL = NormalizeDouble((TRAILINGSTEP_SELL>0?TRAILINGSTEP_SELL:ZEROLEVEL_SELL)-(TRAILING_STOP+TRAILING_STEP)*_Point, _Digits); if(ask<=NormalizeDouble(ZEROLEVEL_SELL-(TRAILING_STOP+TRAILING_STEP)*_Point, _Digits) && (NormalizeDouble(ask+(TRAILING_STOP+TRAILING_STEP)*_Point, _Digits)<=TRAILINGSTEP_SELL || TRAILINGSTEP_SELL==0)) TRAILINGSTEP_SELL = NormalizeDouble(ask+TRAILING_STEP*_Point, _Digits); if(TRAILINGSTEP_SELL>0 && ask>=TRAILINGSTEP_SELL) CLOSE_SELL = true; }
}

void VIRTUAL_BREAKEVEN(int CMD = -1) {
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID), ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   if(CMD == POSITION_TYPE_BUY && BUYS>0 && TICKVALUE*BUY_LOTS>0) { ZEROLEVEL_BUY = NormalizeDouble(bid-(BUY_PROFIT/(TICKVALUE*BUY_LOTS)*_Point), _Digits); BREAKEVENSTOP_BUY = NormalizeDouble(ZEROLEVEL_BUY+(BREAKEVEN_STOP+BREAKEVEN_STEP)*_Point, _Digits); if(bid>=BREAKEVENSTOP_BUY) BREAKEVENSTEP_BUY = NormalizeDouble(ZEROLEVEL_BUY+BREAKEVEN_STEP*_Point, _Digits); if(BREAKEVENSTEP_BUY>0 && bid<=BREAKEVENSTEP_BUY) CLOSE_BUY = true; }
   if(CMD == POSITION_TYPE_SELL && SELLS>0 && TICKVALUE*SELL_LOTS>0) { ZEROLEVEL_SELL = NormalizeDouble(ask+(SELL_PROFIT/(TICKVALUE*SELL_LOTS)*_Point), _Digits); BREAKEVENSTOP_SELL = NormalizeDouble(ZEROLEVEL_SELL-(BREAKEVEN_STOP+BREAKEVEN_STEP)*_Point, _Digits); if(ask<=BREAKEVENSTOP_SELL) BREAKEVENSTEP_SELL = NormalizeDouble(ZEROLEVEL_SELL-BREAKEVEN_STEP*_Point, _Digits); if(BREAKEVENSTEP_SELL>0 && ask>=BREAKEVENSTEP_SELL) CLOSE_SELL = true; }
}

void VIRTUAL_STOPLOSS_TAKEPROFIT(int CMD = -1) {
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID), ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   if(CMD == POSITION_TYPE_BUY && BUYS>0 && TICKVALUE*BUY_LOTS>0) { ZEROLEVEL_BUY = NormalizeDouble(bid-(BUY_PROFIT/(TICKVALUE*BUY_LOTS)*_Point), _Digits); if(STOPLOSS>0) STOPLOSS_BUY = NormalizeDouble(ZEROLEVEL_BUY-STOPLOSS*_Point, _Digits); if(TAKEPROFIT>0) TAKEPROFIT_BUY = NormalizeDouble(ZEROLEVEL_BUY+TAKEPROFIT*_Point, _Digits); if(TAKEPROFIT>0 && TAKEPROFIT_BUY!=0 && bid>=TAKEPROFIT_BUY) CLOSE_BUY = true; if(STOPLOSS>0 && STOPLOSS_BUY!=0 && bid<=STOPLOSS_BUY) CLOSE_BUY = true; }
   if(CMD == POSITION_TYPE_SELL && SELLS>0 && TICKVALUE*SELL_LOTS>0) { ZEROLEVEL_SELL = NormalizeDouble(ask+(SELL_PROFIT/(TICKVALUE*SELL_LOTS)*_Point), _Digits); if(STOPLOSS>0) STOPLOSS_SELL = NormalizeDouble(ZEROLEVEL_SELL+STOPLOSS*_Point, _Digits); if(TAKEPROFIT>0) TAKEPROFIT_SELL = NormalizeDouble(ZEROLEVEL_SELL-TAKEPROFIT*_Point, _Digits); if(TAKEPROFIT>0 && TAKEPROFIT_SELL!=0 && ask<=TAKEPROFIT_SELL) CLOSE_SELL = true; if(STOPLOSS>0 && STOPLOSS_SELL!=0 && ask>=STOPLOSS_SELL) CLOSE_SELL = true; }
}

bool WORKING_HOURS(string STARTTIME = "00:00", string ENDTIME = "00:00") {
   if(STARTTIME == "00:00" && ENDTIME == "00:00") return true;
   MqlDateTime t; TimeCurrent(t); double DATETIME = t.hour + t.min / 60.0;
   double TEMP_START = (int)StringSubstr(STARTTIME,0,2) + (int)StringSubstr(STARTTIME,3,2) / 60.0, TEMP_END = (int)StringSubstr(ENDTIME,0,2) + (int)StringSubstr(ENDTIME,3,2) / 60.0;
   double START_H = MathMin(TEMP_END, TEMP_START), END_H = MathMax(TEMP_END, TEMP_START);
   bool ALLOWED = (DATETIME >= START_H && DATETIME < END_H); return (TEMP_START > TEMP_END) ? !ALLOWED : ALLOWED;
}

void PROFIT_OTHER_SYMBOLS(double &_TODAY, double &_WEEK, double &_MONTH, double &_GROWTH, double &_VTODAY, double &_VWEEK, double &_VMONTH, double &_VTOTAL, int &_GROWTH_PIPS) {
   _GROWTH_PIPS = 0; _TODAY = _WEEK = _MONTH = _GROWTH = _VTODAY = _VWEEK = _VMONTH = _VTOTAL = 0; HistorySelect(0, TimeCurrent());
   for(int i=0; i<HistoryDealsTotal(); i++) { ulong t = HistoryDealGetTicket(i); if(t==0 || (HistoryDealGetInteger(t, DEAL_MAGIC)!=MAGIC_NUMBER && MAGIC_NUMBER!=-1)) continue; long dt = HistoryDealGetInteger(t, DEAL_TYPE); if(dt!=DEAL_TYPE_BUY && dt!=DEAL_TYPE_SELL) continue; double p = HistoryDealGetDouble(t, DEAL_PROFIT)+HistoryDealGetDouble(t, DEAL_SWAP)+HistoryDealGetDouble(t, DEAL_COMMISSION), l = HistoryDealGetDouble(t, DEAL_VOLUME); datetime ct = (datetime)HistoryDealGetInteger(t, DEAL_TIME); if(ct>=iTime(NULL,PERIOD_D1,0)) { _TODAY+=p; _VTODAY+=l; } if(ct>=iTime(NULL,PERIOD_W1,0)) { _WEEK+=p; _VWEEK+=l; } if(ct>=iTime(NULL,PERIOD_MN1,0)) { _MONTH+=p; _VMONTH+=l; } _GROWTH+=p; _VTOTAL+=l; }
}

void PROFIT_SYMBOL(double &_TODAY, double &_WEEK, double &_MONTH, double &_GROWTH, double &_VTODAY, double &_VWEEK, double &_VMONTH, double &_VTOTAL, int &_TODAY_PIPS, int &_WEEK_PIPS, int &_MONTH_PIPS, int &_GROWTH_PIPS) {
   _TODAY_PIPS = _WEEK_PIPS = _MONTH_PIPS = _GROWTH_PIPS = 0; _TODAY = _WEEK = _MONTH = _GROWTH = _VTODAY = _VWEEK = _VMONTH = _VTOTAL = 0; HistorySelect(0, TimeCurrent());
   for(int i=0; i<HistoryDealsTotal(); i++) { ulong t = HistoryDealGetTicket(i); if(t==0 || HistoryDealGetString(t, DEAL_SYMBOL)!=_Symbol || (HistoryDealGetInteger(t, DEAL_MAGIC)!=MAGIC_NUMBER && MAGIC_NUMBER!=-1)) continue; long dt = HistoryDealGetInteger(t, DEAL_TYPE); if(dt!=DEAL_TYPE_BUY && dt!=DEAL_TYPE_SELL) continue; double p = HistoryDealGetDouble(t, DEAL_PROFIT)+HistoryDealGetDouble(t, DEAL_SWAP)+HistoryDealGetDouble(t, DEAL_COMMISSION), l = HistoryDealGetDouble(t, DEAL_VOLUME); datetime ct = (datetime)HistoryDealGetInteger(t, DEAL_TIME); if(ct>=iTime(NULL,PERIOD_D1,0)) { _TODAY+=p; _VTODAY+=l; } if(ct>=iTime(NULL,PERIOD_W1,0)) { _WEEK+=p; _VWEEK+=l; } if(ct>=iTime(NULL,PERIOD_MN1,0)) { _MONTH+=p; _VMONTH+=l; } _GROWTH+=p; _VTOTAL+=l; }
}

double LOT_CALCULATE(double RISK, double SL, double BALANCE, double BALANCE_LOT) {
   double LOT = VOLUME; if(RISK_PER_TRADE>0 && SL>0 && TICKVALUE>0) LOT = NormalizeDouble(((AccountInfoDouble(ACCOUNT_BALANCE)*RISK/100.0)/SL)/TICKVALUE, 2);
   else if(FROM_BALANCE>0) LOT = NormalizeDouble(AccountInfoDouble(ACCOUNT_BALANCE)/FROM_BALANCE*BALANCE_LOT, 2);
   return MathMax(MathMin(LOT, SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX)), SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN));
}

`;
