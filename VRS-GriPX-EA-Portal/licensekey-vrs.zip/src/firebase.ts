import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyDW8z9Ef9PgvVF4dbYO4VY7O_Jt_37Vt9E",
  authDomain: "licensekey-ea.firebaseapp.com",
  projectId: "licensekey-ea",
  storageBucket: "licensekey-ea.firebasestorage.app",
  messagingSenderId: "16944915592",
  appId: "1:16944915592:web:4660c6b04036d9ebfa2b3d"
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });
export { signInWithPopup, signOut };
