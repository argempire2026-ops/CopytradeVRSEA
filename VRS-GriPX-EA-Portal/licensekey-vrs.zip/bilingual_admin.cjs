const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Admin Header
code = code.replace(/>Urus Pelanggan<\/span>/g, '>{t[lang].manageClients}</span>');
code = code.replace(/'Urus Pelanggan'/g, 't[lang].manageClients');
code = code.replace(/'Team Access'/g, 't[lang].teamAccess');
code = code.replace(/'Tetapan Sistem'/g, 't[lang].adminSettings');
code = code.replace(/'Web HTML Source'/g, 't[lang].htmlSource');
code = code.replace(/'EA Code Source'/g, 't[lang].eaSource');
code = code.replace(/'Overview'/g, 't[lang].overview');

code = code.replace(/>Senarai Pelanggan<\/h3>/g, '>{t[lang].clientsList}</h3>');
code = code.replace(/>Senarai Pelanggan<\/th>/g, '>{t[lang].clientsList}</th>');
code = code.replace(/>Emel Pelanggan<\/th>/g, '>{t[lang].clientEmail}</th>');
code = code.replace(/>Jumlah Lesen<\/th>/g, '>{t[lang].totalLicenses}</th>');
code = code.replace(/>Tindakan<\/th>/g, '>{t[lang].actions}</th>');

fs.writeFileSync('src/components/Dashboard.tsx', code);
