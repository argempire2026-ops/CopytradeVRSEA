const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "{activeTab === 'keys' ? 'Overview' : 'EA Code Source'}",
  "{activeTab === 'keys' ? 'Overview' : activeTab === 'ea' ? 'EA Code Source' : 'Web HTML Source'}"
);

code = code.replace(
  "              </div>\n            </div>\n          ) : (\n            <>\n          {/* Create Form */}",
  `              </div>
            </div>
          ) : activeTab === 'html' ? (
            <div className="flex-1 flex flex-col bg-slate-900 rounded-xl overflow-hidden shadow-lg border border-slate-800">
              <div className="flex justify-between items-center p-4 border-b border-slate-800 bg-slate-900 shrink-0">
                <h3 className="text-sm font-bold text-slate-300 flex items-center gap-2">
                  <Code className="w-4 h-4 text-indigo-400" />
                  index.html (Single File)
                </h3>
                <button
                  onClick={handleCopyCode}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded flex items-center gap-2 transition-colors"
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy HTML'}
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4 bg-[#0F172A]">
                <pre className="text-[12px] font-mono text-slate-300 whitespace-pre-wrap font-medium">
                  {htmlCode || 'Loading code...'}
                </pre>
              </div>
            </div>
          ) : (
            <>
          {/* Create Form */}`
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
