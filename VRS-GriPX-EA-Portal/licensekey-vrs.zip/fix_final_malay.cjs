const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/Daftarkan pelanggan baru di sini untuk memberikan mereka akses ke portal pelanggan\. Mereka boleh log masuk menggunakan e-mel dan kata laluan ini\./g, "Register new clients here to give them access to the client portal. They can login using this email and password.");

fs.writeFileSync('src/components/Dashboard.tsx', code);
