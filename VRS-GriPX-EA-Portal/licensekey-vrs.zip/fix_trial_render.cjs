const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldRender = `                {trialResult.error ? (
                  <p className="text-red-500 font-medium">{trialResult.error}</p>
                ) : (
                  <>
                    <p className="text-sm text-slate-400 mb-2">Sila salin License Key anda (Sah 24 Jam):</p>
                    <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                      {trialResult.key}
                    </div>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(trialResult.key);
                        alert('Key disalin!');
                      }}
                      className="text-[#D4AF37] text-sm font-medium hover:text-indigo-800"
                    >
                      Salin Key
                    </button>
                  </>
                )}`;

const newRender = `                {trialResult.error ? (
                  <p className="text-red-500 font-medium">{trialResult.error}</p>
                ) : (
                  <>
                    <p className="text-sm text-slate-400 mb-2">
                      {trialResult.existing ? 'Lesen Trial anda masih aktif:' : 'Sila salin License Key anda (Sah 24 Jam):'}
                    </p>
                    <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                      {trialResult.key}
                    </div>
                    {trialResult.expiresAt && (
                      <p className="text-xs text-rose-400 mb-4">
                        Tamat Tempoh: {format(new Date(trialResult.expiresAt), 'dd MMM yyyy, HH:mm')}
                      </p>
                    )}
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(trialResult.key);
                        alert('Key disalin!');
                      }}
                      className="text-[#D4AF37] text-sm font-medium hover:text-[#F1C40F]"
                    >
                      Salin Key
                    </button>
                  </>
                )}`;

code = code.replace(oldRender, newRender);
fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Fixed render');
