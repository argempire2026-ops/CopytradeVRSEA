const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Update UI Text
code = code.replace(
  '<div className="text-right">\n                <p className="text-xs text-slate-400">Baki Free Trial: <span className="font-bold text-[#D4AF37]">{3 - (clientUser.trialCount || 0)} / 3</span></p>\n              </div>',
  ''
);

code = code.replace(
  '<h3 className="text-lg font-semibold text-slate-200 mb-4">Tuntut Free Trial 1 Hari</h3>',
  '<h3 className="text-lg font-semibold text-slate-200 mb-4">Tuntut Free Trial 3 Hari</h3>'
);

code = code.replace(
  '<p className="text-sm text-slate-400 mb-2">Sila salin License Key anda (Sah 24 Jam):</p>',
  '<p className="text-sm text-slate-400 mb-2">Sila salin License Key anda (Sah 3 Hari):</p>'
);

// 2. Update logic
const oldLogic = `      const currentTrialCount = clientUser.trialCount || 0;
      if (currentTrialCount >= 3) {
        setTrialResult({ key: '', error: 'Anda telah mencapai had maksimum tuntutan Free Trial (3 kali).' });
        setTrialLoading(false);
        return;
      }
    
      // Create a 1 day expiry
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const expiryStr = tomorrow.toISOString(); `;

const newLogic = `      // Create a 3 day expiry
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 3);
      const expiryStr = expiryDate.toISOString();`;

code = code.replace(oldLogic, newLogic);

const oldUpdates = `      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      // No history log for trial
      await updateDoc(doc(db, 'clients', clientUser.email), { trialCount: currentTrialCount + 1 });
      
      setClientUser({ ...clientUser, trialCount: currentTrialCount + 1 });
      setTrialResult({ key: generatedKey, expiresAt: expiryStr });
      setTrialMt5('');`;

const newUpdates = `      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      // No history log for trial
      
      setTrialResult({ key: generatedKey, expiresAt: expiryStr });
      setTrialMt5('');`;

code = code.replace(oldUpdates, newUpdates);

fs.writeFileSync('src/components/Dashboard.tsx', code);
