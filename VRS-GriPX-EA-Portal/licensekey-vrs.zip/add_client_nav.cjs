const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const clientNavButton = `          <div 
            onClick={() => setActiveTab('team')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'team' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Team Access</span>
          </div>
          <div 
            onClick={() => setActiveTab('clients')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'clients' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Clients</span>
          </div>`;

code = code.replace(`          <div 
            onClick={() => setActiveTab('team')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'team' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Team Access</span>
          </div>`, clientNavButton);

fs.writeFileSync('src/components/Dashboard.tsx', code);
