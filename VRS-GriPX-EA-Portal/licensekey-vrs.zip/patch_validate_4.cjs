const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  /if \(!silent\) Alert\("License anda telah DIBATALKAN \\(Revoked\\)!"\);\n            return false;/g,
  `if (!silent) Alert("License anda telah DIBATALKAN (Revoked)!");\n            g_is_expired = true;\n            return false;`
);

code = code.replace(
  /if \(!silent\) Alert\("License anda telah TAMAT TEMPOH \\(Expired\\)!"\);\n            return false;/g,
  `if (!silent) Alert("License anda telah TAMAT TEMPOH (Expired)!");\n            g_is_expired = true;\n            return false;`
);

code = code.replace(
  /if \(!silent\) Alert\("License SAH, tetapi Nama Akaun MT5 anda \\(" \+ AccountInfoString\\(ACCOUNT_NAME\\) \+ "\\) TIDAK DIBENARKAN untuk license ini!"\\);\n                        return false;/g,
  `if (!silent) Alert("License SAH, tetapi Nama Akaun MT5 anda (" + AccountInfoString(ACCOUNT_NAME) + ") TIDAK DIBENARKAN untuk license ini!");\n                        g_is_expired = true;\n                        return false;`
);

fs.writeFileSync('public/ea-code.txt', code);
