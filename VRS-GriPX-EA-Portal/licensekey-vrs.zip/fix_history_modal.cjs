const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Add state
code = code.replace(
  "const [clearingHistory, setClearingHistory] = useState(false);",
  "const [clearingHistory, setClearingHistory] = useState(false);\n  const [showClearHistoryConfirm, setShowClearHistoryConfirm] = useState(false);"
);

// Update function
const oldFunc = `    const handleClearAllHistory = async () => {
    if (!window.confirm('Adakah anda pasti mahu memadam KESEMUA rekod sejarah untuk semua pelanggan? Tindakan ini tidak boleh dipulihkan.')) {
      return;
    }
    setClearingHistory(true);
    try {
      const snap = await getDocs(collection(db, 'licenseHistory'));
      let count = 0;
      snap.forEach((docSnap) => {
        deleteDoc(docSnap.ref);
        count++;
      });
      alert(\`Berjaya memadam \${count} rekod sejarah.\`);
    } catch (error: any) {
      alert('Ralat memadam sejarah: ' + error.message);
    }
    setClearingHistory(false);
  };`;

const newFunc = `  const executeClearAllHistory = async () => {
    setClearingHistory(true);
    try {
      const snap = await getDocs(collection(db, 'licenseHistory'));
      let count = 0;
      const deletePromises: any[] = [];
      snap.forEach((docSnap) => {
        deletePromises.push(deleteDoc(docSnap.ref));
        count++;
      });
      await Promise.all(deletePromises);
      setShowClearHistoryConfirm(false);
    } catch (error: any) {
      alert('Ralat memadam sejarah: ' + error.message);
    }
    setClearingHistory(false);
  };`;

code = code.replace(oldFunc, newFunc);

// Update button onClick
code = code.replace(
  "onClick={handleClearAllHistory}",
  "onClick={() => setShowClearHistoryConfirm(true)}"
);

// Add the modal HTML in the admin render
const modalHtml = `
      {/* Clear History Confirmation Modal */}
      {showClearHistoryConfirm && (
        <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#131E3A] border border-rose-500/30 rounded-xl shadow-2xl max-w-sm w-full overflow-hidden">
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-rose-500" />
              </div>
              <h3 className="text-lg font-bold text-slate-200 mb-2">Adakah anda pasti?</h3>
              <p className="text-sm text-slate-400 mb-6">
                Tindakan ini akan memadam KESEMUA rekod Sejarah & Status Lesen untuk SEMUA pelanggan. Tindakan ini tidak boleh dipulihkan.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowClearHistoryConfirm(false)}
                  disabled={clearingHistory}
                  className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 font-medium rounded-lg hover:bg-slate-700 transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  onClick={executeClearAllHistory}
                  disabled={clearingHistory}
                  className="flex-1 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg transition-colors disabled:opacity-50"
                >
                  {clearingHistory ? 'Memadam...' : 'Setuju Padam Semua Sejarah'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
`;

// Insert it right before the closing </main> of the admin interface. Or before the final closing div of the admin view.
code = code.replace(
  "      </main>\n    </div>\n  );\n}",
  modalHtml + "\n      </main>\n    </div>\n  );\n}"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
