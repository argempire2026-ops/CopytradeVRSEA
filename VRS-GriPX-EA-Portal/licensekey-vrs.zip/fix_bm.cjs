const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const replacements = [
    [/SILA-MASUKKAN-KEY-DI-SINI/g, 'PLEASE-ENTER-KEY-HERE'],
    [/Sila masukkan License Key di bahagian input parameter!/g, 'Please enter the License Key in the input parameter section!'],
    [/Gunakan zon masa Malaysia \(MYT\) untuk semakan luput semasa OnInit/g, 'Use Malaysia timezone (MYT) for expiration check during OnInit'],
    [/License anda telah TAMAT TEMPOH pada /g, 'Your license has EXPIRED on '],
    [/menguruskan posisi sedia ada untuk close profit/g, 'manage existing positions to close in profit'],
    [/tetapi Nama Akaun MT5 anda/g, 'but your MT5 Account Name'],
    [/TIDAK DIBENARKAN untuk license ini!/g, 'is NOT ALLOWED for this license!'],
    [/License anda telah DIBATALKAN \(Revoked\)!/g, 'Your license has been REVOKED!'],
    [/License anda telah TAMAT TEMPOH \(Expired\)! Posisi sedia ada diuruskan untuk Close Profit\./g, 'Your license has EXPIRED! Existing positions will be managed to Close in Profit.'],
    [/status license tidak diketahui. Sila hubungi admin\./g, 'Unknown license status. Please contact admin.'],
    [/License Key tidak dijumpai \(Invalid\)! Sila semak semula key anda\./g, 'License Key not found (Invalid)! Please check your key again.'],
    [/RALAT WEBREQUEST! Sila 'Allow WebRequest' untuk URL:/g, 'WEBREQUEST ERROR! Please \\"Allow WebRequest\\" for URL:'],
    [/Gagal berhubung dengan server Firebase\. Ralat:/g, 'Failed to connect to Firebase server. Error:'],
    [/License anda telah TAMAT TEMPOH \("/g, 'Your license has EXPIRED ("'],
    [/STATUS: EA EXPIRED! Sila renew license anda\.\\nPosisi sedia ada diuruskan untuk Close Profit\.\\nEntry awal baru telah diberhentikan\./g, 'STATUS: EA EXPIRED! Please renew your license.\\nExisting positions will be managed to Close in Profit.\\nNew entries have been stopped.'],
    [/EA EXPIRED! Sila renew license/g, 'EA EXPIRED! Please renew license']
];

for (const [regex, replacement] of replacements) {
    code = code.replace(regex, replacement);
}

fs.writeFileSync('src/eaCode.ts', code);
