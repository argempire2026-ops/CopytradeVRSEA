const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// Find the index of the second occurrence (around 20594)
// Let's just remove the one near `last_news_blocked_state = false`
const toRemove = `if (MQID_NOTI != "") {\\n      string expireStr = TimeToString(g_license_expiry_time, TIME_DATE);\\n      SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\\\\nLicense expires on: " + expireStr);\\n   }`;

code = code.replace(/if \(MQID_NOTI != ""\) \{\s*string expireStr = TimeToString\(g_license_expiry_time, TIME_DATE\);\s*SendNotification\("VRS-GriPX EA has been successfully attached and activated on " \+ _Symbol \+ "!\\nLicense expires on: " \+ expireStr\);\s*\}\s*last_news_blocked/g, 'last_news_blocked');

fs.writeFileSync('src/eaCode.ts', code);
console.log('Cleaned up OnTimer duplication');
