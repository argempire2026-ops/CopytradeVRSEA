const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add states
const statesSearch = "  const [renewLink, setRenewLink] = useState('');";
const statesReplace = "  const [renewLink, setRenewLink] = useState('');\n  const [freeClaimLink, setFreeClaimLink] = useState('');\n  const [showFreeClaimModal, setShowFreeClaimModal] = useState(false);\n  const [freeClaimInputKey, setFreeClaimInputKey] = useState('');\n  const [freeClaimError, setFreeClaimError] = useState('');\n  const [freeClaimLoading, setFreeClaimLoading] = useState(false);";
code = code.replace(statesSearch, statesReplace);

// 2. Add Firestore fetch
const fetchSearch = "        if (data.renewLink) setRenewLink(data.renewLink);";
const fetchReplace = "        if (data.renewLink) setRenewLink(data.renewLink);\n        if (data.freeClaimLink) setFreeClaimLink(data.freeClaimLink);";
code = code.replace(fetchSearch, fetchReplace);

// 3. Add Firestore write
const writeSearch = "        renewLink";
const writeReplace = "        renewLink,\n        freeClaimLink";
code = code.replace(writeSearch, writeReplace);

// 4. Add function logic
const functionSearch = "  const handleClaimTrial = async (e: React.FormEvent) => {";
const functionReplace = `  const handleFreeClaimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFreeClaimError('');
    if (!freeClaimInputKey.trim()) return;
    
    setFreeClaimLoading(true);
    try {
      const keyDoc = await getDoc(doc(db, 'licenseKeys', freeClaimInputKey.trim()));
      if (!keyDoc.exists()) {
        setFreeClaimError('Invalid License Key. Please check and try again.');
        setFreeClaimLoading(false);
        return;
      }
      
      const keyData = keyDoc.data();
      if (keyData.isTrial === true) {
        setFreeClaimError('Trial keys are not eligible for Free Claim. Please enter a subscribed premium license key.');
        setFreeClaimLoading(false);
        return;
      }

      setShowFreeClaimModal(false);
      setFreeClaimInputKey('');
      if (freeClaimLink) {
        window.open(freeClaimLink, '_blank');
      } else {
        alert('Free Claim URL has not been set by Admin.');
      }
    } catch (err: any) {
      setFreeClaimError('Error validating key: ' + err.message);
    }
    setFreeClaimLoading(false);
  };

  const handleClaimTrial = async (e: React.FormEvent) => {`;
code = code.replace(functionSearch, functionReplace);

// 5. Add UI button
const uiHeaderSearch = `<div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-slate-200">{t.activeLicense}</h2>
              
            </div>`;
// Just in case there are varying spaces:
const uiHeaderRegex = /<div className="flex justify-between items-center mb-6">\s*<h2 className="text-xl font-bold text-slate-200">\{t\.activeLicense\}<\/h2>\s*<\/div>/;

const uiHeaderReplace = `<div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-slate-200">{t.activeLicense}</h2>
              <button
                onClick={() => {
                  setFreeClaimError('');
                  setFreeClaimInputKey('');
                  setShowFreeClaimModal(true);
                }}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-500 hover:from-blue-500 hover:to-indigo-400 text-white text-sm font-bold rounded shadow transition-all"
              >
                Free Claim
              </button>
            </div>`;
code = code.replace(uiHeaderRegex, uiHeaderReplace);

// 6. Add Free Claim Modal UI
const modalSearch = "            {showEaModal && (";
const modalReplace = `            {showFreeClaimModal && (
              <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#131E3A] border border-slate-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-slate-200">Free Claim Verification</h3>
                  </div>
                  <form onSubmit={handleFreeClaimSubmit} className="p-6">
                    <p className="text-sm text-slate-300 mb-4">Please enter your License Key after subscribing to proceed with your Free Claim.</p>
                    
                    {freeClaimError && (
                      <div className="mb-4 p-3 bg-red-500/10 border border-red-500/50 rounded text-red-500 text-sm">
                        {freeClaimError}
                      </div>
                    )}

                    <div className="mb-6">
                      <label className="block text-sm font-medium text-slate-400 mb-2">License Key</label>
                      <input
                        type="text"
                        value={freeClaimInputKey}
                        onChange={(e) => setFreeClaimInputKey(e.target.value)}
                        placeholder="Enter your valid premium license key"
                        className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                        required
                      />
                    </div>

                    <div className="flex justify-end gap-3">
                      <button
                        type="button"
                        onClick={() => setShowFreeClaimModal(false)}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={freeClaimLoading || !freeClaimInputKey.trim()}
                        className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-all disabled:opacity-50"
                      >
                        {freeClaimLoading ? 'Verifying...' : 'Verify & Claim'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {showEaModal && (`;
code = code.replace(modalSearch, modalReplace);

// 7. Add Admin Field
const adminSearchRegex = /(<label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Subscription \/ Renew Link<\/label>\s*<input[\s\S]*?className="w-full bg-\[#050914\].*?\n\s*placeholder="e\.g\..*?\n\s*\/>\s*<p.*?>.*?<\/p>\s*<\/div>)/;

const adminReplace = `$1
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 mt-4">Free Claim URL</label>
                      <input
                        type="url"
                        value={freeClaimLink}
                        onChange={(e) => setFreeClaimLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="e.g. https://claim.example.com"
                      />
                      <p className="text-xs text-slate-500 mt-2">This link is used when clients click the Free Claim button with a valid premium license.</p>
                    </div>`;
code = code.replace(adminSearchRegex, adminReplace);

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log("Modifications complete");
