const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const regLogicOld = `    if (!regClientEmail.trim() || !regClientName.trim() || !regClientPassword.trim()) return;
    try {
      const emailKey = regClientEmail.toLowerCase().trim();`;

const regLogicNew = `    if (!regClientEmail.trim() || !regClientName.trim() || !regClientPassword.trim()) return;
    
    if (!regClientEmail.toLowerCase().trim().endsWith('@gmail.com')) {
      setClientRegError('Pendaftaran hanya dibenarkan menggunakan akaun Gmail (@gmail.com).');
      return;
    }
    
    try {
      const emailKey = regClientEmail.toLowerCase().trim();`;

code = code.replace(regLogicOld, regLogicNew);

const createClientLogicOld = `    if (!newClientEmail.trim() || !newClientPassword.trim()) return;
    try {
      const clientRef = doc(db, 'clients', newClientEmail.toLowerCase().trim());`;

const createClientLogicNew = `    if (!newClientEmail.trim() || !newClientPassword.trim()) return;
    
    if (!newClientEmail.toLowerCase().trim().endsWith('@gmail.com')) {
      alert('Pendaftaran hanya dibenarkan menggunakan akaun Gmail (@gmail.com).');
      return;
    }
    
    try {
      const clientRef = doc(db, 'clients', newClientEmail.toLowerCase().trim());`;

code = code.replace(createClientLogicOld, createClientLogicNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
