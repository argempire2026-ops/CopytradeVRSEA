const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const oldParse = `                        datetime expTime = StructToTime(dt);
                        string displayDate = TimeToString(expTime, TIME_DATE|TIME_MINUTES);
                        
                        g_license_expiry_time = expTime; // Simpan masa luput
                        
                        // Gunakan zon masa Malaysia (MYT) untuk semakan luput semasa OnInit
                        datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
                        if (myt_now >= expTime) {`;

// Replace physical newlines with "\\n" because the string contains literal "\\n"
const oldStr = oldParse.replace(/\n/g, '\\n');

const newParse = `                        datetime expTimeUTC = StructToTime(dt);
                        datetime expTimeMYT = expTimeUTC + (Malaysia_GMT_Offset * 3600);
                        string displayDate = TimeToString(expTimeMYT, TIME_DATE|TIME_MINUTES);
                        
                        g_license_expiry_time = expTimeMYT; // Simpan masa luput
                        
                        // Gunakan zon masa Malaysia (MYT) untuk semakan luput semasa OnInit
                        datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
                        if (myt_now >= g_license_expiry_time) {`;

const newStr = newParse.replace(/\n/g, '\\n');

if (code.includes(oldStr)) {
    code = code.replace(oldStr, newStr);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Replaced successfully!");
} else {
    console.log("Could not find the target string. Looking for:");
    console.log(oldStr);
}
