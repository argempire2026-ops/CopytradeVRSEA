const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const newStates = `  const [adminPassword, setAdminPassword] = useState('');
  const [showClientLogin, setShowClientLogin] = useState(false);
  const [clientEmail, setClientEmail] = useState('');
  const [clientPassword, setClientPassword] = useState('');
  const [clientUser, setClientUser] = useState<any>(null);
  const [clientKeys, setClientKeys] = useState<any[]>([]);
  const [clientLoginError, setClientLoginError] = useState('');
  const [clients, setClients] = useState<any[]>([]);
  const [newClientEmail, setNewClientEmail] = useState('');
  const [newClientPassword, setNewClientPassword] = useState('');
  const [newClientName, setNewClientName] = useState('');`;

code = code.replace("  const [adminPassword, setAdminPassword] = useState('');", newStates);
fs.writeFileSync('src/components/Dashboard.tsx', code);
