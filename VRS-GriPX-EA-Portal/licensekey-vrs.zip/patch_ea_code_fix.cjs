const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  'string project_id = "licensekey-ea";',
  'string project_id = "hypnic-era-707pf";'
);
code = code.replace(
  'string database_id = "(default)";',
  'string database_id = "ai-studio-245cc25a-6f6b-40e7-ad09-9650e6274c82";'
);
code = code.replace(
  'string api_key = "AIzaSyDW8z9Ef9PgvVF4dbYO4VY7O_Jt_37Vt9E";',
  'string api_key = "AIzaSyCRnWnBVLhgbNcxh0jEss65VqgEbV7E22k";'
);

fs.writeFileSync('public/ea-code.txt', code);
