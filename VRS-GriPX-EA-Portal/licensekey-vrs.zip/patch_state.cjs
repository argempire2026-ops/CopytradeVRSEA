const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "const [activeTab, setActiveTab] = useState<'keys' | 'ea'>('keys');",
  "const [activeTab, setActiveTab] = useState<'keys' | 'ea' | 'html'>('keys');\n  const [htmlCode, setHtmlCode] = useState<string>('');"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
