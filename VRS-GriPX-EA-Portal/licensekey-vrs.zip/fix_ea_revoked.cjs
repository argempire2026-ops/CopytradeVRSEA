const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const revokedRegex = /else if \(StringFind\(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"revoked\\\\\\"\\"\) > 0\)\\n        \{\\n            Alert\(\\"License anda telah DIBATALKAN \(Revoked\)!\\"\);\\n            return false;\\n        \}/;

const newRevoked = `else if (StringFind(resultStr, \\"\\\\\\"stringValue\\\\\\":\\\\\\"revoked\\\\\\"\\") > 0)\\n        {\\n            Alert(\\"License anda telah DIBATALKAN (Revoked)! EA dihentikan.\\");\\n            ExpertRemove();\\n            return false;\\n        }`;

if (revokedRegex.test(code)) {
    code = code.replace(revokedRegex, newRevoked);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Fixed revoked logic!");
} else {
    console.log("Could not find revoked logic with regex.");
}
