const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');
let parseCode = code.match(/StringSplit\\(resultStr, ',', keyValuePairs\\);.*?(?=if \\(!g_is_active\\))/s);
if (parseCode) {
    console.log(parseCode[0].substring(0, 1000));
} else {
    console.log("Not found");
}
