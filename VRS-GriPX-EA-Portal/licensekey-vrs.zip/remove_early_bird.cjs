const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Remove early bird from state
const statesToRemove = `  const [earlyBirdLimit, setEarlyBirdLimit] = useState(0);
  const [earlyBirdDays, setEarlyBirdDays] = useState(7);
  const [earlyBirdClaimed, setEarlyBirdClaimed] = useState(0);`;
code = code.replace(statesToRemove, "");

// 2. Remove early bird from fetch
const fetchToRemove = `        if (data.earlyBirdLimit !== undefined) setEarlyBirdLimit(data.earlyBirdLimit);
        if (data.earlyBirdDays !== undefined) setEarlyBirdDays(data.earlyBirdDays);
        if (data.earlyBirdClaimed !== undefined) setEarlyBirdClaimed(data.earlyBirdClaimed);`;
code = code.replace(fetchToRemove, "");

// 3. Remove early bird from save settings
const saveToRemove = `        earlyBirdLimit,
        earlyBirdDays,
        earlyBirdClaimed,`;
code = code.replace(saveToRemove, "");

// 4. Update UI in settings
const settingsUIOld = `<label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Early Bird Limit (Quota)</label>
                  <input type="number" min="0" value={earlyBirdLimit} onChange={(e) => setEarlyBirdLimit(parseInt(e.target.value) || 0)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-1" />
                  <p className="text-xs text-slate-500 mb-6">First N claims will get the early bird promo duration. Set to 0 to disable.</p>

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Early Bird Duration (Days)</label>
                  <input type="number" min="1" value={earlyBirdDays} onChange={(e) => setEarlyBirdDays(parseInt(e.target.value) || 7)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-6" />

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Early Bird Claimed (Editable to Reset)</label>
                  <input type="number" min="0" value={earlyBirdClaimed} onChange={(e) => setEarlyBirdClaimed(parseInt(e.target.value) || 0)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-6" />`;
code = code.replace(settingsUIOld, "");

// 5. Update Claim logic
const claimLogicOld = `      // Get latest settings to check promo
      let daysToGive = defaultTrialDays;
      const settingsSnap = await getDoc(doc(db, 'settings', 'general'));
      if (settingsSnap.exists()) {
        const sData = settingsSnap.data();
        const currentClaimed = sData.earlyBirdClaimed || 0;
        const currentLimit = sData.earlyBirdLimit || 0;
        if (currentLimit > 0 && currentClaimed < currentLimit) {
          daysToGive = sData.earlyBirdDays || 7;
          // Increment promo claimed
          await updateDoc(doc(db, 'settings', 'general'), {
            earlyBirdClaimed: increment(1)
          });
          setEarlyBirdClaimed(currentClaimed + 1);
        }
      }

      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + daysToGive);
      const expiryStr = expiryDate.toISOString();`;

const claimLogicNew = `      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + defaultTrialDays);
      const expiryStr = expiryDate.toISOString();`;

code = code.replace(claimLogicOld, claimLogicNew);

// 6. Update the Claim Panel Header & Info
const headerOld = `<h3 className="text-lg font-semibold text-slate-200 mb-4">
                {earlyBirdLimit > 0 && earlyBirdClaimed < earlyBirdLimit 
                  ? \`Claim \${earlyBirdDays}-Day Free Trial (Early Bird Promo!)\`
                  : \`Claim \${defaultTrialDays}-Day Free Trial\`}
              </h3>`;

const headerNew = `              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-slate-200">Claim {defaultTrialDays}-Day Free Trial</h3>
                <div className="text-sm font-medium px-3 py-1 bg-slate-800 rounded-full text-slate-300">
                  {clientUser.trialCount || 0} / {clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials} Claimed
                </div>
              </div>
              <p className="text-sm text-slate-400 mb-6">
                You have <strong>{(clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials) - (clientUser.trialCount || 0)}</strong> claims remaining.
              </p>`;

code = code.replace(headerOld, headerNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
