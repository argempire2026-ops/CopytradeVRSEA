const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const oldStr = 'ObjectSetString(0, \\\\\\"VRS_UI_License_Lbl\\\\\\", OBJPROP_TEXT, \\\\\\"License Expiry: \\\\\\" + g_license_expiry);';
const newStr = `   string licenseText = \\\\\\"License Expiry: \\\\\\" + g_license_expiry;
   if (g_is_trial) licenseText = \\\\\\"TRIAL LICENSE - Expiry: \\\\\\" + g_license_expiry;
   ObjectSetString(0, \\\\\\"VRS_UI_License_Lbl\\\\\\", OBJPROP_TEXT, licenseText);
   if (g_is_trial) ObjectSetInteger(0, \\\\\\"VRS_UI_License_Lbl\\\\\\", OBJPROP_COLOR, cp_yellow);`;

if (code.includes('ObjectSetString(0, \\"VRS_UI_License_Lbl\\", OBJPROP_TEXT, \\"License Expiry: \\" + g_license_expiry);')) {
    code = code.replace(
        'ObjectSetString(0, \\"VRS_UI_License_Lbl\\", OBJPROP_TEXT, \\"License Expiry: \\" + g_license_expiry);',
        newStr.replace(/\n/g, '\\n').replace(/\\\\"/g, '\\"')
    );
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Replaced UI update successfully!");
} else {
    console.log("Could not find the UI update string.");
}
