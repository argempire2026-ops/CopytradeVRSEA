const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The original parsing block
const oldParse = `                        if (ArraySize(dtParts) == 2) {
                            string timeParts[];
                            StringSplit(dtParts[1], ':', timeParts);
                            if (ArraySize(timeParts) >= 2) {
                                dt.hour = (int)StringToInteger(timeParts[0]);
                                dt.min = (int)StringToInteger(timeParts[1]);
                                dt.sec = 0;
                            } else {
                                dt.hour = 23; dt.min = 59; dt.sec = 59;
                            }
                        } else {
                            dt.hour = 23; dt.min = 59; dt.sec = 59;
                        }
                        
                        datetime expTime = StructToTime(dt);
                        string displayDate = TimeToString(expTime, TIME_DATE|TIME_MINUTES);
                        
                        g_license_expiry_time = expTime; // Simpan masa luput
                        
                        // Gunakan zon masa Malaysia (MYT) untuk semakan luput semasa OnInit
                        datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
                        if (myt_now >= expTime) {`;

const newParse = `                        if (ArraySize(dtParts) == 2) {
                            string timeParts[];
                            StringSplit(dtParts[1], ':', timeParts);
                            if (ArraySize(timeParts) >= 2) {
                                dt.hour = (int)StringToInteger(timeParts[0]);
                                dt.min = (int)StringToInteger(timeParts[1]);
                                dt.sec = 0;
                            } else {
                                dt.hour = 23; dt.min = 59; dt.sec = 59;
                            }
                        } else {
                            dt.hour = 23; dt.min = 59; dt.sec = 59;
                        }
                        
                        datetime expTimeUTC = StructToTime(dt);
                        // Convert UTC expiry to MYT for display and logic
                        datetime expTimeMYT = expTimeUTC + (Malaysia_GMT_Offset * 3600);
                        string displayDate = TimeToString(expTimeMYT, TIME_DATE|TIME_MINUTES);
                        
                        g_license_expiry_time = expTimeMYT; // Simpan masa luput dalam MYT
                        
                        // Gunakan zon masa Malaysia (MYT) untuk semakan luput semasa OnInit
                        datetime myt_now = TimeGMT() + (Malaysia_GMT_Offset * 3600);
                        if (myt_now >= g_license_expiry_time) {`;

code = code.replace(oldParse, newParse);
fs.writeFileSync('src/eaCode.ts', code);
