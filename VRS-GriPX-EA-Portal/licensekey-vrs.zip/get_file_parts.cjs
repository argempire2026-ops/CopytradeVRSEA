const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const tStart = code.indexOf('const t = {');
const tEnd = code.indexOf('export default function Dashboard() {');

console.log("Found dictionary? ", tStart !== -1 && tEnd !== -1);
