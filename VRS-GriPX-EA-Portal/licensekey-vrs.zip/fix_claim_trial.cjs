const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Update setClientUser to include trialCount
code = code.replace(
  "setClientUser({ email: matchedClient.email, name: matchedClient.name });",
  "setClientUser({ email: matchedClient.email, name: matchedClient.name, trialCount: matchedClient.trialCount || 0 });"
);

// 2. Rewrite handleClaimTrial
const oldHandleClaimTrial = /const handleClaimTrial = async[\s\S]*?const handleCopyKey/m;
const newHandleClaimTrial = `const handleClaimTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialMt5.trim() || !clientUser) return;
    
    setTrialLoading(true);
    setTrialResult(null);
    try {
      const currentTrialCount = clientUser.trialCount || 0;
      if (currentTrialCount >= 3) {
        setTrialResult({ key: '', error: 'Anda telah mencapai had maksimum tuntutan Free Trial (3 kali).' });
        setTrialLoading(false);
        return;
      }
    
      // Create a 1 day expiry
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const expiryStr = tomorrow.toISOString(); 
      
      const generatedKey = 'TRIAL-' + generateRandomKey().substring(0, 8);
      
      const newKey: any = {
        id: generatedKey,
        key: generatedKey,
        customerEmail: clientUser.email,
        customerName: 'Trial MT5: ' + trialMt5.trim(),
        allowedAccounts: trialMt5.trim(),
        status: 'active',
        ownerUid: 'system_trial',
        createdAt: serverTimestamp(),
        expiresAt: expiryStr,
        isTrial: true
      };
      
      await setDoc(doc(db, 'licenseKeys', generatedKey), newKey);
      await updateDoc(doc(db, 'clients', clientUser.email), { trialCount: currentTrialCount + 1 });
      
      setClientUser({ ...clientUser, trialCount: currentTrialCount + 1 });
      setTrialResult({ key: generatedKey, expiresAt: expiryStr });
      setTrialMt5('');
    } catch (error: any) {
      console.error(error);
      setTrialResult({ key: '', error: 'Gagal menjana trial. ' + error.message });
    } finally {
      setTrialLoading(false);
    }
  };

  const handleCopyKey`;
code = code.replace(oldHandleClaimTrial, newHandleClaimTrial);

// 3. Remove Claim Trial from public login form
const claimTrialPublicRegex = /<\>\s*<h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Claim Trial 1 Hari<\/h2>[\s\S]*?<\/form>\s*\)\}\s*<\/>\s*\)\}/;
code = code.replace(claimTrialPublicRegex, '');

// 4. Add Claim Trial to Client Portal
const clientPortalStartRegex = /<h2 className="text-xl font-bold text-slate-200 mb-6">Lesen Aktif Anda<\/h2>/;
const clientPortalClaimTrial = `<div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-slate-200">Lesen Aktif Anda</h2>
              <div className="text-right">
                <p className="text-xs text-slate-400">Baki Free Trial: <span className="font-bold text-[#D4AF37]">{3 - (clientUser.trialCount || 0)} / 3</span></p>
              </div>
            </div>
            
            <div className="bg-[#131E3A] p-6 rounded-xl shadow-lg border border-slate-800 mb-8">
              <h3 className="text-lg font-semibold text-slate-200 mb-4">Tuntut Free Trial 1 Hari</h3>
              {trialResult ? (
                <div className="p-4 rounded-lg border bg-[#050914] text-center max-w-md mx-auto">
                  {trialResult.error ? (
                    <>
                      <p className="text-red-500 font-medium mb-4">{trialResult.error}</p>
                      <button onClick={() => setTrialResult(null)} className="text-[#D4AF37] text-sm hover:underline">Kembali</button>
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-slate-400 mb-2">Sila salin License Key anda (Sah 24 Jam):</p>
                      <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                        {trialResult.key}
                      </div>
                      {trialResult.expiresAt && (
                        <p className="text-xs text-rose-400 mb-4">
                          Tamat Tempoh: {new Date(trialResult.expiresAt).toLocaleDateString('ms-MY', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                      <div className="flex gap-4 justify-center">
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(trialResult.key);
                            alert('Key disalin!');
                          }}
                          className="px-4 py-2 bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#F1C40F]/20 hover:text-[#F1C40F] rounded transition-colors"
                        >
                          Salin Key
                        </button>
                        <button onClick={() => setTrialResult(null)} className="px-4 py-2 bg-slate-800 text-slate-300 text-sm hover:bg-slate-700 rounded transition-colors">Tutup</button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <form onSubmit={handleClaimTrial} className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-1 w-full max-w-md">
                    <label className="block text-sm font-medium text-slate-300 mb-1">Nama MT5 (Berdaftar Dengan Broker)</label>
                    <input
                      type="text"
                      value={trialMt5}
                      onChange={(e) => setTrialMt5(e.target.value)}
                      placeholder="Contoh: MUHAMAD FAAIZ"
                      className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={trialLoading || !trialMt5.trim() || (clientUser.trialCount || 0) >= 3}
                    className="w-full sm:w-auto py-3 px-6 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors disabled:opacity-50 whitespace-nowrap"
                  >
                    {trialLoading ? 'Memproses...' : 'Tuntut Trial'}
                  </button>
                </form>
              )}
            </div>`;
code = code.replace(clientPortalStartRegex, clientPortalClaimTrial);

fs.writeFileSync('src/components/Dashboard.tsx', code);
