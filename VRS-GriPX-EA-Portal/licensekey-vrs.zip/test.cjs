const fs = require('fs');
let content = fs.readFileSync('public/dashboard-export.html', 'utf-8');
console.log("Found custom key:", content.includes("AIzaSyDW8z9Ef9PgvVF4dbYO4VY7O_Jt_37Vt9E"));
