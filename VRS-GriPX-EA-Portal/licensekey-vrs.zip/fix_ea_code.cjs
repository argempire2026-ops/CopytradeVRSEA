const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');
if (code.startsWith('undefined`')) {
    code = code.replace('undefined`', 'export const EA_CODE = String.raw`');
}
if (code.startsWith('export const EA_CODE = `\n')) {
    code = code.replace('export const EA_CODE = `\n', 'export const EA_CODE = String.raw`\n');
}
fs.writeFileSync('src/eaCode.ts', code);
console.log('Fixed export statement');
