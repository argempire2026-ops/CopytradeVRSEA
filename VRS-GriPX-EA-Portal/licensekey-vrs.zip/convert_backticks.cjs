const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// The file currently looks like: export const EA_CODE = "...";
// We will evaluate it (or extract it) and wrap it in backticks.
// Since it's a valid TS file except for the error, wait, the error is Unterminated string literal, which means it IS currently broken.
// I will just use regex to extract the inner string from `export const EA_CODE = "` and `";`
// But wait, the file is ALREADY broken because of an unescaped double quote somewhere, which terminated the string early!

const prefix = 'export const EA_CODE = "';
if (code.startsWith(prefix)) {
    let inner = code.substring(prefix.length);
    if (inner.endsWith('";\n')) {
        inner = inner.substring(0, inner.length - 3);
    } else if (inner.endsWith('";')) {
        inner = inner.substring(0, inner.length - 2);
    }
    
    // Now inner is the string with lots of \n and \".
    // We want to unescape \n to real newlines, and \" to real ".
    let realStr = '';
    for(let i=0; i<inner.length; i++) {
        if (inner[i] === '\\') {
            if (inner[i+1] === 'n') {
                realStr += '\n';
                i++;
            } else if (inner[i+1] === '"') {
                realStr += '"';
                i++;
            } else if (inner[i+1] === 'r') {
                realStr += '\r';
                i++;
            } else if (inner[i+1] === 't') {
                realStr += '\t';
                i++;
            } else if (inner[i+1] === '\\') {
                realStr += '\\';
                i++;
            } else {
                realStr += '\\';
            }
        } else {
            realStr += inner[i];
        }
    }
    
    // Now we have the pure EA code as a string!
    // We can write it back using backticks.
    // Wait, if it has backticks or ${}, we must escape them for the JS template literal.
    realStr = realStr.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
    
    const newFile = 'export const EA_CODE = `\n' + realStr + '\n`;\n';
    fs.writeFileSync('src/eaCode.ts', newFile);
    console.log('Converted to backticks');
} else {
    console.log('Does not start with export const EA_CODE = "');
}
