const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const tReplaceEn = `
    removeEa: 'Remove',
    selectEa: 'Select EA to view details',
    downloadNow: 'Download Now',
    linkNotProvided: 'Link Not Provided',
    noEaProvided: 'No EA provided at this time.',
    noDescription: 'No description provided by Admin at this time.',
    clientLogin: 'Client Login',
    registeredEmailPlaceholder: 'Registered Email',
    passwordPlaceholder: 'Password',
    loginBtn: 'Login',
    welcomeMsg: 'Welcome to VRS Community Client Portal.\\nPlease log in or register a new account.',
    registerNewAccount: 'Register New Account',
    backBtn: 'Back',
    clientRegister: 'Client Registration',
    adminAccess: 'Admin Access',
    invalidPassword: 'Invalid Password'
  },`;

const tReplaceMs = `
    removeEa: 'Buang',
    selectEa: 'Pilih EA untuk lihat butiran',
    downloadNow: 'Muat Turun Sekarang',
    linkNotProvided: 'Link Belum Disediakan',
    noEaProvided: 'Tiada EA disediakan buat masa ini.',
    noDescription: 'Tiada keterangan disediakan oleh Admin buat masa ini.',
    clientLogin: 'Log Masuk Pelanggan',
    registeredEmailPlaceholder: 'E-mel Mendaftar',
    passwordPlaceholder: 'Kata Laluan',
    loginBtn: 'Log Masuk',
    welcomeMsg: 'Selamat datang ke Portal Pelanggan VRS Community.\\nSila log masuk atau daftar akaun baru.',
    registerNewAccount: 'Daftar Akaun Baru',
    backBtn: 'Kembali',
    clientRegister: 'Pendaftaran Pelanggan',
    adminAccess: 'Akses Admin',
    invalidPassword: 'Kata Laluan Tidak Sah'
  }
};`;

code = code.replace(/removeEa: 'Remove',\n\s*selectEa: 'Select EA to view details',\n\s*downloadNow: 'Download Now',\n\s*linkNotProvided: 'Link Not Provided',\n\s*noEaProvided: 'No EA provided at this time.',\n\s*noDescription: 'No description provided by Admin at this time.'\n\s*},\n/m, tReplaceEn + '\n');
code = code.replace(/removeEa: 'Buang',\n\s*selectEa: 'Pilih EA untuk lihat butiran',\n\s*downloadNow: 'Muat Turun Sekarang',\n\s*linkNotProvided: 'Link Belum Disediakan',\n\s*noEaProvided: 'Tiada EA disediakan buat masa ini.',\n\s*noDescription: 'Tiada keterangan disediakan oleh Admin buat masa ini.'\n\s*}\n};\n/m, tReplaceMs + '\n');

// Then apply replacing in the return statement for the unauthenticated view

// Replace language toggle logic inside the unauthenticated view. 
// I'll add the language toggler just below the "VRS Community" text.

const oldHeader = `<h1 className="text-2xl font-bold text-slate-200 mb-1 text-center">VRS (EXPERT ADVISOR)</h1>
          <p className="text-sm text-slate-400 text-center mb-8 font-medium">VRS Community</p>`;

const newHeader = `<h1 className="text-2xl font-bold text-slate-200 mb-1 text-center">VRS (EXPERT ADVISOR)</h1>
          <p className="text-sm text-slate-400 text-center mb-6 font-medium">VRS Community</p>
          <div className="flex bg-[#050914] p-1 rounded-lg mb-6 self-center">
            <button 
              onClick={() => setLang('en')}
              className={\`px-4 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'en' ? 'bg-[#D4AF37] text-slate-900' : 'text-slate-500 hover:text-slate-300'}\`}
            >
              ENG
            </button>
            <button 
              onClick={() => setLang('ms')}
              className={\`px-4 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'ms' ? 'bg-[#D4AF37] text-slate-900' : 'text-slate-500 hover:text-slate-300'}\`}
            >
              BM
            </button>
          </div>`;

code = code.replace(oldHeader, newHeader);


// Translating the fields
code = code.replace(/>Admin Access<\/h2>/g, '>{t[lang].adminAccess}</h2>');
code = code.replace(/Kata Laluan/g, '{t[lang].passwordPlaceholder}');
code = code.replace(/>\s*Log Masuk\s*<\/button>/g, '>{t[lang].loginBtn}</button>');
code = code.replace(/>\s*Kembali\s*<\/button>/g, '>{t[lang].backBtn}</button>');
code = code.replace(/>Log Masuk Pelanggan<\/h2>/g, '>{t[lang].clientLogin}</h2>');
code = code.replace(/>Pendaftaran Pelanggan<\/h2>/g, '>{t[lang].clientRegister}</h2>');
code = code.replace(/E-mel Mendaftar/g, '{t[lang].registeredEmailPlaceholder}');
code = code.replace(/Selamat datang ke Portal Pelanggan VRS Community.<br\/>Sila log masuk atau daftar akaun baru./g, '{t[lang].welcomeMsg.split(\'\\\\n\').map((line, i) => <React.Fragment key={i}>{line}<br/></React.Fragment>)}');
code = code.replace(/>\s*Log Masuk Pelanggan\s*<\/button>/g, '>{t[lang].clientLogin}</button>');
code = code.replace(/>\s*Daftar Akaun Baru\s*<\/button>/g, '>{t[lang].registerNewAccount}</button>');
code = code.replace(/>\s*Daftar Akaun Baru\s*<\/a>/g, '>{t[lang].registerNewAccount}</a>');
code = code.replace(/>\s*Daftar Akaun Baru\s*<\/span>/g, '>{t[lang].registerNewAccount}</span>');


fs.writeFileSync('src/components/Dashboard.tsx', code);
