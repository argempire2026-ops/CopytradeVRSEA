const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldState = `  const [adminUnlockClicks, setAdminUnlockClicks] = useState(0);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [trialMt5, setTrialMt5] = useState('');`;

const newState = `  const [adminUnlockClicks, setAdminUnlockClicks] = useState(0);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [trialMt5, setTrialMt5] = useState('');`;

code = code.replace(oldState, newState);

const oldHandle = `  const handleLogoClick = () => {
    if (showAdminLogin) return;
    const clicks = adminUnlockClicks + 1;
    setAdminUnlockClicks(clicks);
    if (clicks >= 5) {
      const pwd = window.prompt("Enter admin password:");
      if (pwd === "VRS123") {
        setShowAdminLogin(true);
      }
      setAdminUnlockClicks(0);
    }
  };`;

const newHandle = `  const handleLogoClick = () => {
    if (showAdminLogin || showPasswordPrompt) return;
    setAdminUnlockClicks(prev => {
      const clicks = prev + 1;
      if (clicks >= 5) {
        setShowPasswordPrompt(true);
        return 0;
      }
      return clicks;
    });
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === "VRS123") {
      setShowAdminLogin(true);
      setShowPasswordPrompt(false);
      setAdminPassword('');
    } else {
      alert("Password salah.");
      setShowPasswordPrompt(false);
      setAdminPassword('');
    }
  };`;

code = code.replace(oldHandle, newHandle);

const oldUi = `        <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 flex flex-col items-center max-w-sm w-full">
          <div onClick={handleLogoClick} className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-4xl mb-4 cursor-pointer select-none">
            V
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-1 text-center">VRS (EXPERT ADVISOR)</h1>
          <p className="text-sm text-slate-500 text-center mb-8 font-medium">VRS Community</p>
          
          <div className="w-full">
            <h2 className="text-lg font-semibold text-slate-700 mb-4 text-center">Claim Trial 1 Hari</h2>
            
            {trialResult ? (`;

const newUi = `        <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 flex flex-col items-center max-w-sm w-full">
          <img 
            onClick={handleLogoClick} 
            src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" 
            alt="VRS Logo"
            className="w-20 h-20 rounded-2xl mb-4 cursor-pointer select-none object-cover"
          />
          <h1 className="text-2xl font-bold text-slate-800 mb-1 text-center">VRS (EXPERT ADVISOR)</h1>
          <p className="text-sm text-slate-500 text-center mb-8 font-medium">VRS Community</p>
          
          <div className="w-full">
            {showPasswordPrompt ? (
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-700 mb-4 text-center">Admin Access</h2>
                <div>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full p-3 border border-slate-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                    autoFocus
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded shadow transition-colors">
                  Submit
                </button>
                <button type="button" onClick={() => setShowPasswordPrompt(false)} className="w-full mt-2 py-2 text-sm text-slate-500 hover:text-slate-700">Cancel</button>
              </form>
            ) : (
              <>
                <h2 className="text-lg font-semibold text-slate-700 mb-4 text-center">Claim Trial 1 Hari</h2>
                
                {trialResult ? (`

code = code.replace(oldUi, newUi);

const oldSmallLogo = `<div className="w-6 h-6 md:w-8 md:h-8 bg-indigo-500 rounded flex items-center justify-center text-white font-bold text-sm md:text-xl">V</div>`;
const newSmallLogo = `<img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-6 h-6 md:w-8 md:h-8 rounded object-cover" alt="VRS Logo" />`;

code = code.replace(oldSmallLogo, newSmallLogo);

// There is one more small logo in the admin login UI. Let's find it.
const oldAdminLogo = `<div className="w-12 h-12 bg-indigo-500 rounded flex items-center justify-center text-white font-bold text-2xl mb-4">V</div>`;
const newAdminLogo = `<img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-16 h-16 rounded-xl mb-4 object-cover" alt="VRS Logo" />`;

code = code.replace(oldAdminLogo, newAdminLogo);

// We need to also close the <> in the newUi fragment if we opened it.
const oldFormEnd = `                </button>
              </form>
            )}
          </div>
        </div>`;
const newFormEnd = `                </button>
              </form>
            )}
            </>
            )}
          </div>
        </div>`;

code = code.replace(oldFormEnd, newFormEnd);

fs.writeFileSync('src/components/Dashboard.tsx', code);
