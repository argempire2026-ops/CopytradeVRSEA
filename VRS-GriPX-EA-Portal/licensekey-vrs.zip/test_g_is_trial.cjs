const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');
let count = (code.match(/g_is_trial/g) || []).length;
console.log("Count of g_is_trial: " + count);
