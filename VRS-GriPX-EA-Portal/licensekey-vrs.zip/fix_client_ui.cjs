const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldUI = `              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-slate-200">Claim {defaultTrialDays}-Day Free Trial</h3>
                <div className="text-sm font-medium px-3 py-1 bg-slate-800 rounded-full text-slate-300">
                  {clientUser.trialCount || 0} / {clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials} Claimed
                </div>
              </div>
              <p className="text-sm text-slate-400 mb-6">
                You have <strong>{(clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials) - (clientUser.trialCount || 0)}</strong> claims remaining.
              </p>`;

const newUI = `              <div className="mb-4">
                <h3 className="text-lg font-semibold text-slate-200">Claim {defaultTrialDays}-Day Free Trial</h3>
              </div>`;

code = code.replace(oldUI, newUI);
fs.writeFileSync('src/components/Dashboard.tsx', code);
