const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

const oldBlock = `   if (g_is_expired) {
      Comment("STATUS: EA EXPIRED! Sila renew license anda.\\nPosisi sedia ada diuruskan untuk Close Profit.\\nEntry awal baru telah diberhentikan.");
      
      int B, S, BL, SL, BS, SS;
      COUNT_ORDERS(B, S, BL, SL, BS, SS, MAGIC_NUMBER);
      if (B == 0 && S == 0) {
         return; // Berhenti pelaksanaan EA sepenuhnya jika tiada entry
      }
      // Biarkan pelaksanaan diteruskan supaya Trailing Stop, TP, dan Grid berjalan.
   }`;

const newBlock = `   if (g_is_expired) {
      Comment("STATUS: EA EXPIRED! Sila renew license anda.\\nPosisi sedia ada diuruskan untuk Close Profit.\\nEntry awal baru telah diberhentikan.");
      
      int B, S, BL, SL, BS, SS;
      COUNT_ORDERS(B, S, BL, SL, BS, SS, MAGIC_NUMBER);
      if (B == 0 && S == 0) {
         // Padam semua pending orders
         for (int i = OrdersTotal() - 1; i >= 0; i--) {
            ulong ticket = OrderGetTicket(i);
            if (ticket != 0 && OrderGetString(ORDER_SYMBOL) == _Symbol && ((long)OrderGetInteger(ORDER_MAGIC) == MAGIC_NUMBER || MAGIC_NUMBER == -1)) {
               Trade.OrderDelete(ticket);
            }
         }
         ExpertRemove(); // Berhentikan EA sepenuhnya dari chart
         return;
      }
      // Biarkan pelaksanaan diteruskan supaya Trailing Stop, TP, dan Grid berjalan.
   }`;

code = code.replace(oldBlock, newBlock);
fs.writeFileSync('public/ea-code.txt', code);
