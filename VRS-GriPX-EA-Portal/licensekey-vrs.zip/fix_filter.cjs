const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const searchHtml = `<div className="p-4 border-b border-slate-800/50 bg-[#0A1024] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shrink-0">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-tight">Recent License Generations</h3>
              <input
                type="text"
                placeholder="Cari emel / nama / kunci..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-[#050914] text-white rounded px-3 py-1.5 text-xs border border-slate-800 focus:border-[#D4AF37] outline-none w-full sm:w-64"
              />
            </div>`;

code = code.replace(
  `<div className="p-4 border-b border-slate-800/50 bg-[#0A1024] flex justify-between items-center shrink-0">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-tight">Recent License Generations</h3>
            </div>`,
  searchHtml
);

code = code.replace(
  "{keys.map(k => (",
  "{keys.filter(k => k.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) || (k.customerName && k.customerName.toLowerCase().includes(searchTerm.toLowerCase())) || k.key.toLowerCase().includes(searchTerm.toLowerCase())).map(k => ("
);
code = code.replace(
  "{keys.map((k) => (",
  "{keys.filter(k => k.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) || (k.customerName && k.customerName.toLowerCase().includes(searchTerm.toLowerCase())) || k.key.toLowerCase().includes(searchTerm.toLowerCase())).map(k => ("
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
