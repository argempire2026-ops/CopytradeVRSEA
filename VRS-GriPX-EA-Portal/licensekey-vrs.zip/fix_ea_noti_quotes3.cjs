const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// We want to write literal backslash, double quote, etc.
const toFind = `SendNotification("VRS-GriPX EA has been successfully attached and activated on " + _Symbol + "!\\nLicense expires on: " + expireStr);`;
const toFind2 = `SendNotification(\\"VRS-GriPX EA has been successfully attached and activated on \\" + _Symbol + \\"!\\\\nLicense expires on: \\" + expireStr);`;

const correctStr = 'SendNotification(\\"VRS-GriPX EA has been successfully attached and activated on \\" + _Symbol + \\"!\\\\nLicense expires on: \\" + expireStr);';

code = code.split(toFind).join(correctStr);
code = code.split(toFind2).join(correctStr);
fs.writeFileSync('src/eaCode.ts', code);
console.log('Fixed EA code with precise escaping');
