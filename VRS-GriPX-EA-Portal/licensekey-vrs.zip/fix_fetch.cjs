const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "fetch('/dashboard-export.html?v=' + new Date().getTime()).then(res => res.text()).then(text => setHtmlCode(text)).catch(err => console.error(err));",
  "fetch('/dashboard-export.html?v=' + new Date().getTime()).then(res => { if (!res.ok) throw new Error('Not found'); return res.text(); }).then(text => setHtmlCode(text)).catch(err => setHtmlCode('// Sila run \"npm run build && cp dist/index.html public/dashboard-export.html\" untuk lihat kod HTML ini.\\n// Gagal memuat HTML source code.'));"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
