const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Import Users
code = code.replace(
  "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download } from 'lucide-react';",
  "import { Key, Plus, Trash2, Ban, CheckCircle, Clock, Code, Copy, Download, Users } from 'lucide-react';"
);

// 2. Change activeTab type
code = code.replace(
  "const [activeTab, setActiveTab] = useState<'keys' | 'ea' | 'html'>('keys');",
  "const [activeTab, setActiveTab] = useState<'keys' | 'ea' | 'html' | 'team'>('keys');\n  const [admins, setAdmins] = useState<{email: string}[]>([]);\n  const [newAdminEmail, setNewAdminEmail] = useState('');"
);

// 3. Add useEffect and handlers for admins
const adminEffects = `
  useEffect(() => {
    if (user && user.email === 'mfrdotbiz@gmail.com') {
      const q = query(collection(db, 'admins'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const adminsData = [];
        snapshot.docs.forEach(doc => adminsData.push({ email: doc.id }));
        setAdmins(adminsData);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim()) return;
    try {
      await setDoc(doc(db, 'admins', newAdminEmail.trim().toLowerCase()), { addedAt: serverTimestamp() });
      setNewAdminEmail('');
    } catch (error) {
      alert("Failed to add admin: " + error.message);
    }
  };

  const handleRemoveAdmin = async (email: string) => {
    try {
      await deleteDoc(doc(db, 'admins', email));
    } catch (error) {
      alert("Failed to remove admin: " + error.message);
    }
  };

  const handleCreate`;

code = code.replace("  const handleCreate", adminEffects);

// 4. Add Team tab in sidebar (nav)
const newTeamTab = `          <div 
            onClick={() => setActiveTab('team')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'team' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Team Access</span>
          </div>
        </nav>`;

code = code.replace("        </nav>", newTeamTab);

// 5. Add Header logic
code = code.replace(
  "{activeTab === 'keys' ? 'Overview' : activeTab === 'ea' ? 'EA Code Source' : 'Web HTML Source'}",
  "{activeTab === 'keys' ? 'Overview' : activeTab === 'ea' ? 'EA Code Source' : activeTab === 'html' ? 'Web HTML Source' : 'Team Access'}"
);

// 6. Add Team UI inside main content
const teamUI = `
          ) : activeTab === 'team' ? (
            <div className="flex-1 flex flex-col gap-6">
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm shrink-0">
                <h3 className="text-sm uppercase font-bold text-slate-800 tracking-wider mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4 text-indigo-500" />
                  Shared Access Management
                </h3>
                <p className="text-xs text-slate-500 mb-6">
                  Add team members' email addresses here. They will be able to log in with their Google account to view and manage license keys. Only you (mfrdotbiz@gmail.com) can add or remove members.
                </p>
                {user.email === 'mfrdotbiz@gmail.com' ? (
                  <form onSubmit={handleAddAdmin} className="flex gap-4 items-end max-w-md">
                    <div className="flex-1">
                      <label className="block text-xs font-semibold text-slate-500 mb-1">Google Email Address</label>
                      <input
                        type="email"
                        value={newAdminEmail}
                        onChange={(e) => setNewAdminEmail(e.target.value)}
                        placeholder="colleague@gmail.com"
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors outline-none text-slate-800 font-medium"
                        required
                      />
                    </div>
                    <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded text-sm shadow transition-colors whitespace-nowrap">
                      Add Admin
                    </button>
                  </form>
                ) : (
                  <div className="p-4 bg-amber-50 text-amber-800 rounded border border-amber-200 text-sm font-medium">
                    Only the primary owner can manage team members.
                  </div>
                )}
              </div>
              
              <div className="flex-1 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col min-h-0">
                <div className="p-4 border-b border-slate-100 bg-slate-50/50">
                  <h3 className="text-sm font-bold text-slate-700 uppercase tracking-tight">Active Team Members</h3>
                </div>
                <div className="flex-1 overflow-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-3 whitespace-nowrap">Email Address</th>
                        <th className="px-6 py-3 whitespace-nowrap">Role</th>
                        <th className="px-6 py-3 whitespace-nowrap text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr className="hover:bg-slate-50">
                        <td className="px-6 py-4 text-sm font-medium text-slate-800">mfrdotbiz@gmail.com</td>
                        <td className="px-6 py-4"><span className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded text-[10px] font-bold uppercase tracking-wider">Owner</span></td>
                        <td className="px-6 py-4 text-right"></td>
                      </tr>
                      {admins.map(admin => (
                        <tr key={admin.email} className="hover:bg-slate-50">
                          <td className="px-6 py-4 text-sm font-medium text-slate-700">{admin.email}</td>
                          <td className="px-6 py-4"><span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded text-[10px] font-bold uppercase tracking-wider">Admin</span></td>
                          <td className="px-6 py-4 text-right">
                            {user.email === 'mfrdotbiz@gmail.com' && (
                              <button onClick={() => handleRemoveAdmin(admin.email)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors" title="Remove Access">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : activeTab === 'html' ? (`;

code = code.replace(") : activeTab === 'html' ? (", teamUI);

fs.writeFileSync('src/components/Dashboard.tsx', code);
