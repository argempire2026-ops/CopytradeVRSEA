const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const oldStr = 'request.type_filling = GetFillingMode(_Symbol);\\n   OrderSend(request, result);';
const newStr = 'request.type_filling = GetFillingMode(_Symbol);\\n   if(!OrderSend(request, result)) { Print(\\"OrderSend error: \\", GetLastError()); }';

if (code.includes(oldStr)) {
    code = code.replace(oldStr, newStr);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Replaced OrderSend successfully!");
} else {
    console.log("Could not find OrderSend string.");
}
