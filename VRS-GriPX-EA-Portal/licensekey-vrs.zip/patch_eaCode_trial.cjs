const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const declOld = `bool g_is_expired = false;`;
const declNew = `bool g_is_expired = false;
bool g_is_trial = false;`;

code = code.replace(declOld, declNew);

const licenseCheckOld = `        if (StringFind(resultStr, "\\"stringValue\\":\\"active\\"") > 0) 
        {
            // Check for expiration date`;
const licenseCheckNew = `        if (StringFind(resultStr, "\\"stringValue\\":\\"active\\"") > 0) 
        {
            if (StringFind(resultStr, "\\"isTrial\\":{\\"booleanValue\\":true}") > 0 || StringFind(licenseKey, "TRIAL-") == 0) {
                g_is_trial = true;
            } else {
                g_is_trial = false;
            }
            
            // Check for expiration date`;

code = code.replace(licenseCheckOld, licenseCheckNew);

const uiUpdateOld = `   ObjectSetString(0, "VRS_UI_License_Lbl", OBJPROP_TEXT, "License Expiry: " + g_license_expiry);`;
const uiUpdateNew = `   string licenseText = "License Expiry: " + g_license_expiry;
   if (g_is_trial) licenseText = "TRIAL LICENSE - Expiry: " + g_license_expiry;
   ObjectSetString(0, "VRS_UI_License_Lbl", OBJPROP_TEXT, licenseText);
   if (g_is_trial) ObjectSetInteger(0, "VRS_UI_License_Lbl", OBJPROP_COLOR, cp_yellow);`;

code = code.replace(uiUpdateOld, uiUpdateNew);

fs.writeFileSync('src/eaCode.ts', code);
