const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add expiryPreset state
code = code.replace(
  "const [expiryDate, setExpiryDate] = useState('');",
  "const [expiryDate, setExpiryDate] = useState('');\n  const [expiryPreset, setExpiryPreset] = useState('lifetime');\n  const [renewExpiryPreset, setRenewExpiryPreset] = useState('custom');"
);

// 2. Add handlePresetChange and handleRenewPresetChange functions
const presetFuncs = `  const handlePresetChange = (preset: string) => {
    setExpiryPreset(preset);
    const d = new Date();
    if (preset === 'lifetime') {
      setExpiryDate('');
    } else if (preset === '1_month') {
      d.setMonth(d.getMonth() + 1); setExpiryDate(d.toISOString().slice(0,16));
    } else if (preset === '3_months') {
      d.setMonth(d.getMonth() + 3); setExpiryDate(d.toISOString().slice(0,16));
    } else if (preset === '6_months') {
      d.setMonth(d.getMonth() + 6); setExpiryDate(d.toISOString().slice(0,16));
    } else if (preset === '1_year') {
      d.setFullYear(d.getFullYear() + 1); setExpiryDate(d.toISOString().slice(0,16));
    }
  };

  const handleRenewPresetChange = (preset: string, currentExpiryStr: string | null) => {
    setRenewExpiryPreset(preset);
    // If renewing from an existing expiry, use that as base? 
    // Usually renewals are from *now*, or we just use *now* to be safe and simple.
    const d = new Date();
    if (preset === 'lifetime') {
      setRenewKey(prev => prev ? {...prev, expiry: ''} : null);
    } else if (preset === '1_month') {
      d.setMonth(d.getMonth() + 1); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    } else if (preset === '3_months') {
      d.setMonth(d.getMonth() + 3); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    } else if (preset === '6_months') {
      d.setMonth(d.getMonth() + 6); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    } else if (preset === '1_year') {
      d.setFullYear(d.getFullYear() + 1); setRenewKey(prev => prev ? {...prev, expiry: d.toISOString().slice(0,16)} : null);
    }
  };

  const handleCreate`;

code = code.replace("  const handleCreate", presetFuncs);


// 3. Update the UI for Generate Key
const generateUIOld = `              <div className="flex-1 w-full">
                <input
                  id="expiryDate"
                  type="datetime-local"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  title="Leave blank for Lifetime"
                  className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                />
              </div>`;

const generateUINew = `              <div className="flex-1 w-full flex gap-2">
                <select
                  value={expiryPreset}
                  onChange={(e) => handlePresetChange(e.target.value)}
                  className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white font-medium"
                >
                  <option value="lifetime">Lifetime</option>
                  <option value="1_month">1 Bulan</option>
                  <option value="3_months">3 Bulan</option>
                  <option value="6_months">6 Bulan</option>
                  <option value="1_year">1 Tahun</option>
                  <option value="custom">Custom Date</option>
                </select>
                {expiryPreset === 'custom' && (
                  <input
                    id="expiryDate"
                    type="datetime-local"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-xs focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                  />
                )}
              </div>`;

code = code.replace(generateUIOld, generateUINew);


// 4. Update the UI for Edit License
const editUIOld = `                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Expiry Date</label>
                  <input
                    type="datetime-local"
                    value={renewKey.expiry}
                    onChange={(e) => setRenewKey({...renewKey, expiry: e.target.value})}
                    className="w-full px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                  />
                </div>`;

const editUINew = `                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Expiry Date</label>
                  <div className="flex gap-2">
                    <select
                      value={renewExpiryPreset}
                      onChange={(e) => handleRenewPresetChange(e.target.value, renewKey.expiry)}
                      className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white font-medium"
                    >
                      <option value="custom">Custom Date</option>
                      <option value="lifetime">Lifetime</option>
                      <option value="1_month">1 Bulan (+ dari hari ini)</option>
                      <option value="3_months">3 Bulan (+ dari hari ini)</option>
                      <option value="6_months">6 Bulan (+ dari hari ini)</option>
                      <option value="1_year">1 Tahun (+ dari hari ini)</option>
                    </select>
                    <input
                      type="datetime-local"
                      value={renewKey.expiry}
                      onChange={(e) => {
                        setRenewExpiryPreset('custom');
                        setRenewKey({...renewKey, expiry: e.target.value});
                      }}
                      className="w-1/2 px-3 py-2 bg-[#050914] border border-slate-800 rounded text-sm focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] transition-colors outline-none text-white placeholder:text-slate-500 font-medium [color-scheme:dark]"
                    />
                  </div>
                </div>`;

code = code.replace(editUIOld, editUINew);


// Need to reset preset on successful create
const resetCreateOld = `      setCustomerEmail('');
      setCustomerName('');
      setAllowedAccounts('');
      setExpiryDate('');`;

const resetCreateNew = `      setCustomerEmail('');
      setCustomerName('');
      setAllowedAccounts('');
      setExpiryDate('');
      setExpiryPreset('lifetime');`;

code = code.replace(resetCreateOld, resetCreateNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
