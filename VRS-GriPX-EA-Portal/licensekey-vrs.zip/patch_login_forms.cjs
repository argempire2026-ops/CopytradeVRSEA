const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf8');

const targetIndex = code.indexOf('          <div className="w-full">');

if (targetIndex !== -1) {
    const endStr = '      </div>\n    );\n  }';
    const endIndex = code.indexOf(endStr, targetIndex);
    
    if (endIndex !== -1) {
        const fullEndIndex = endIndex + endStr.length;
        const oldSection = code.substring(targetIndex, fullEndIndex);
        
        const newSection = `          <div className="w-full">
            {showPasswordPrompt ? (
              <motion.form 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onSubmit={handlePasswordSubmit} 
                className="space-y-4"
              >
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">{t.adminAccess}</h2>
                <div>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    autoFocus
                  />
                </div>
                <button type="submit" className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  Submit
                </button>
                <button type="button" onClick={() => setShowPasswordPrompt(false)} className="w-full mt-2 py-2 text-sm text-slate-400 hover:text-white transition-colors">Cancel</button>
              </motion.form>
            ) : showClientRegister ? (
              <motion.form 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onSubmit={handleClientRegister} 
                className="space-y-4"
              >
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">{t.clientRegister}</h2>
                {clientRegError && <p className="text-pink-500 text-sm font-medium text-center">{clientRegError}</p>}
                <div>
                  <input
                    type="text"
                    value={regClientName}
                    onChange={(e) => setRegClientName(e.target.value)}
                    placeholder="Nama Penuh"
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <div>
                  <input
                    type="email"
                    value={regClientEmail}
                    onChange={(e) => setRegClientEmail(e.target.value)}
                    placeholder="Your Email"
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={regClientPassword}
                    onChange={(e) => setRegClientPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <button type="submit" className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  Register Account
                </button>
                <div className="flex justify-between mt-4">
                  <button type="button" onClick={() => {setShowClientRegister(false); setShowClientLogin(true);}} className="py-2 text-sm text-[#00FFC8] hover:text-white transition-colors">Already have an account?</button>
                  <button type="button" onClick={() => setShowClientRegister(false)} className="py-2 text-sm text-slate-400 hover:text-white transition-colors">{t.backBtn}</button>
                </div>
              </motion.form>
            ) : showClientLogin ? (
              <motion.form 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onSubmit={handleClientLogin} 
                className="space-y-4"
              >
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">{t.clientLogin}</h2>
                {clientLoginError && <p className="text-pink-500 text-sm font-medium text-center">{clientLoginError}</p>}
                <div>
                  <input
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder={t.registeredEmailPlaceholder}
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={clientPassword}
                    onChange={(e) => setClientPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full p-3.5 bg-black/40 border border-slate-700/50 rounded-lg focus:ring-2 focus:ring-[#00FFC8]/50 focus:border-[#00FFC8] outline-none text-white placeholder:text-slate-500 transition-all shadow-inner"
                    required
                  />
                </div>
                <button type="submit" className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                  {t.loginBtn}
                </button>
                <div className="flex justify-between mt-4">
                  <button type="button" onClick={() => {setShowClientLogin(false); setShowClientRegister(true);}} className="py-2 text-sm text-[#00FFC8] hover:text-white transition-colors">{t.registerNewAccount}</button>
                  <button type="button" onClick={() => setShowClientLogin(false)} className="py-2 text-sm text-slate-400 hover:text-white transition-colors">{t.backBtn}</button>
                </div>
              </motion.form>
            ) : (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="text-center space-y-6 py-4"
              >
                 <p className="text-slate-300 text-sm leading-relaxed mb-6">
                   {t.welcomeMsg.split('\\n').map((line, i) => <React.Fragment key={i}>{line}<br/></React.Fragment>)}
                 </p>
                 <div className="flex flex-col gap-4">
                   <button 
                     onClick={() => setShowClientLogin(true)} 
                     className="group relative w-full py-3.5 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#FFD700] text-slate-900 font-bold rounded-lg shadow-[0_4px_14px_0_rgba(212,175,55,0.4)] hover:shadow-[0_6px_20px_0_rgba(212,175,55,0.6)] transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden"
                   >
                     <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out"></div>
                     <Lock size={18} className="text-slate-800" />
                     {t.clientLogin}
                   </button>
                   <button 
                     onClick={() => setShowClientRegister(true)} 
                     className="w-full py-3.5 px-4 bg-slate-800/80 backdrop-blur-sm border border-slate-700/50 text-slate-300 font-bold rounded-lg shadow-lg transition-all hover:bg-slate-700 hover:text-white hover:border-slate-500 hover:shadow-[0_4px_14px_0_rgba(255,255,255,0.05)] flex items-center justify-center gap-2"
                   >
                     <UserPlus size={18} />
                     {t.registerNewAccount}
                   </button>
                 </div>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    );
  }`;

        code = code.replace(oldSection, newSection);
        fs.writeFileSync('src/components/Dashboard.tsx', code);
        console.log("Forms block updated successfully.");
    } else {
        console.log("Could not find endIndex.");
    }
} else {
    console.log("Could not find targetIndex.");
}
