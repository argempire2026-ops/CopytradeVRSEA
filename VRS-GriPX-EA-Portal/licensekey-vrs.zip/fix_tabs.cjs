const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "const [activeTab, setActiveTab] = useState<'keys' | 'ea' | 'html' | 'team' | 'clients'>('keys');",
  "const [activeTab, setActiveTab] = useState<'keys' | 'ea' | 'html' | 'team' | 'clients' | 'settings'>('keys');"
);

const tabClientHtml = `          <div 
            onClick={() => setActiveTab('clients')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'clients' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <Users className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-medium">Urus Pelanggan</span>
          </div>`;

const tabSettingsHtml = `          <div 
            onClick={() => setActiveTab('settings')}
            className={\`flex items-center gap-2 md:gap-3 px-3 py-2 rounded shadow-sm cursor-pointer transition-colors whitespace-nowrap shrink-0 \${activeTab === 'settings' ? 'bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-slate-900 shadow-md' : 'hover:bg-slate-800 text-slate-400'}\`}
          >
            <span className="text-xs md:text-sm font-medium">Tetapan</span>
          </div>`;

code = code.replace(tabClientHtml, tabClientHtml + "\n" + tabSettingsHtml);

const saveSettingsFunction = `  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsLoading(true);
    try {
      await setDoc(doc(db, 'settings', 'general'), {
        historyDays,
        eaDownloadLink,
        eaDescription,
        whatsappLink,
        tutorialLink
      }, { merge: true });
      alert('Tetapan berjaya disimpan!');
    } catch (err: any) {
      alert('Gagal simpan tetapan: ' + err.message);
    }
    setSettingsLoading(false);
  };
`;

code = code.replace("  const handleCopyCode = async () => {", saveSettingsFunction + "\n  const handleCopyCode = async () => {");

const settingsUI = `          {activeTab === 'settings' && (
            <div className="bg-[#131E3A] border border-slate-800 rounded-xl p-6 shadow-lg max-w-2xl">
              <h2 className="text-xl font-bold text-slate-200 mb-6">Tetapan Sistem</h2>
              <form onSubmit={handleSaveSettings} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Sejarah (Hari)</label>
                  <input
                    type="number"
                    value={historyDays}
                    onChange={(e) => setHistoryDays(Number(e.target.value))}
                    className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                    placeholder="Contoh: 30"
                  />
                  <p className="text-xs text-slate-500 mt-1">Tempoh hari sebelum sejarah lesen klien dipadam secara automatik.</p>
                </div>
                
                <div className="pt-4 border-t border-slate-800">
                  <h3 className="text-lg font-bold text-slate-200 mb-4">Kemaskini EA (Client Portal)</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Muat Turun EA</label>
                      <input
                        type="url"
                        value={eaDownloadLink}
                        onChange={(e) => setEaDownloadLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://drive.google.com/file/d/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Keterangan / Changelog EA</label>
                      <textarea
                        value={eaDescription}
                        onChange={(e) => setEaDescription(e.target.value)}
                        rows={4}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Masukkan keterangan versi atau panduan ringkas..."
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <h3 className="text-lg font-bold text-slate-200 mb-4">Pautan Luaran</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Group WhatsApp</label>
                      <input
                        type="url"
                        value={whatsappLink}
                        onChange={(e) => setWhatsappLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://chat.whatsapp.com/..."
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Pautan Panduan Tutorial</label>
                      <input
                        type="url"
                        value={tutorialLink}
                        onChange={(e) => setTutorialLink(e.target.value)}
                        className="w-full bg-[#050914] text-white rounded p-3 border border-slate-800 focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] outline-none"
                        placeholder="Contoh: https://youtube.com/..."
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="submit"
                    disabled={settingsLoading}
                    className="px-6 py-2 bg-[#D4AF37] hover:bg-[#F1C40F] text-slate-900 font-bold rounded shadow-lg transition-all disabled:opacity-50"
                  >
                    {settingsLoading ? 'Menyimpan...' : 'Simpan Tetapan'}
                  </button>
                </div>
              </form>
            </div>
          )}`;

code = code.replace(
  "{activeTab === 'clients' && (",
  settingsUI + "\n          {activeTab === 'clients' && ("
);

code = code.replace(
  "activeTab === 'html' ? 'Web HTML Source' : 'Team Access'",
  "activeTab === 'html' ? 'Web HTML Source' : activeTab === 'settings' ? 'Tetapan Sistem' : activeTab === 'clients' ? 'Urus Pelanggan' : 'Team Access'"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
