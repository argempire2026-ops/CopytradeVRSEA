const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Remove the lang state
code = code.replace(/const \[lang, setLang\] = useState<'en' \| 'ms'>\('en'\);\n/g, '');

// 2. Fix the t object structure.
const tMatch = code.match(/const t = {\s*en: ({[\s\S]*?}),\s*ms: {/);
if (tMatch) {
  const enObjString = tMatch[1];
  const tBlockMatch = code.match(/const t = {[\s\S]*?\n};\n/);
  if (tBlockMatch) {
    code = code.replace(tBlockMatch[0], `const t = ${enObjString};\n`);
  }
}

// 3. Replace all `t[lang].` with `t.`
code = code.replace(/t\[lang\]\./g, 't.');

// 4. Remove all the language toggler UI elements
code = code.replace(/<div className="flex bg-\[#050914\] p-1 rounded-lg">[\s\S]*?<\/div>\n/g, '');
code = code.replace(/<div className="flex bg-\[#050914\] p-1 rounded-lg mb-6 self-center">[\s\S]*?<\/div>\n/g, '');

fs.writeFileSync('src/components/Dashboard.tsx', code);
