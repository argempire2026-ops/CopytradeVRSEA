const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "keys.map((k) => (",
  "keys.filter(k => k.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) || (k.customerName && k.customerName.toLowerCase().includes(searchTerm.toLowerCase())) || k.key.toLowerCase().includes(searchTerm.toLowerCase())).map((k) => ("
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
