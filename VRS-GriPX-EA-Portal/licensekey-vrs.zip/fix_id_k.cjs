const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${k.id}\`);",
  "handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${id}\`);"
);

code = code.replace(
  "handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${id}\`);\n    }\n  };\n\n  const handleToggleStatus = async (k: any) => {\n    try {\n      const newStatus = k.status === 'active' ? 'revoked' : 'active';\n      await updateDoc(doc(db, 'licenseKeys', k.id), { status: newStatus });\n      await logHistory(k.customerEmail, k.key, newStatus === 'active' ? 'Diaktifkan Semula' : 'Dibatalkan', newStatus === 'active' ? 'Lesen telah diaktifkan semula.' : 'Lesen dibatalkan oleh Admin.');\n    } catch (error) {\n      handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${id}\`);",
  "handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${id}\`);\n    }\n  };\n\n  const handleToggleStatus = async (k: any) => {\n    try {\n      const newStatus = k.status === 'active' ? 'revoked' : 'active';\n      await updateDoc(doc(db, 'licenseKeys', k.id), { status: newStatus });\n      await logHistory(k.customerEmail, k.key, newStatus === 'active' ? 'Diaktifkan Semula' : 'Dibatalkan', newStatus === 'active' ? 'Lesen telah diaktifkan semula.' : 'Lesen dibatalkan oleh Admin.');\n    } catch (error) {\n      handleFirestoreError(error, OperationType.UPDATE, \`licenseKeys/\${k.id}\`);"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
