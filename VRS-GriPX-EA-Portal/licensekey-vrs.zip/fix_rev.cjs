const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const s1 = 'Alert(\\"License anda telah DIBATALKAN (Revoked)!\\");\\n            return false;';
const r1 = 'Alert(\\"License anda telah DIBATALKAN (Revoked)!\\");\\n            ExpertRemove();\\n            return false;';

if(code.includes(s1)) {
    code = code.replace(s1, r1);
    fs.writeFileSync('src/eaCode.ts', code);
    console.log("Replaced!");
} else {
    console.log("Not found.");
}
