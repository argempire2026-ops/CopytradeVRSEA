const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  'void OnTick()\n{\n   if(!m_symbol.RefreshRates()) return;\n   \n   // --- LICENSE EXPIRATION REAL-TIME CHECK ---',
  `void OnTick()\n{\n   if(!m_symbol.RefreshRates()) return;\n   \n   // --- PERIODIC FIREBASE LICENSE CHECK (Every 60 seconds) ---\n   static datetime last_firebase_check = 0;\n   if(TimeCurrent() - last_firebase_check >= 60) {\n       last_firebase_check = TimeCurrent();\n       ValidateLicenseFirebase(USER_LICENSE_KEY, true);\n   }\n   \n   // --- LICENSE EXPIRATION REAL-TIME CHECK ---`
);

fs.writeFileSync('public/ea-code.txt', code);
