const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(/alert\('Pendaftaran berjaya! Sila log masuk\.'\);/g, "alert('Registration successful! Please login.');");
code = code.replace(/setClientRegError\('Gagal mendaftar: ' \+ err\.message\);/g, "setClientRegError('Failed to register: ' + err.message);");
code = code.replace(/alert\('Akaun pelanggan berjaya dicipta!'\);/g, "alert('Client account created successfully!');");
code = code.replace(/alert\('Gagal mencipta akaun: ' \+ err\.message\);/g, "alert('Failed to create account: ' + err.message);");
code = code.replace(/'Dipadam', 'Lesen telah dipadam oleh Admin\.'/g, "'Deleted', 'License deleted by Admin.'");
code = code.replace(/alert\('Gagal padam: ' \+ error\.message\);/g, "alert('Failed to delete: ' + error.message);");
code = code.replace(/error: 'Gagal menjana trial\. ' \+ error\.message/g, "error: 'Failed to generate trial. ' + error.message");
code = code.replace(/\/\/ Sila run "npm run build && cp dist\/index\.html public\/dashboard-export\.html" untuk lihat kod HTML ini\.\\n\/\/ Gagal memuat HTML source code\./g, "// Please run \\\"npm run build && cp dist/index.html public/dashboard-export.html\\\" to view this HTML code.\\n// Failed to load HTML source code.");
code = code.replace(/alert\('Tetapan berjaya disimpan!'\);/g, "alert('Settings saved successfully!');");
code = code.replace(/alert\('Gagal simpan tetapan: ' \+ err\.message\);/g, "alert('Failed to save settings: ' + err.message);");
code = code.replace(/'Diaktifkan Semula' : 'Dibatalkan', newStatus === 'active' \? 'Lesen telah diaktifkan semula\.' : 'Lesen dibatalkan oleh Admin\.'/g, "'Reactivated' : 'Revoked', newStatus === 'active' ? 'License reactivated.' : 'License revoked by Admin.'");
code = code.replace(/>\s*Log Keluar\s*</g, ">Logout<");
code = code.replace(/alert\('Key disalin!'\);/g, "alert('Key copied!');");
code = code.replace(/>\s*Salin Key\s*</g, ">Copy Key<");
code = code.replace(/>Daftarkan pelanggan baru di sini untuk memberikan mereka akses ke portal pelanggan\. Mereka boleh log masuk menggunakan e-mel dan kata laluan ini\.</g, ">Register new clients here to give them access to the client portal. They can login using this email and password.<");
code = code.replace(/title="Padam Akaun"/g, 'title="Delete Account"');
code = code.replace(/>Pengesahan Padam</g, ">Confirm Delete<");
code = code.replace(/>Adakah anda pasti untuk padam \{deleteConfirm\.type === 'client' \? 'akaun pelanggan' : 'lesen'\} ini\? Sila masukkan kata laluan admin untuk sahkan\.</g, ">\n                Are you sure you want to delete this {deleteConfirm.type === 'client' ? 'client account' : 'license'}? Please enter the admin password to confirm.\n              <");
code = code.replace(/>\s*Batal\s*</g, ">Cancel<");
code = code.replace(/>\s*Sah & Padam\s*</g, ">Confirm & Delete<");
code = code.replace(/>Tetapan</g, ">Settings<");

fs.writeFileSync('src/components/Dashboard.tsx', code);
