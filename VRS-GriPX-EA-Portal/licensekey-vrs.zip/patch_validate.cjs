const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  'bool ValidateLicenseFirebase(string licenseKey)',
  'bool ValidateLicenseFirebase(string licenseKey, bool silent = false)'
);

code = code.replace(
  /Alert\("License anda telah TAMAT TEMPOH pada " \+ displayDate \+ "! EA akan close semua entry dan berhenti beroperasi\."\);/g,
  `if (!silent) Alert("License anda telah TAMAT TEMPOH pada " + displayDate + "! EA akan close semua entry dan berhenti beroperasi.");`
);

code = code.replace(
  /Print\("🔥 \\[FIREBASE\\] License SAH dan AKTIF!"\);/g,
  `if (!silent) Print("🔥 [FIREBASE] License SAH dan AKTIF!");`
);

code = code.replace(
  /Alert\("License anda telah DIBATALKAN \\(Revoked\\)!"\);/g,
  `if (!silent) Alert("License anda telah DIBATALKAN (Revoked)!");`
);

code = code.replace(
  /Alert\("License anda telah TAMAT TEMPOH \\(Expired\\)!"\);/g,
  `if (!silent) Alert("License anda telah TAMAT TEMPOH (Expired)!");`
);

code = code.replace(
  /Alert\("Status license tidak diketahui. Sila hubungi admin."\);/g,
  `if (!silent) Alert("Status license tidak diketahui. Sila hubungi admin.");`
);

fs.writeFileSync('public/ea-code.txt', code);
