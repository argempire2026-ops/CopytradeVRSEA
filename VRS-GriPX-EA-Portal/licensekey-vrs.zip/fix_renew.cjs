const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add state for renewLink
const stateOld = "  const [tutorialLink, setTutorialLink] = useState('');";
const stateNew = "  const [tutorialLink, setTutorialLink] = useState('');\n  const [renewLink, setRenewLink] = useState('');";
code = code.replace(stateOld, stateNew);

// 2. Fetch renewLink
const fetchOld = "        if (data.tutorialLink) setTutorialLink(data.tutorialLink);";
const fetchNew = "        if (data.tutorialLink) setTutorialLink(data.tutorialLink);\n        if (data.renewLink) setRenewLink(data.renewLink);";
code = code.replace(fetchOld, fetchNew);

// 3. Save renewLink
const saveOld = "        tutorialLink\\n      }, { merge: true });";
const saveNew = "        tutorialLink,\n        renewLink\n      }, { merge: true });";
code = code.replace(saveOld, saveNew);

// 4. Update the Client UI to remove the claim count text and replace it with restricted logic
const clientUIRegex = /<div className="bg-\[#131E3A\] p-6 rounded-xl shadow-lg border border-slate-800 mb-8">[\s\S]*?(?=<\/div>\s*<\/div>\s*<\/div>\s*<\/main>)/;

// Wait, the client UI is quite specific. Let's do a more targeted replace.
