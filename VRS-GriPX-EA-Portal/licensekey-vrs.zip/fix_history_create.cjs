const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "await logHistory(customerEmail.trim(), generatedKey, 'Dicipta', 'Lesen baru telah dijana.');",
  "// No history log for create"
);
code = code.replace(
  "await logHistory(clientUser.email, generatedKey, 'Trial', 'Berjaya tuntut Free Trial 1 Hari.');",
  "// No history log for trial"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
