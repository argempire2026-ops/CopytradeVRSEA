const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace("Sejarah & Status Lesen (30 Hari)", "Sejarah & Status Lesen ({historyDays} Hari)");
code = code.replace("Tiada rekod sejarah dalam masa 30 hari.", "Tiada rekod sejarah dalam masa {historyDays} hari.");

fs.writeFileSync('src/components/Dashboard.tsx', code);
