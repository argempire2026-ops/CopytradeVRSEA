const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

code = code.replace(
  "fetch('/dashboard-export.html?v=' + new Date().getTime()).getTime())",
  "fetch('/dashboard-export.html?v=' + new Date().getTime())"
);

fs.writeFileSync('src/components/Dashboard.tsx', code);
