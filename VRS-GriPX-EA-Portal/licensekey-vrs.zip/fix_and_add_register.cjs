const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add states
const stateInjection = `  const [newClientName, setNewClientName] = useState('');
  const [showClientRegister, setShowClientRegister] = useState(false);
  const [regClientEmail, setRegClientEmail] = useState('');
  const [regClientName, setRegClientName] = useState('');
  const [regClientPassword, setRegClientPassword] = useState('');
  const [clientRegError, setClientRegError] = useState('');`;

code = code.replace("  const [newClientName, setNewClientName] = useState('');", stateInjection);


// 2. Add handleClientRegister right before handleCreateClient
const registerHandler = `  const handleClientRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setClientRegError('');
    if (!regClientEmail.trim() || !regClientName.trim() || !regClientPassword.trim()) return;
    try {
      const emailKey = regClientEmail.toLowerCase().trim();
      const clientRef = doc(db, 'clients', emailKey);
      
      const q = query(collection(db, 'clients'), where('email', '==', emailKey));
      const snap = await getDocs(q);
      
      if (!snap.empty) {
        setClientRegError('E-mel ini telah didaftarkan.');
        return;
      }
      
      await setDoc(clientRef, {
        email: emailKey,
        name: regClientName.trim(),
        password: regClientPassword,
        createdAt: serverTimestamp()
      });
      
      alert('Pendaftaran berjaya! Sila log masuk.');
      setShowClientRegister(false);
      setRegClientEmail('');
      setRegClientName('');
      setRegClientPassword('');
      setShowClientLogin(true);
    } catch (err: any) {
      setClientRegError('Gagal mendaftar: ' + err.message);
    }
  };

  const handleCreateClient`;
code = code.replace("  const handleCreateClient", registerHandler);

// 3. Fix the broken table from previous replace
const brokenTablePart = `                    ) : showClientLogin ? (
              <form onSubmit={handleClientLogin} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Client Login</h2>
                {clientLoginError && <p className="text-red-500 text-sm font-medium text-center">{clientLoginError}</p>}
                <div>
                  <input
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder="E-mel Mendaftar"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={clientPassword}
                    onChange={(e) => setClientPassword(e.target.value)}
                    placeholder="Kata Laluan"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                  Log Masuk
                </button>
                <button type="button" onClick={() => setShowClientLogin(false)} className="w-full mt-2 py-2 text-sm text-slate-400 hover:text-slate-200">Kembali</button>
              </form>
            ) : (
                      clientKeys.map`;

code = code.replace(brokenTablePart, `                    ) : (
                      clientKeys.map`);

// 4. Update the bottom of the public page to include both forms
// Current structure:
/*
            ) : (
              <form onSubmit={handleClaimTrial} className="space-y-4">
              ...
              </form>
            )}
            </>
            )}
            
            {!showPasswordPrompt && !showClientLogin && (
              <div className="mt-8 text-center border-t border-slate-800 pt-6">
                <p className="text-sm text-slate-400 mb-3">Pelanggan berdaftar?</p>
                <button 
                  onClick={() => setShowClientLogin(true)}
                  className="px-6 py-2 bg-slate-800 text-slate-300 rounded hover:bg-slate-700 transition-colors text-sm font-medium"
                >
                  Log Masuk Pelanggan
                </button>
              </div>
            )}
          </div>
*/

// I need to replace the `showPasswordPrompt ? ... : ( <form onSubmit={handleClaimTrial}> ... )}` structure to handle showClientRegister and showClientLogin.

const oldPublicForms = `            {showPasswordPrompt ? (
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Admin Access</h2>
                <div>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    autoFocus
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                  Submit
                </button>
                <button type="button" onClick={() => setShowPasswordPrompt(false)} className="w-full mt-2 py-2 text-sm text-slate-400 hover:text-slate-200">Cancel</button>
              </form>
            ) : (
              <>
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Claim Trial 1 Hari</h2>
                
                {trialResult ? (
              <div className="mb-6 p-4 rounded-lg border bg-[#050914] text-center">
                {trialResult.error ? (
                  <>
                    <p className="text-red-500 font-medium mb-4">{trialResult.error}</p>
                    <button onClick={() => setTrialResult(null)} className="text-[#D4AF37] text-sm hover:underline">Kembali</button>
                  </>
                ) : (
                  <>
                    <p className="text-sm text-slate-400 mb-2">
                      {trialResult.existing ? 'Lesen Trial anda masih aktif:' : 'Sila salin License Key anda (Sah 24 Jam):'}
                    </p>
                    <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                      {trialResult.key}
                    </div>
                    {trialResult.expiresAt && (
                      <p className="text-xs text-rose-400 mb-4">
                        Tamat Tempoh: {format(new Date(trialResult.expiresAt), 'dd MMM yyyy, HH:mm')}
                      </p>
                    )}
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(trialResult.key);
                        alert('Key disalin!');
                      }}
                      className="text-[#D4AF37] text-sm font-medium hover:text-[#F1C40F]"
                    >
                      Salin Key
                    </button>
                  </>
                )}
              </div>
            ) : (
              <form onSubmit={handleClaimTrial} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-1">Nama Penuh Berdaftar Dengan Broker</label>
                  <input
                    type="text"
                    value={trialMt5}
                    onChange={(e) => setTrialMt5(e.target.value)}
                    placeholder="Contoh: MUHAMAD FAAIZ..."
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <button 
                  type="submit"
                  disabled={trialLoading || !trialMt5.trim()}
                  className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors disabled:opacity-50"
                >
                  {trialLoading ? 'Memproses...' : 'Generate Trial Key'}
                </button>
              </form>
            )}
            </>
            )}
            
            {!showPasswordPrompt && !showClientLogin && (
              <div className="mt-8 text-center border-t border-slate-800 pt-6">
                <p className="text-sm text-slate-400 mb-3">Pelanggan berdaftar?</p>
                <button 
                  onClick={() => setShowClientLogin(true)}
                  className="px-6 py-2 bg-slate-800 text-slate-300 rounded hover:bg-slate-700 transition-colors text-sm font-medium"
                >
                  Log Masuk Pelanggan
                </button>
              </div>
            )}`;

const newPublicForms = `            {showPasswordPrompt ? (
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Admin Access</h2>
                <div>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    autoFocus
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                  Submit
                </button>
                <button type="button" onClick={() => setShowPasswordPrompt(false)} className="w-full mt-2 py-2 text-sm text-slate-400 hover:text-slate-200">Cancel</button>
              </form>
            ) : showClientRegister ? (
              <form onSubmit={handleClientRegister} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Pendaftaran Pelanggan</h2>
                {clientRegError && <p className="text-red-500 text-sm font-medium text-center">{clientRegError}</p>}
                <div>
                  <input
                    type="text"
                    value={regClientName}
                    onChange={(e) => setRegClientName(e.target.value)}
                    placeholder="Nama Penuh"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <div>
                  <input
                    type="email"
                    value={regClientEmail}
                    onChange={(e) => setRegClientEmail(e.target.value)}
                    placeholder="E-mel Anda"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={regClientPassword}
                    onChange={(e) => setRegClientPassword(e.target.value)}
                    placeholder="Kata Laluan"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                  Daftar Akaun
                </button>
                <div className="flex justify-between mt-2">
                  <button type="button" onClick={() => {setShowClientRegister(false); setShowClientLogin(true);}} className="py-2 text-sm text-[#D4AF37] hover:text-[#F1C40F]">Sudah ada akaun?</button>
                  <button type="button" onClick={() => setShowClientRegister(false)} className="py-2 text-sm text-slate-400 hover:text-slate-200">Kembali</button>
                </div>
              </form>
            ) : showClientLogin ? (
              <form onSubmit={handleClientLogin} className="space-y-4">
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Log Masuk Pelanggan</h2>
                {clientLoginError && <p className="text-red-500 text-sm font-medium text-center">{clientLoginError}</p>}
                <div>
                  <input
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder="E-mel Mendaftar"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <div>
                  <input
                    type="password"
                    value={clientPassword}
                    onChange={(e) => setClientPassword(e.target.value)}
                    placeholder="Kata Laluan"
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <button type="submit" className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors">
                  Log Masuk
                </button>
                <div className="flex justify-between mt-2">
                  <button type="button" onClick={() => {setShowClientLogin(false); setShowClientRegister(true);}} className="py-2 text-sm text-[#D4AF37] hover:text-[#F1C40F]">Daftar Akaun Baru</button>
                  <button type="button" onClick={() => setShowClientLogin(false)} className="py-2 text-sm text-slate-400 hover:text-slate-200">Kembali</button>
                </div>
              </form>
            ) : (
              <>
                <h2 className="text-lg font-semibold text-slate-200 mb-4 text-center">Claim Trial 1 Hari</h2>
                
                {trialResult ? (
              <div className="mb-6 p-4 rounded-lg border bg-[#050914] text-center">
                {trialResult.error ? (
                  <>
                    <p className="text-red-500 font-medium mb-4">{trialResult.error}</p>
                    <button onClick={() => setTrialResult(null)} className="text-[#D4AF37] text-sm hover:underline">Kembali</button>
                  </>
                ) : (
                  <>
                    <p className="text-sm text-slate-400 mb-2">
                      {trialResult.existing ? 'Lesen Trial anda masih aktif:' : 'Sila salin License Key anda (Sah 24 Jam):'}
                    </p>
                    <div className="bg-[#131E3A] border border-[#D4AF37]/50 p-3 rounded font-mono text-[#F1C40F] text-lg font-bold mb-3 break-all">
                      {trialResult.key}
                    </div>
                    {trialResult.expiresAt && (
                      <p className="text-xs text-rose-400 mb-4">
                        Tamat Tempoh: {format(new Date(trialResult.expiresAt), 'dd MMM yyyy, HH:mm')}
                      </p>
                    )}
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(trialResult.key);
                        alert('Key disalin!');
                      }}
                      className="text-[#D4AF37] text-sm font-medium hover:text-[#F1C40F]"
                    >
                      Salin Key
                    </button>
                  </>
                )}
              </div>
            ) : (
              <form onSubmit={handleClaimTrial} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-1">Nama Penuh Berdaftar Dengan Broker</label>
                  <input
                    type="text"
                    value={trialMt5}
                    onChange={(e) => setTrialMt5(e.target.value)}
                    placeholder="Contoh: MUHAMAD FAAIZ..."
                    className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"
                    required
                  />
                </div>
                <button 
                  type="submit"
                  disabled={trialLoading || !trialMt5.trim()}
                  className="w-full py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] hover:from-[#F1C40F] hover:to-[#F1C40F] text-slate-900 font-bold rounded shadow transition-colors disabled:opacity-50"
                >
                  {trialLoading ? 'Memproses...' : 'Generate Trial Key'}
                </button>
              </form>
            )}
            </>
            )}
            
            {!showPasswordPrompt && !showClientLogin && !showClientRegister && (
              <div className="mt-8 text-center border-t border-slate-800 pt-6">
                <p className="text-sm text-slate-400 mb-3">Pelanggan berdaftar?</p>
                <button 
                  onClick={() => setShowClientLogin(true)}
                  className="px-6 py-2 bg-slate-800 text-slate-300 rounded hover:bg-slate-700 transition-colors text-sm font-medium"
                >
                  Portal Pelanggan
                </button>
              </div>
            )}`;

code = code.replace(oldPublicForms, newPublicForms);

fs.writeFileSync('src/components/Dashboard.tsx', code);
