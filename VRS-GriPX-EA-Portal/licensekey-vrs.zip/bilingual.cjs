const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const dictionary = `
const t = {
  en: {
    clientPortal: 'Client Portal Login',
    registeredEmail: 'Registered Email',
    password: 'Password',
    login: 'Login',
    welcome: 'Welcome',
    logout: 'Logout',
    downloadEA: 'Download EA',
    joinWhatsapp: 'Join WhatsApp Group',
    tutorialGuide: 'Tutorial Guide',
    activeLicense: 'Your Active License',
    historyStatus: 'License History & Status',
    claimTrial: 'Claim 3-Day Free Trial',
    copyKeyValid: 'Please copy your License Key (Valid for 3 Days):',
    expires: 'Expires:',
    copyKey: 'Copy Key',
    close: 'Close',
    mt5Name: 'MT5 Name (Registered with Broker)',
    claimNow: 'Claim Now',
    linkNotSetWarning: 'Link not updated by Admin.',
    adminSettings: 'System Settings',
    manageClients: 'Manage Clients',
    teamAccess: 'Team Access',
    eaSource: 'EA Code Source',
    htmlSource: 'Web HTML Source',
    overview: 'Overview',
    historyDays: 'History (Days)',
    historyDaysDesc: 'Number of days before client license history is automatically deleted.',
    deleteAllNow: 'Delete All Now',
    eaUpdate: 'EA Update (Client Portal)',
    eaDownloadLink: 'EA Download Link',
    eaDesc: 'EA Description / Changelog',
    extLinks: 'External Links',
    whatsappLink: 'WhatsApp Group Link',
    tutorialLink: 'Tutorial Guide Link',
    saveSettings: 'Save Settings',
    saving: 'Saving...',
    areYouSure: 'Are you sure?',
    deleteAllWarning: 'This action will delete ALL License History & Status records for ALL clients. This action cannot be undone.',
    cancel: 'Cancel',
    confirmDeleteAll: 'Agree to Delete All History',
    deleting: 'Deleting...',
    clientsList: 'Clients List',
    clientEmail: 'Client Email',
    totalLicenses: 'Total Licenses',
    actions: 'Actions'
  },
  ms: {
    clientPortal: 'Log Masuk Portal Pelanggan',
    registeredEmail: 'Emel Berdaftar',
    password: 'Kata Laluan',
    login: 'Log Masuk',
    welcome: 'Selamat Datang',
    logout: 'Log Keluar',
    downloadEA: 'Muat Turun EA',
    joinWhatsapp: 'Sertai Group WhatsApp',
    tutorialGuide: 'Panduan Tutorial',
    activeLicense: 'Lesen Aktif Anda',
    historyStatus: 'Sejarah & Status Lesen',
    claimTrial: 'Tuntut Free Trial 3 Hari',
    copyKeyValid: 'Sila salin License Key anda (Sah 3 Hari):',
    expires: 'Tamat Tempoh:',
    copyKey: 'Salin Key',
    close: 'Tutup',
    mt5Name: 'Nama MT5 (Berdaftar Dengan Broker)',
    claimNow: 'Tuntut Sekarang',
    linkNotSetWarning: 'Pautan belum dikemaskini oleh Admin.',
    adminSettings: 'Tetapan Sistem',
    manageClients: 'Urus Pelanggan',
    teamAccess: 'Team Access',
    eaSource: 'EA Code Source',
    htmlSource: 'Web HTML Source',
    overview: 'Overview',
    historyDays: 'Sejarah (Hari)',
    historyDaysDesc: 'Tempoh hari sebelum sejarah lesen klien dipadam secara automatik.',
    deleteAllNow: 'Padam Semua Sekarang',
    eaUpdate: 'Kemaskini EA (Client Portal)',
    eaDownloadLink: 'Pautan Muat Turun EA',
    eaDesc: 'Keterangan / Changelog EA',
    extLinks: 'Pautan Luaran',
    whatsappLink: 'Pautan Group WhatsApp',
    tutorialLink: 'Pautan Panduan Tutorial',
    saveSettings: 'Simpan Tetapan',
    saving: 'Menyimpan...',
    areYouSure: 'Adakah anda pasti?',
    deleteAllWarning: 'Tindakan ini akan memadam KESEMUA rekod Sejarah & Status Lesen untuk SEMUA pelanggan. Tindakan ini tidak boleh dipulihkan.',
    cancel: 'Batal',
    confirmDeleteAll: 'Setuju Padam Semua Sejarah',
    deleting: 'Memadam...',
    clientsList: 'Senarai Pelanggan',
    clientEmail: 'Emel Pelanggan',
    totalLicenses: 'Jumlah Lesen',
    actions: 'Tindakan'
  }
};
`;

// Insert dictionary before component
code = code.replace("export default function Dashboard() {", dictionary + "\nexport default function Dashboard() {");

// Inject language state
code = code.replace("  const [clearingHistory, setClearingHistory] = useState(false);", "  const [clearingHistory, setClearingHistory] = useState(false);\n  const [lang, setLang] = useState<'en' | 'ms'>('en');");

// Inject Language Toggle UI for Admin
const adminHeaderOld = `<div className="hidden md:block p-4 border-t border-slate-800 bg-slate-900/50 mt-auto">`;
const adminHeaderNew = `<div className="px-4 py-2 mt-auto">
          <div className="flex bg-[#050914] p-1 rounded-lg">
            <button 
              onClick={() => setLang('en')}
              className={\`flex-1 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'en' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}\`}
            >
              ENG
            </button>
            <button 
              onClick={() => setLang('ms')}
              className={\`flex-1 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'ms' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}\`}
            >
              BM
            </button>
          </div>
        </div>
        <div className="hidden md:block p-4 border-t border-slate-800 bg-slate-900/50">`;
code = code.replace(adminHeaderOld, adminHeaderNew);

// Inject Language Toggle UI for Client Dashboard
const clientHeaderOld = `<div className="flex items-center gap-4">
              <p className="text-sm text-slate-300 hidden md:block">Selamat Datang, {clientUser.name || clientUser.email}</p>`;
const clientHeaderNew = `<div className="flex items-center gap-4">
              <div className="flex bg-[#050914] p-1 rounded-lg">
                <button 
                  onClick={() => setLang('en')}
                  className={\`px-3 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'en' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}\`}
                >
                  ENG
                </button>
                <button 
                  onClick={() => setLang('ms')}
                  className={\`px-3 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'ms' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}\`}
                >
                  BM
                </button>
              </div>
              <p className="text-sm text-slate-300 hidden md:block">{t[lang].welcome}, {clientUser.name || clientUser.email}</p>`;
code = code.replace(clientHeaderOld, clientHeaderNew);

// Replacements
code = code.replace(/>Log Keluar<\/button>/g, '>{t[lang].logout}</button>');
code = code.replace(/>Muat Turun EA<\/span>/g, '>{t[lang].downloadEA}</span>');
code = code.replace(/>Join Group WhatsApp<\/span>/g, '>{t[lang].joinWhatsapp}</span>');
code = code.replace(/>Panduan Tutorial<\/span>/g, '>{t[lang].tutorialGuide}</span>');
code = code.replace(/alert\('Pautan belum dikemaskini oleh Admin.'\)/g, 'alert(t[lang].linkNotSetWarning)');

code = code.replace(/>Lesen Aktif Anda<\/h2>/g, '>{t[lang].activeLicense}</h2>');
code = code.replace(/>Tuntut Free Trial 3 Hari<\/h3>/g, '>{t[lang].claimTrial}</h3>');
code = code.replace(/>Sila salin License Key anda \(Sah 3 Hari\):<\/p>/g, '>{t[lang].copyKeyValid}</p>');
code = code.replace(/Tamat Tempoh:/g, '{t[lang].expires}');
code = code.replace(/>Salin Key<\/button>/g, '>{t[lang].copyKey}</button>');
code = code.replace(/>Tutup<\/button>/g, '>{t[lang].close}</button>');
code = code.replace(/>Nama MT5 \(Berdaftar Dengan Broker\)<\/label>/g, '>{t[lang].mt5Name}</label>');
code = code.replace(/>Tuntut Sekarang<\/button>/g, '>{t[lang].claimNow}</button>');
code = code.replace(/>Sejarah & Status Lesen<\/h2>/g, '>{t[lang].historyStatus}</h2>');

// Admin panel replacements
code = code.replace(/>Tetapan Sistem<\/span>/g, '>{t[lang].adminSettings}</span>');
code = code.replace(/>Tetapan Sistem<\/h2>/g, '>{t[lang].adminSettings}</h2>');
code = code.replace(/>Sejarah \(Hari\)<\/label>/g, '>{t[lang].historyDays}</label>');
code = code.replace(/>Tempoh hari sebelum sejarah lesen klien dipadam secara automatik.<\/p>/g, '>{t[lang].historyDaysDesc}</p>');
code = code.replace(/'Memadam...' : 'Padam Semua Sekarang'/g, 'clearingHistory ? t[lang].deleting : t[lang].deleteAllNow');

code = code.replace(/>Kemaskini EA \(Client Portal\)<\/h3>/g, '>{t[lang].eaUpdate}</h3>');
code = code.replace(/>Pautan Muat Turun EA<\/label>/g, '>{t[lang].eaDownloadLink}</label>');
code = code.replace(/>Keterangan \/ Changelog EA<\/label>/g, '>{t[lang].eaDesc}</label>');
code = code.replace(/>Pautan Luaran<\/h3>/g, '>{t[lang].extLinks}</h3>');
code = code.replace(/>Pautan Group WhatsApp<\/label>/g, '>{t[lang].whatsappLink}</label>');
code = code.replace(/>Pautan Panduan Tutorial<\/label>/g, '>{t[lang].tutorialLink}</label>');
code = code.replace(/'Menyimpan...' : 'Simpan Tetapan'/g, 'settingsLoading ? t[lang].saving : t[lang].saveSettings');

code = code.replace(/>Adakah anda pasti\?<\/h3>/g, '>{t[lang].areYouSure}</h3>');
code = code.replace(/>Tindakan ini akan memadam KESEMUA rekod Sejarah & Status Lesen untuk SEMUA pelanggan. Tindakan ini tidak boleh dipulihkan.<\/p>/g, '>{t[lang].deleteAllWarning}</p>');
code = code.replace(/>Batal<\/button>/g, '>{t[lang].cancel}</button>');
code = code.replace(/'Memadam...' : 'Setuju Padam Semua Sejarah'/g, "clearingHistory ? t[lang].deleting : t[lang].confirmDeleteAll");


fs.writeFileSync('src/components/Dashboard.tsx', code);
