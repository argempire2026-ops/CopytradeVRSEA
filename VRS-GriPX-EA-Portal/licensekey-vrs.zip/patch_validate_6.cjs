const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  'Print("🔥 [FIREBASE] License SAH dan AKTIF!");\n            return true;',
  'if (!silent) Print("🔥 [FIREBASE] License SAH dan AKTIF!");\n            g_is_expired = false;\n            return true;'
);

fs.writeFileSync('public/ea-code.txt', code);
