const fs = require('fs');
const code = fs.readFileSync('src/eaCode.ts', 'utf-8');

const validateMatch = code.indexOf('bool ValidateLicenseFirebase(');
if (validateMatch !== -1) {
  console.log(code.substring(validateMatch, validateMatch + 3000));
} else {
  console.log("ValidateLicenseFirebase not found");
}
