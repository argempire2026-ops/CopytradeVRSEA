const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Replace login strings
code = code.replace(/>Log Masuk Portal Pelanggan<\/h2>/g, '>{t[lang].clientPortal}</h2>');
code = code.replace(/>Emel Berdaftar<\/label>/g, '>{t[lang].registeredEmail}</label>');
code = code.replace(/>Kata Laluan<\/label>/g, '>{t[lang].password}</label>');
code = code.replace(/>Log Masuk<\/button>/g, '>{t[lang].login}</button>');

// Add toggle to the login screen
const loginHeaderOld = `<img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-16 h-16 rounded-xl object-cover shadow-lg mx-auto mb-6" alt="VRS Logo" />`;
const loginHeaderNew = `<div className="flex justify-end mb-4">
              <div className="flex bg-[#050914] p-1 rounded-lg">
                <button 
                  type="button"
                  onClick={() => setLang('en')}
                  className={\`px-3 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'en' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}\`}
                >
                  ENG
                </button>
                <button 
                  type="button"
                  onClick={() => setLang('ms')}
                  className={\`px-3 text-xs font-bold py-1.5 rounded-md transition-colors \${lang === 'ms' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-300'}\`}
                >
                  BM
                </button>
              </div>
            </div>
            <img src="https://i.postimg.cc/mDjNtPBK/Whats-App-Image-2026-09-03-at-5-08-05-AM-(1).jpg" className="w-16 h-16 rounded-xl object-cover shadow-lg mx-auto mb-6" alt="VRS Logo" />`;
code = code.replace(loginHeaderOld, loginHeaderNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
