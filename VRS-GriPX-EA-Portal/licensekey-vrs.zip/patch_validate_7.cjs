const fs = require('fs');
let code = fs.readFileSync('public/ea-code.txt', 'utf-8');

code = code.replace(
  'if (!silent) Print("🔥 [FIREBASE] License SAH dan AKTIF!");\n            g_is_expired = false;\n            return true;',
  `datetime myt_now_check = TimeGMT() + (Malaysia_GMT_Offset * 3600);
            if (g_license_expiry_time > 0 && myt_now_check >= g_license_expiry_time) {
                // expired date reached
                g_is_expired = true;
            } else {
                if (!silent) Print("🔥 [FIREBASE] License SAH dan AKTIF!");
                g_is_expired = false;
            }
            return true;`
);

fs.writeFileSync('public/ea-code.txt', code);
