const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// 1. Add states
code = code.replace(
  "const [defaultMaxTrials, setDefaultMaxTrials] = useState(1);",
  "const [defaultMaxTrials, setDefaultMaxTrials] = useState(1);\n  const [defaultTrialDays, setDefaultTrialDays] = useState(3);\n  const [earlyBirdLimit, setEarlyBirdLimit] = useState(0);\n  const [earlyBirdDays, setEarlyBirdDays] = useState(7);\n  const [earlyBirdClaimed, setEarlyBirdClaimed] = useState(0);"
);

// 2. Load settings
code = code.replace(
  "if (data.defaultMaxTrials !== undefined) setDefaultMaxTrials(data.defaultMaxTrials);",
  `if (data.defaultMaxTrials !== undefined) setDefaultMaxTrials(data.defaultMaxTrials);
        if (data.defaultTrialDays !== undefined) setDefaultTrialDays(data.defaultTrialDays);
        if (data.earlyBirdLimit !== undefined) setEarlyBirdLimit(data.earlyBirdLimit);
        if (data.earlyBirdDays !== undefined) setEarlyBirdDays(data.earlyBirdDays);
        if (data.earlyBirdClaimed !== undefined) setEarlyBirdClaimed(data.earlyBirdClaimed);`
);

// 3. Save settings
code = code.replace(
  "defaultMaxTrials,\n        eaList,",
  "defaultMaxTrials,\n        defaultTrialDays,\n        earlyBirdLimit,\n        earlyBirdDays,\n        earlyBirdClaimed,\n        eaList,"
);

// 4. Update UI in settings
const settingsUIOld = `                  <p className="text-xs text-slate-500 mb-6">Global limit for how many times a client can claim the free trial.</p>

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.historyDays}</label>`;
const settingsUINew = `                  <p className="text-xs text-slate-500 mb-6">Global limit for how many times a client can claim the free trial.</p>

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Default Trial Duration (Days)</label>
                  <input type="number" min="1" value={defaultTrialDays} onChange={(e) => setDefaultTrialDays(parseInt(e.target.value) || 3)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-6" />

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Early Bird Limit (Quota)</label>
                  <input type="number" min="0" value={earlyBirdLimit} onChange={(e) => setEarlyBirdLimit(parseInt(e.target.value) || 0)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-1" />
                  <p className="text-xs text-slate-500 mb-6">First N claims will get the early bird promo duration. Set to 0 to disable.</p>

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Early Bird Duration (Days)</label>
                  <input type="number" min="1" value={earlyBirdDays} onChange={(e) => setEarlyBirdDays(parseInt(e.target.value) || 7)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-6" />

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Early Bird Claimed (Editable to Reset)</label>
                  <input type="number" min="0" value={earlyBirdClaimed} onChange={(e) => setEarlyBirdClaimed(parseInt(e.target.value) || 0)} className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-slate-500 outline-none text-slate-200 transition-shadow mb-6" />

                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{t.historyDays}</label>`;
code = code.replace(settingsUIOld, settingsUINew);


// 5. Update claim logic
// Ensure getDoc and increment are imported from firebase/firestore
if (!code.includes("increment")) {
    code = code.replace("updateDoc, deleteDoc", "updateDoc, deleteDoc, increment, getDoc");
    code = code.replace("updateDoc, getDocs", "updateDoc, getDocs, increment, getDoc"); // Try both just in case
}

const claimLogicOld = `      // Create a 3 day expiry
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 3);
      const expiryStr = expiryDate.toISOString();`;

const claimLogicNew = `      // Get latest settings to check promo
      let daysToGive = defaultTrialDays;
      const settingsSnap = await getDoc(doc(db, 'settings', 'general'));
      if (settingsSnap.exists()) {
        const sData = settingsSnap.data();
        const currentClaimed = sData.earlyBirdClaimed || 0;
        const currentLimit = sData.earlyBirdLimit || 0;
        if (currentLimit > 0 && currentClaimed < currentLimit) {
          daysToGive = sData.earlyBirdDays || 7;
          // Increment promo claimed
          await updateDoc(doc(db, 'settings', 'general'), {
            earlyBirdClaimed: increment(1)
          });
          setEarlyBirdClaimed(currentClaimed + 1);
        }
      }

      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + daysToGive);
      const expiryStr = expiryDate.toISOString();`;

code = code.replace(claimLogicOld, claimLogicNew);

// 6. Update the text shown to the user on the claim trial panel
// Let's find "Claim 3-Day Free Trial"
code = code.replace(/Claim 3-Day Free Trial/g, "Claim Free Trial");


fs.writeFileSync('src/components/Dashboard.tsx', code);
