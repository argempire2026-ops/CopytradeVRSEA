const fs = require('fs');
let code = fs.readFileSync('src/eaCode.ts', 'utf-8');

// 1. Add tracking variable
code = code.replace(/bool\s+is_news_blocked = false;/, `bool     is_news_blocked = false;
bool     last_news_blocked_state = false;`);

// 2. Add logic inside OnTick()
const onTickMatch = code.indexOf('void OnTick()');
if (onTickMatch !== -1) {
    const afterOnTick = code.indexOf('{', onTickMatch) + 1;
    const injection = `
   if (is_news_blocked && !last_news_blocked_state && MQID_NOTI != "") {
      string timeStr = TimeToString(next_news_time_myt, TIME_MINUTES);
      SendNotification("VRS Alert : No entry for now. " + next_news_impact_str + " Impact News will occur at " + timeStr);
   }
   last_news_blocked_state = is_news_blocked;
`;
    code = code.substring(0, afterOnTick) + injection + code.substring(afterOnTick);
}

fs.writeFileSync('src/eaCode.ts', code);
