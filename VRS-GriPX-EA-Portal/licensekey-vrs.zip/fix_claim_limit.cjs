const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const oldLogic = `  const handleClaimTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialMt5.trim() || !clientUser) return;
    
    const maxAllowed = clientUser.maxTrials !== undefined ? clientUser.maxTrials : defaultMaxTrials;
    if (clientUser.trialCount >= maxAllowed) {
      setTrialResult({ key: '', error: \`You have reached the maximum allowed trial claims (\${maxAllowed}).\` });
      return;
    }`;

const newLogic = `  const handleClaimTrial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trialMt5.trim() || !clientUser) return;
    
    if ((clientUser.trialCount || 0) >= 1) {
      setTrialResult({ key: '', error: \`You have already claimed your free trial. Please subscribe or renew to continue.\` });
      return;
    }`;

code = code.replace(oldLogic, newLogic);

// We also need to change the UI when trialCount >= 1 instead of showing the form.
// Let's find the trial result / form UI.
