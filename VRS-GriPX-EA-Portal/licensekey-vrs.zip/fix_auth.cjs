const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

const authLogicOld = `  useEffect(() => {
    // Wait for auth to initialize before fetching data
    const unsubscribeAuth = auth.onAuthStateChanged((currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const q = query(collection(db, 'licenseKeys'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
          const now = new Date();
          const keysData: LicenseKey[] = [];
          
          snapshot.docs.forEach(document => {
            const data = document.data();
            const keyId = document.id;
            
            if (data.expiresAt && new Date(data.expiresAt) < now) {
              deleteDoc(doc(db, 'licenseKeys', keyId)).catch(console.error);
            } else {
              keysData.push({
                ...data,
                id: keyId,
                status: data.status,
                createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : new Date().toISOString()
              } as LicenseKey);
            }
          });
          
          setKeys(keysData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
          setLoading(false);
        });
        return () => unsubscribe();
      } else {
        setKeys([]);
        setLoading(true);
      }
    });
    return () => unsubscribeAuth();
  }, []);`;

const authLogicNew = `  useEffect(() => {
    let unsubscribeSnapshot: (() => void) | undefined;
    let isCheckingAccess = false;

    const unsubscribeAuth = auth.onAuthStateChanged(async (currentUser) => {
      if (currentUser) {
        if (currentUser.email === 'mfrdotbiz@gmail.com') {
          // Master admin
          setUser(currentUser);
          subscribeToKeys(currentUser);
        } else {
          try {
            // Check if user is in admins list
            const adminDoc = await getDoc(doc(db, 'admins', currentUser.email || ''));
            if (adminDoc.exists()) {
              setUser(currentUser);
              subscribeToKeys(currentUser);
            } else {
              throw new Error('Not admin');
            }
          } catch (e) {
            alert('Akses Ditolak: E-mel anda tiada dalam senarai Team Access.');
            await auth.signOut();
            setUser(null);
            setKeys([]);
            setLoading(true);
            setShowAdminLogin(false);
          }
        }
      } else {
        setUser(null);
        setKeys([]);
        setLoading(true);
        if (unsubscribeSnapshot) unsubscribeSnapshot();
      }
    });

    const subscribeToKeys = (currentUser: any) => {
      const q = query(collection(db, 'licenseKeys'));
      unsubscribeSnapshot = onSnapshot(q, (snapshot) => {
        const now = new Date();
        const keysData: LicenseKey[] = [];
        
        snapshot.docs.forEach(document => {
          const data = document.data();
          const keyId = document.id;
          
          if (data.expiresAt && new Date(data.expiresAt) < now) {
            deleteDoc(doc(db, 'licenseKeys', keyId)).catch(console.error);
          } else {
            keysData.push({
              ...data,
              id: keyId,
              status: data.status,
              createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : new Date().toISOString()
            } as LicenseKey);
          }
        });
        
        setKeys(keysData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
        setLoading(false);
      }, (error) => {
        console.error("Keys snapshot error:", error);
      });
    };

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);`;

code = code.replace(authLogicOld, authLogicNew);

fs.writeFileSync('src/components/Dashboard.tsx', code);
