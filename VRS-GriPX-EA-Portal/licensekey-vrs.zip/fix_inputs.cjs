const fs = require('fs');
let code = fs.readFileSync('src/components/Dashboard.tsx', 'utf-8');

// Fix specific inputs with border-slate-300
code = code.replace(/className="w-full p-3 border border-slate-300 rounded focus:ring-2 focus:ring-\[\#D4AF37\] focus:border-\[\#D4AF37\] outline-none"/g, 'className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none text-white placeholder:text-slate-500"');

code = code.replace(/className="w-full p-3 border border-slate-300 rounded focus:ring-2 focus:ring-\[\#D4AF37\] focus:border-\[\#D4AF37\] outline-none transition-shadow"/g, 'className="w-full p-3 bg-[#050914] border border-slate-800 rounded focus:ring-2 focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none transition-shadow text-white placeholder:text-slate-500"');

// Fix all inputs with text-slate-200 to also have placeholder:text-slate-500
code = code.replace(/outline-none text-slate-200/g, 'outline-none text-white placeholder:text-slate-500');

fs.writeFileSync('src/components/Dashboard.tsx', code);
console.log('Fixed inputs');
